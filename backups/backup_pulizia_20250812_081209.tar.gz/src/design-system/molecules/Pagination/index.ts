export { Pagination } from './Pagination';
export type { PaginationProps } from './Pagination';
export { default } from './Pagination';