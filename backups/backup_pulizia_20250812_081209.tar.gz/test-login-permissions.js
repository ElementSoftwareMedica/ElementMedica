import fetch from 'node-fetch';

async function testLoginAndPermissions() {
  try {
    console.log('🧪 TEST LOGIN E PERMESSI ADMIN');
    console.log('==============================');
    
    // 1. Test login
    console.log('\n1. 🔐 Test login...');
    const loginResponse = await fetch('http://localhost:4001/api/v1/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });
    
    if (!loginResponse.ok) {
      console.log('❌ Login fallito:', loginResponse.status, loginResponse.statusText);
      const errorText = await loginResponse.text();
      console.log('Errore:', errorText);
      return;
    }
    
    const loginData = await loginResponse.json();
    console.log('✅ Login riuscito');
    console.log('📋 Dati utente:', {
      id: loginData.user?.id,
      email: loginData.user?.email,
      role: loginData.user?.role,
      roles: loginData.user?.roles
    });
    
    const token = loginData.tokens?.access_token;
    if (!token) {
      console.log('❌ Token non ricevuto');
      return;
    }
    console.log('🔑 Token ricevuto:', token.substring(0, 20) + '...');
    
    // 2. Test verifica token
    console.log('\n2. 🔍 Test verifica token...');
    const verifyResponse = await fetch('http://localhost:4001/api/v1/auth/verify', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!verifyResponse.ok) {
      console.log('❌ Verifica token fallita:', verifyResponse.status, verifyResponse.statusText);
      const errorText = await verifyResponse.text();
      console.log('Errore:', errorText);
      return;
    }
    
    const verifyData = await verifyResponse.json();
    console.log('✅ Token verificato');
    console.log('📋 Utente verificato:', {
      id: verifyData.user?.id,
      email: verifyData.user?.email,
      role: verifyData.user?.role,
      roles: verifyData.user?.roles
    });
    
    // 3. Analisi permessi
    console.log('\n3. 🔍 Analisi permessi...');
    const permissions = verifyData.permissions || {};
    const permissionKeys = Object.keys(permissions).filter(key => permissions[key] === true);
    
    console.log('📊 Totale permessi:', permissionKeys.length);
    console.log('📋 Tutti i permessi:', permissionKeys.sort());
    
    // 4. Verifica permessi critici per i ruoli
    console.log('\n4. 🔑 Verifica permessi ruoli...');
    const permessiRuoli = [
      'roles:read',
      'roles:view',
      'roles:create',
      'roles:edit',
      'roles:delete',
      'roles:manage',
      'ROLE_MANAGEMENT',
      'VIEW_ROLES',
      'CREATE_ROLES',
      'EDIT_ROLES',
      'DELETE_ROLES'
    ];
    
    console.log('🔍 Permessi relativi ai ruoli:');
    permessiRuoli.forEach(perm => {
      const hasPermission = permissions[perm] === true;
      console.log(`  ${hasPermission ? '✅' : '❌'} ${perm}: ${hasPermission}`);
    });
    
    // 5. Test specifico per roles:read
    console.log('\n5. 🎯 Test specifico roles:read...');
    const hasRolesRead = permissions['roles:read'] === true;
    const hasRolesView = permissions['roles:view'] === true;
    const hasRoleManagement = permissions['ROLE_MANAGEMENT'] === true;
    
    console.log(`roles:read: ${hasRolesRead ? '✅' : '❌'}`);
    console.log(`roles:view: ${hasRolesView ? '✅' : '❌'}`);
    console.log(`ROLE_MANAGEMENT: ${hasRoleManagement ? '✅' : '❌'}`);
    
    if (hasRolesRead || hasRolesView || hasRoleManagement) {
      console.log('✅ L\'admin dovrebbe poter accedere ai ruoli');
    } else {
      console.log('❌ L\'admin NON può accedere ai ruoli - permessi mancanti');
    }
    
    // 6. Test endpoint ruoli (se disponibile)
    console.log('\n6. 🧪 Test endpoint ruoli...');
    try {
      const rolesResponse = await fetch('http://localhost:4001/api/v1/roles', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (rolesResponse.ok) {
        const rolesData = await rolesResponse.json();
        console.log('✅ Endpoint ruoli accessibile');
        console.log('📋 Ruoli trovati:', rolesData.length || 'N/A');
      } else {
        console.log('❌ Endpoint ruoli non accessibile:', rolesResponse.status);
      }
    } catch (error) {
      console.log('⚠️ Endpoint ruoli non testabile:', error.message);
    }
    
    console.log('\n🎯 RISULTATO TEST');
    console.log('=================');
    if (hasRolesRead || hasRolesView || hasRoleManagement) {
      console.log('✅ LOGIN E PERMESSI FUNZIONANTI');
      console.log('L\'admin può accedere alla gestione ruoli');
    } else {
      console.log('❌ PERMESSI MANCANTI');
      console.log('Eseguire lo script verify-fix-admin-permissions.js');
    }
    
  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
  }
}

// Esegui il test
testLoginAndPermissions();