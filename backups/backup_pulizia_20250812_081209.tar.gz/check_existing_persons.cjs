const { PrismaClient } = require('@prisma/client');

async function checkExistingPersons() {
  const prisma = new PrismaClient();
  
  try {
    console.log('🔍 Verifico persone esistenti nel database...\n');
    
    // Cerca persone con il codice fiscale del test
    const personsWithTaxCode = await prisma.person.findMany({
      where: {
        taxCode: 'RSSMRA80A01H501Z'
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        taxCode: true,
        deletedAt: true
      }
    });
    
    console.log('📋 Persone trovate con taxCode RSSMRA80A01H501Z:');
    console.log(JSON.stringify(personsWithTaxCode, null, 2));
    
    // Mostra le prime 10 persone nel database
    const allPersons = await prisma.person.findMany({
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        taxCode: true,
        deletedAt: true
      },
      take: 10,
      orderBy: {
        createdAt: 'desc'
      }
    });
    
    console.log('\n📊 Prime 10 persone nel database (più recenti):');
    console.log(JSON.stringify(allPersons, null, 2));
    
    // Conta totale persone
    const totalPersons = await prisma.person.count();
    console.log(`\n📈 Totale persone nel database: ${totalPersons}`);
    
  } catch (error) {
    console.error('❌ Errore:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkExistingPersons();