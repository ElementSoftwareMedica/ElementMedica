/**
 * Design System - Label Component Export
 */

export { Label, type LabelProps, type LabelSize, type LabelVariant } from './Label';
export { default } from './Label';