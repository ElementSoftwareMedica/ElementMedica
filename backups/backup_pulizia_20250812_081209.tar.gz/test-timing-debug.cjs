const puppeteer = require('puppeteer');

async function testTimingDebug() {
  const browser = await puppeteer.launch({ 
    headless: false,
    devtools: true,
    slowMo: 100
  });
  
  const page = await browser.newPage();
  
  // Intercetta tutti i log della console
  page.on('console', msg => {
    const type = msg.type();
    const text = msg.text();
    
    // Filtra solo i log rilevanti per TenantContext e Dashboard
    if (text.includes('TenantContext') || 
        text.includes('Dashboard') || 
        text.includes('fetchCounters') ||
        text.includes('fetchData') ||
        text.includes('counters') ||
        text.includes('/api/counters')) {
      console.log(`[BROWSER ${type.toUpperCase()}] ${text}`);
    }
  });
  
  // Intercetta le richieste di rete
  page.on('request', request => {
    const url = request.url();
    if (url.includes('/api/')) {
      console.log(`[NETWORK REQUEST] ${request.method()} ${url}`);
    }
  });
  
  page.on('response', response => {
    const url = response.url();
    if (url.includes('/api/')) {
      console.log(`[NETWORK RESPONSE] ${response.status()} ${url}`);
    }
  });
  
  try {
    console.log('🚀 Navigating to login page...');
    await page.goto('http://localhost:5174/login');
    
    console.log('📝 Filling login form...');
    await page.waitForSelector('#identifier');
    await page.type('#identifier', 'admin@example.com');
    await page.type('#password', 'password123');
    
    console.log('🔐 Submitting login...');
    await page.click('button[type="submit"]');
    
    // Aspetta il redirect alla dashboard
    console.log('⏳ Waiting for dashboard...');
    await page.waitForNavigation({ waitUntil: 'networkidle0' });
    
    // Aspetta un po' per permettere ai context di inizializzarsi
    console.log('⏳ Waiting for contexts to initialize...');
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Verifica lo stato dei context nel browser
    const contextState = await page.evaluate(() => {
      // Accedi ai context React tramite il DOM
      const authData = localStorage.getItem('authToken');
      const tenantData = localStorage.getItem('tenantId');
      
      return {
        hasAuthToken: !!authData,
        hasTenantId: !!tenantData,
        authToken: authData ? 'present' : 'missing',
        tenantId: tenantData ? 'present' : 'missing'
      };
    });
    
    console.log('📊 Context state:', contextState);
    
    // Verifica i contatori nel DOM
    const countersInDOM = await page.evaluate(() => {
      const statCards = document.querySelectorAll('[data-testid*="stat-card"], .stat-card, [class*="stat"]');
      const counters = [];
      
      statCards.forEach((card, index) => {
        const text = card.textContent || '';
        const value = card.querySelector('[class*="value"], .value, h2, h3')?.textContent || '';
        counters.push({
          index,
          text: text.substring(0, 100),
          value: value
        });
      });
      
      return counters;
    });
    
    console.log('📊 Counters in DOM:', countersInDOM);
    
    // Aspetta ancora un po' e ricontrolla
    console.log('⏳ Waiting additional time for async operations...');
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    // Ricontrolla i contatori
    const countersAfterWait = await page.evaluate(() => {
      const statCards = document.querySelectorAll('[data-testid*="stat-card"], .stat-card, [class*="stat"]');
      const counters = [];
      
      statCards.forEach((card, index) => {
        const text = card.textContent || '';
        const value = card.querySelector('[class*="value"], .value, h2, h3')?.textContent || '';
        counters.push({
          index,
          text: text.substring(0, 100),
          value: value
        });
      });
      
      return counters;
    });
    
    console.log('📊 Counters after additional wait:', countersAfterWait);
    
    // Forza una chiamata manuale all'API per verificare se funziona
    console.log('🔧 Testing manual API call...');
    const manualApiCall = await page.evaluate(async () => {
      try {
        const token = localStorage.getItem('authToken');
        const tenantId = localStorage.getItem('tenantId');
        
        const response = await fetch('/api/counters', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'X-Tenant-ID': tenantId,
            'Content-Type': 'application/json'
          }
        });
        
        const data = await response.json();
        
        return {
          status: response.status,
          data: data,
          headers: {
            authorization: !!token,
            tenantId: !!tenantId
          }
        };
      } catch (error) {
        return {
          error: error.message
        };
      }
    });
    
    console.log('🔧 Manual API call result:', manualApiCall);
    
    // Salva screenshot
    await page.screenshot({ path: 'dashboard-timing-debug.png', fullPage: true });
    console.log('📸 Screenshot saved as dashboard-timing-debug.png');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await browser.close();
  }
}

testTimingDebug().catch(console.error);