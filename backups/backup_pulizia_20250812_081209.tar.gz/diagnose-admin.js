const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function diagnoseAndFix() {
  try {
    console.log('🔍 DIAGNOSI COMPLETA PERMESSI ADMIN');
    console.log('=====================================\n');

    // 1. Trova l'utente admin
    const admin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        roles: {
          include: {
            permissions: true
          }
        }
      }
    });

    if (!admin) {
      console.log('❌ ERRORE: Admin non trovato');
      return;
    }

    console.log(`✅ Admin trovato: ${admin.email} (ID: ${admin.id})`);
    console.log(`📋 Ruoli attuali: ${admin.roles.length}`);

    // 2. Verifica ruoli esistenti
    admin.roles.forEach((role, index) => {
      console.log(`   ${index + 1}. ${role.roleType} (Attivo: ${role.isActive})`);
      console.log(`      Permessi: ${role.permissions.length}`);
      role.permissions.forEach(perm => {
        console.log(`        - ${perm.permission}: ${perm.isGranted}`);
      });
    });

    // 3. Verifica se ha il ruolo ADMIN
    const adminRole = admin.roles.find(r => r.roleType === 'ADMIN' && r.isActive);
    
    if (!adminRole) {
      console.log('\n⚠️ PROBLEMA: Ruolo ADMIN mancante o inattivo');
      console.log('🔧 Aggiungendo ruolo ADMIN...');
      
      const newRole = await prisma.personRole.create({
        data: {
          personId: admin.id,
          roleType: 'ADMIN',
          tenantId: admin.tenantId,
          isActive: true,
          assignedAt: new Date(),
          assignedBy: admin.id
        }
      });
      
      console.log(`✅ Ruolo ADMIN aggiunto (ID: ${newRole.id})`);
    } else {
      console.log('\n✅ Ruolo ADMIN presente e attivo');
      
      // 4. Verifica se ha il permesso ROLE_MANAGEMENT
      const hasRoleManagement = adminRole.permissions.some(p => 
        p.permission === 'ROLE_MANAGEMENT' && p.isGranted
      );
      
      if (!hasRoleManagement) {
        console.log('⚠️ PROBLEMA: Permesso ROLE_MANAGEMENT mancante');
        console.log('🔧 Aggiungendo permesso ROLE_MANAGEMENT...');
        
        await prisma.rolePermission.create({
          data: {
            personRoleId: adminRole.id,
            permission: 'ROLE_MANAGEMENT',
            isGranted: true,
            grantedAt: new Date(),
            grantedBy: admin.id
          }
        });
        
        console.log('✅ Permesso ROLE_MANAGEMENT aggiunto');
      } else {
        console.log('✅ Permesso ROLE_MANAGEMENT presente');
      }
    }

    // 5. Verifica finale
    console.log('\n🔍 VERIFICA FINALE');
    console.log('==================');
    
    const finalAdmin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        roles: {
          where: { isActive: true },
          include: {
            permissions: {
              where: { isGranted: true }
            }
          }
        }
      }
    });

    console.log(`📋 Ruoli attivi: ${finalAdmin.roles.length}`);
    finalAdmin.roles.forEach(role => {
      console.log(`   - ${role.roleType}: ${role.permissions.length} permessi`);
      role.permissions.forEach(perm => {
        console.log(`     * ${perm.permission}`);
      });
    });

    // 6. Test del permesso ROLE_MANAGEMENT
    const hasRoleManagementFinal = finalAdmin.roles.some(role => 
      role.permissions.some(p => p.permission === 'ROLE_MANAGEMENT')
    );
    
    console.log(`\n🎯 ROLE_MANAGEMENT: ${hasRoleManagementFinal ? '✅ PRESENTE' : '❌ MANCANTE'}`);
    
    if (hasRoleManagementFinal) {
      console.log('\n🎉 RISOLUZIONE COMPLETATA!');
      console.log('L\'admin ora dovrebbe poter accedere alla sezione ruoli.');
    } else {
      console.log('\n❌ PROBLEMA PERSISTENTE');
      console.log('Verifica manualmente il database.');
    }

  } catch (error) {
    console.error('❌ ERRORE:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

diagnoseAndFix();