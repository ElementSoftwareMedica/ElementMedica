const axios = require('axios');

async function testFrontendCounters() {
  try {
    console.log('🔐 Step 1: Login...');
    const loginResponse = await axios.post('http://localhost:4003/api/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    const token = loginResponse.data.tokens.access_token;
    const tenantId = loginResponse.data.user.tenantId;
    console.log('✅ Login successful');
    console.log('🔑 Token exists:', !!token);
    console.log('🏢 Tenant ID:', tenantId);
    
    console.log('\n🔄 Step 2: Test /api/counters exactly like frontend...');
    
    // Simula esattamente come il frontend fa la chiamata
    const countersResponse = await axios.get('http://localhost:4003/api/counters', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'X-Tenant-ID': tenantId || 'default-company'
      },
      withCredentials: true,
      timeout: 20000
    });
    
    console.log('✅ Counters response:', JSON.stringify(countersResponse.data, null, 2));
    
  } catch (error) {
    console.error('❌ Error:', error.response?.status, error.response?.data || error.message);
    if (error.response?.data) {
      console.error('Full error response:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

testFrontendCounters();