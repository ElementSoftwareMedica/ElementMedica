// Test dell'accesso alle pagine con i permessi dell'admin
console.log('🔍 Testing page access with admin permissions...');

// Simula i permessi frontend dell'admin (come dovrebbero essere dopo la conversione)
const adminPermissions = {
  'PUBLIC_CMS:READ': true,
  'PUBLIC_CMS:UPDATE': true,
  'PUBLIC_CMS:read': true,
  'PUBLIC_CMS:update': true,
  'PUBLIC_CMS:CREATE': true,
  'PUBLIC_CMS:create': true,
  'PUBLIC_CMS:DELETE': true,
  'PUBLIC_CMS:delete': true,
  'form_templates:read': true,
  'form_templates:create': true,
  'form_templates:update': true,
  'form_templates:delete': true,
  'form_submissions:read': true,
  'form_submissions:create': true,
  'form_submissions:update': true,
  'form_submissions:delete': true,
  'form_submissions:export': true
};

// Simula la funzione hasPermission dell'AuthContext
function hasPermission(resourceOrPermission, action, permissions = adminPermissions) {
  let permissionToCheck;
  
  if (action) {
    // Formato con due parametri: resource e action
    permissionToCheck = `${resourceOrPermission}:${action}`;
    console.log(`🔐 Checking permission (two params): ${resourceOrPermission}:${action}`);
  } else {
    // Formato con un parametro: permesso diretto
    permissionToCheck = resourceOrPermission;
    console.log(`🔐 Checking permission (single param): ${resourceOrPermission}`);
  }
  
  // Verifica permesso diretto
  if (permissions[permissionToCheck] === true) {
    console.log(`✅ Access granted: has ${permissionToCheck} permission (direct match)`);
    return true;
  }
  
  // Se abbiamo due parametri, prova anche altri formati
  if (action) {
    // Verifica permesso all:* (permesso universale)
    if (permissions['all:' + action] === true) {
      console.log('✅ Access granted: has all:' + action + ' permission');
      return true;
    }
    
    // Verifica permesso resource:all (permesso per tutte le azioni sulla risorsa)
    if (permissions[resourceOrPermission + ':all'] === true) {
      console.log('✅ Access granted: has ' + resourceOrPermission + ':all permission');
      return true;
    }
    
    // Concedi accesso se c'è almeno un permesso con quel resource per azioni 'read'
    if (action === 'read') {
      const resourcePermissions = Object.keys(permissions)
        .filter(key => key.startsWith(resourceOrPermission + ':') && permissions[key] === true);
      
      console.log(`🔍 Found ${resourcePermissions.length} permissions for resource '${resourceOrPermission}':`, resourcePermissions);
      
      if (resourcePermissions.length > 0) {
        console.log('✅ Access granted: has some permission for ' + resourceOrPermission);
        return true;
      }
    }
  }
  
  console.log(`❌ Permission check result: false for ${permissionToCheck}`);
  return false;
}

console.log('Admin permissions:', Object.keys(adminPermissions).filter(key => adminPermissions[key]));

// Test delle pagine problematiche
console.log('\n🧪 Testing PublicCMSPage access:');
const canViewCMS = hasPermission('PUBLIC_CMS', 'READ');
const canEditCMS = hasPermission('PUBLIC_CMS', 'UPDATE');
console.log('PublicCMSPage canView:', canViewCMS);
console.log('PublicCMSPage canEdit:', canEditCMS);

console.log('\n🧪 Testing FormTemplatesPage access:');
const canAccessFormTemplates = hasPermission('form_templates', 'read');
console.log('FormTemplatesPage access:', canAccessFormTemplates);

console.log('\n🧪 Testing FormSubmissionsPage access:');
const canAccessFormSubmissions = hasPermission('form_submissions', 'read');
console.log('FormSubmissionsPage access:', canAccessFormSubmissions);

// Test con formato maiuscolo (come potrebbe essere nelle pagine)
console.log('\n🧪 Testing with uppercase format:');
const canViewCMSUpper = hasPermission('PUBLIC_CMS', 'READ');
console.log('PUBLIC_CMS:READ (uppercase):', canViewCMSUpper);

// Test con formato minuscolo
console.log('\n🧪 Testing with lowercase format:');
const canViewCMSLower = hasPermission('PUBLIC_CMS', 'read');
console.log('PUBLIC_CMS:read (lowercase):', canViewCMSLower);