import axios from 'axios';

async function testImportEndpoint() {
  try {
    console.log('🔐 Step 1: Authenticating...');
    
    // Login to get token
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      email: 'admin@example.com',
      password: 'Admin123!'
    });
    
    const token = loginResponse.data.token;
    console.log('✅ Authentication successful');
    
    // Test data for import
    const testData = {
      companies: [
        {
          ragioneSociale: "Test Company Import",
          piva: "12345678901",
          codiceFiscale: "TSTCMP01",
          indirizzo: "Via Test 123",
          citta: "Milano",
          cap: "20100",
          provincia: "MI",
          telefono: "02-1234567",
          email: "test@testcompany.com"
        }
      ]
    };
    
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    
    console.log('\n📤 Step 2: Testing direct API server (port 4001)...');
    try {
      const directResponse = await axios.post('http://localhost:4001/api/v1/companies/import', testData, { headers });
      console.log('✅ Direct API test successful:', directResponse.status);
      console.log('Response:', JSON.stringify(directResponse.data, null, 2));
    } catch (error) {
      console.log('❌ Direct API test failed:', error.response?.status, error.response?.statusText);
      if (error.response?.data) {
        console.log('Error details:', JSON.stringify(error.response.data, null, 2));
      }
    }
    
    console.log('\n🔄 Step 3: Testing through proxy (port 4003)...');
    try {
      const proxyResponse = await axios.post('http://localhost:4003/api/v1/companies/import', testData, { headers });
      console.log('✅ Proxy test successful:', proxyResponse.status);
      console.log('Response:', JSON.stringify(proxyResponse.data, null, 2));
    } catch (error) {
      console.log('❌ Proxy test failed:', error.response?.status, error.response?.statusText);
      if (error.response?.data) {
        console.log('Error details:', JSON.stringify(error.response.data, null, 2));
      }
    }
    
  } catch (error) {
    console.error('❌ Authentication failed:', error.response?.status, error.response?.statusText);
    if (error.response?.data) {
      console.error('Error details:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

testImportEndpoint();