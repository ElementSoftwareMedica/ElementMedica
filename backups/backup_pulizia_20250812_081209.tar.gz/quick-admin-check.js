const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function quickCheck() {
  try {
    console.log('🔍 Controllo rapido admin...');

    // Trova admin
    const admin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        roles: {
          include: {
            permissions: true
          }
        }
      }
    });

    if (!admin) {
      console.log('❌ Admin non trovato');
      return;
    }

    console.log(`✅ Admin: ${admin.email}`);
    console.log(`📋 Ruoli: ${admin.roles.length}`);
    
    const adminRole = admin.roles.find(r => r.roleType === 'ADMIN');
    if (adminRole) {
      console.log(`🔑 Permessi ADMIN: ${adminRole.permissions.length}`);
      const hasRoleManagement = adminRole.permissions.some(p => p.permission === 'ROLE_MANAGEMENT');
      console.log(`🎯 ROLE_MANAGEMENT: ${hasRoleManagement ? '✅' : '❌'}`);
    } else {
      console.log('❌ Ruolo ADMIN non trovato');
    }

  } catch (error) {
    console.error('❌ Errore:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

quickCheck();