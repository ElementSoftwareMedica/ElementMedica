const axios = require('axios');

async function testSubmissionsAdvanced() {
  try {
    console.log('🔍 Testing /api/v1/submissions/advanced endpoint...\n');
    
    // 1. Login to get token
    console.log('1. Login...');
    const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    if (!loginResponse.data.tokens?.access_token) {
      console.error('❌ Login failed - no access token');
      return;
    }
    
    const token = loginResponse.data.tokens.access_token;
    const tenantId = loginResponse.data.user?.tenantId;
    console.log('✅ Login successful');
    console.log('👤 User:', {
      email: loginResponse.data.user?.email,
      role: loginResponse.data.user?.role,
      tenantId: tenantId
    });
    
    // 2. Test submissions/advanced endpoint
    console.log('\n2. Testing /api/v1/submissions/advanced endpoint...');
    try {
      const advancedResponse = await axios.get('http://localhost:4003/api/v1/submissions/advanced', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'X-Tenant-ID': tenantId || 'default-company'
        }
      });
      
      console.log('✅ Advanced submissions request successful');
      console.log('📊 Status:', advancedResponse.status);
      console.log('📋 Response data:', JSON.stringify(advancedResponse.data, null, 2));
      
    } catch (advancedError) {
      console.error('❌ Advanced submissions request failed');
      console.error('Status:', advancedError.response?.status);
      console.error('Error data:', advancedError.response?.data);
      console.error('Error message:', advancedError.message);
      
      // Log headers for debugging
      console.log('\n🔍 Request headers used:');
      console.log('Authorization: Bearer [token]');
      console.log('X-Tenant-ID:', tenantId || 'default-company');
    }
    
    // 3. Test regular submissions endpoint for comparison
    console.log('\n3. Testing /api/v1/submissions endpoint for comparison...');
    try {
      const regularResponse = await axios.get('http://localhost:4003/api/v1/submissions', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'X-Tenant-ID': tenantId || 'default-company'
        }
      });
      
      console.log('✅ Regular submissions request successful');
      console.log('📊 Status:', regularResponse.status);
      console.log('📋 Response data length:', Array.isArray(regularResponse.data) ? regularResponse.data.length : 'Not an array');
      
    } catch (regularError) {
      console.error('❌ Regular submissions request failed');
      console.error('Status:', regularError.response?.status);
      console.error('Error data:', regularError.response?.data);
    }
    
  } catch (error) {
    console.error('❌ General error:', error.response?.data || error.message);
  }
}

testSubmissionsAdvanced();