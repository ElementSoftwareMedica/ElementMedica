#!/bin/bash

# Test API per ruoli e permessi
echo "=== Test API Ruoli e Permessi ==="

# 1. Login per ottenere il token
echo "1. Effettuo login..."
LOGIN_RESPONSE=$(curl -s -X POST "http://localhost:4003/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"identifier":"admin@example.com","password":"Admin123!"}')

echo "Login response: $LOGIN_RESPONSE"

# Estrai il token
TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"token":"[^"]*"' | cut -d'"' -f4)
echo "Token: $TOKEN"

if [ -z "$TOKEN" ]; then
  echo "❌ Errore: Token non ottenuto"
  exit 1
fi

# 2. Ottieni lista ruoli
echo -e "\n2. Ottengo lista ruoli..."
ROLES_RESPONSE=$(curl -s -X GET "http://localhost:4003/api/v1/roles" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN")

echo "Roles response: $ROLES_RESPONSE"

# 3. Ottieni permessi disponibili
echo -e "\n3. Ottengo permessi disponibili..."
PERMISSIONS_RESPONSE=$(curl -s -X GET "http://localhost:4003/api/v1/roles/permissions" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN")

echo "Permissions response: $PERMISSIONS_RESPONSE"

# 4. Testa un ruolo specifico (se esiste)
echo -e "\n4. Testo ruolo specifico..."
ROLE_DETAIL_RESPONSE=$(curl -s -X GET "http://localhost:4003/api/v1/roles/ADMIN" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN")

echo "Role detail response: $ROLE_DETAIL_RESPONSE"

# 5. Testa permessi di un ruolo specifico
echo -e "\n5. Testo permessi ruolo ADMIN..."
ROLE_PERMISSIONS_RESPONSE=$(curl -s -X GET "http://localhost:4003/api/v1/roles/ADMIN/permissions" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN")

echo "Role permissions response: $ROLE_PERMISSIONS_RESPONSE"

echo -e "\n=== Test completato ==="