const axios = require('axios');

async function testSubmissionEndpoint() {
  try {
    console.log('🧪 Testing submission endpoint...');
    
    // 1. Login per ottenere token
    console.log('1. Logging in...');
    const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    if (!loginResponse.data.tokens?.access_token) {
      throw new Error('Login failed - no access token received');
    }
    
    const token = loginResponse.data.tokens.access_token;
    console.log('✅ Login successful, token length:', token.length);
    
    // 2. Test endpoint submissions
    console.log('2. Testing submissions endpoint...');
    const submissionResponse = await axios.get(
      'http://localhost:4003/api/v1/submissions/advanced/3f005622-e9b1-437a-a6d5-e77a7680aed2',
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    console.log('✅ Submission endpoint test successful!');
    console.log('Response status:', submissionResponse.status);
    console.log('Response data keys:', Object.keys(submissionResponse.data));
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    }
  }
}

testSubmissionEndpoint();