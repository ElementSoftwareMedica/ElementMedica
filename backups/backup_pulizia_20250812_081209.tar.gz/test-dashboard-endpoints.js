#!/usr/bin/env node

/**
 * Script per testare gli endpoint dashboard
 */

async function testDashboardEndpoints() {
  console.log('🧪 Testing Dashboard Endpoints...\n');

  try {
    // 1. Test login per ottenere token
    console.log('1. Testing login...');
const BASE_URL = 'http://localhost:4003';

    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      console.error('❌ Login failed:', loginResponse.status, loginResponse.statusText);
      return;
    }

    const loginData = await loginResponse.json();
    console.log('✅ Login successful');
    console.log('🔍 Login response structure:', JSON.stringify(loginData, null, 2));
    
    // Prova diversi campi per il token
    const token = loginData.token || loginData.accessToken || loginData.data?.token || loginData.data?.accessToken || loginData.tokens?.access_token;
    
    if (!token) {
      console.error('❌ No token found in login response');
      console.error('Available fields:', Object.keys(loginData));
      return;
    }

    console.log('🔑 Token obtained:', token.substring(0, 20) + '...\n');

    // 2. Test /api/dashboard/companies
    console.log('2. Testing /api/dashboard/companies...');
    const companiesResponse = await fetch(`${BASE_URL}/api/dashboard/companies`, {
       headers: {
         'Authorization': `Bearer ${token}`,
         'Content-Type': 'application/json',
         'x-tenant-id': 'e3e5d607-bd12-4d60-afbc-ea3b60abf11b'
       }
     });

    console.log('📊 Companies endpoint status:', companiesResponse.status);
    if (companiesResponse.ok) {
      const companiesData = await companiesResponse.json();
      console.log('✅ Companies data:', {
        count: Array.isArray(companiesData) ? companiesData.length : 'Not an array',
        sample: Array.isArray(companiesData) ? companiesData.slice(0, 2) : companiesData
      });
    } else {
      const errorText = await companiesResponse.text();
      console.error('❌ Companies error:', errorText);
    }

    // 3. Test /api/dashboard/employees
    console.log('\n3. Testing /api/dashboard/employees...');
    const employeesResponse = await fetch(`${BASE_URL}/api/dashboard/employees`, {
       headers: {
         'Authorization': `Bearer ${token}`,
         'Content-Type': 'application/json',
         'x-tenant-id': 'e3e5d607-bd12-4d60-afbc-ea3b60abf11b'
       }
     });

    console.log('👥 Employees endpoint status:', employeesResponse.status);
    if (employeesResponse.ok) {
      const employeesData = await employeesResponse.json();
      console.log('✅ Employees data:', {
        count: Array.isArray(employeesData) ? employeesData.length : 'Not an array',
        sample: Array.isArray(employeesData) ? employeesData.slice(0, 2) : employeesData
      });
    } else {
      const errorText = await employeesResponse.text();
      console.error('❌ Employees error:', errorText);
    }

    // 4. Test /api/dashboard/stats
    console.log('\n4. Testing /api/dashboard/stats...');
    const statsResponse = await fetch(`${BASE_URL}/api/dashboard/stats`, {
       headers: {
         'Authorization': `Bearer ${token}`,
         'Content-Type': 'application/json',
         'x-tenant-id': 'e3e5d607-bd12-4d60-afbc-ea3b60abf11b'
       }
     });

    console.log('📈 Stats endpoint status:', statsResponse.status);
    if (statsResponse.ok) {
      const statsData = await statsResponse.json();
      console.log('✅ Stats data:', statsData);
    } else {
      const errorText = await statsResponse.text();
      console.error('❌ Stats error:', errorText);
    }

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testDashboardEndpoints();