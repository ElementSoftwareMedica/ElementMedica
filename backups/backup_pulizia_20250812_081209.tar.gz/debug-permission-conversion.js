// Script per debuggare la conversione dei permessi
// Eseguire con: node debug-permission-conversion.js

// Simula i permessi backend dell'admin
const adminBackendPermissions = {
  // Permessi CMS
  'VIEW_CMS': true,
  'CREATE_CMS': true,
  'EDIT_CMS': true,
  'DELETE_CMS': true,
  'MANAGE_PUBLIC_CONTENT': true,
  'READ_PUBLIC_CONTENT': true,
  'VIEW_PUBLIC_CMS': true,
  'CREATE_PUBLIC_CMS': true,
  'EDIT_PUBLIC_CMS': true,
  'DELETE_PUBLIC_CMS': true,
  'MANAGE_PUBLIC_CMS': true,
  
  // Permessi Form Templates
  'VIEW_FORM_TEMPLATES': true,
  'CREATE_FORM_TEMPLATES': true,
  'EDIT_FORM_TEMPLATES': true,
  'DELETE_FORM_TEMPLATES': true,
  'MANAGE_FORM_TEMPLATES': true,
  
  // Permessi Form Submissions
  'VIEW_SUBMISSIONS': true,
  'VIEW_FORM_SUBMISSIONS': true,
  'CREATE_FORM_SUBMISSIONS': true,
  'EDIT_FORM_SUBMISSIONS': true,
  'DELETE_FORM_SUBMISSIONS': true,
  'MANAGE_SUBMISSIONS': true,
  'MANAGE_FORM_SUBMISSIONS': true,
  'EXPORT_SUBMISSIONS': true,
  'EXPORT_FORM_SUBMISSIONS': true,
  
  // Altri permessi
  'VIEW_COMPANIES': true,
  'VIEW_PERSONS': true,
  'ADMIN_PANEL': true
};

// Simula la funzione convertBackendToFrontendPermissions
function convertBackendToFrontendPermissions(backendPermissions) {
  const frontendPermissions = {};
  
  // Mantieni i permessi backend originali
  Object.keys(backendPermissions).forEach(key => {
    if (backendPermissions[key] === true) {
      frontendPermissions[key] = true;
    }
  });
  
  // Aggiungi le mappature frontend
  Object.keys(backendPermissions).forEach(backendKey => {
    if (backendPermissions[backendKey] === true) {
      // Caso speciale per MANAGE_PUBLIC_CONTENT -> PUBLIC_CMS
      if (backendKey === 'MANAGE_PUBLIC_CONTENT') {
        frontendPermissions['PUBLIC_CMS:READ'] = true;
        frontendPermissions['PUBLIC_CMS:CREATE'] = true;
        frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
        frontendPermissions['PUBLIC_CMS:DELETE'] = true;
        frontendPermissions['PUBLIC_CMS:read'] = true;
        frontendPermissions['PUBLIC_CMS:create'] = true;
        frontendPermissions['PUBLIC_CMS:update'] = true;
        frontendPermissions['PUBLIC_CMS:delete'] = true;
      }
      // Casi speciali per permessi CMS specifici
      else if (backendKey === 'VIEW_CMS') {
        frontendPermissions['PUBLIC_CMS:READ'] = true;
        frontendPermissions['PUBLIC_CMS:read'] = true;
      }
      else if (backendKey === 'CREATE_CMS') {
        frontendPermissions['PUBLIC_CMS:CREATE'] = true;
        frontendPermissions['PUBLIC_CMS:create'] = true;
      }
      else if (backendKey === 'EDIT_CMS') {
        frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
        frontendPermissions['PUBLIC_CMS:update'] = true;
      }
      else if (backendKey === 'DELETE_CMS') {
        frontendPermissions['PUBLIC_CMS:DELETE'] = true;
        frontendPermissions['PUBLIC_CMS:delete'] = true;
      }
      else if (backendKey === 'READ_PUBLIC_CONTENT') {
        frontendPermissions['PUBLIC_CMS:READ'] = true;
        frontendPermissions['PUBLIC_CMS:read'] = true;
      }
      // Permessi PUBLIC_CMS specifici
      else if (backendKey === 'VIEW_PUBLIC_CMS') {
        frontendPermissions['PUBLIC_CMS:READ'] = true;
        frontendPermissions['PUBLIC_CMS:read'] = true;
      }
      else if (backendKey === 'CREATE_PUBLIC_CMS') {
        frontendPermissions['PUBLIC_CMS:CREATE'] = true;
        frontendPermissions['PUBLIC_CMS:create'] = true;
      }
      else if (backendKey === 'EDIT_PUBLIC_CMS') {
        frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
        frontendPermissions['PUBLIC_CMS:update'] = true;
      }
      else if (backendKey === 'DELETE_PUBLIC_CMS') {
        frontendPermissions['PUBLIC_CMS:DELETE'] = true;
        frontendPermissions['PUBLIC_CMS:delete'] = true;
      }
      else if (backendKey === 'MANAGE_PUBLIC_CMS') {
        frontendPermissions['PUBLIC_CMS:READ'] = true;
        frontendPermissions['PUBLIC_CMS:read'] = true;
        frontendPermissions['PUBLIC_CMS:CREATE'] = true;
        frontendPermissions['PUBLIC_CMS:create'] = true;
        frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
        frontendPermissions['PUBLIC_CMS:update'] = true;
        frontendPermissions['PUBLIC_CMS:DELETE'] = true;
        frontendPermissions['PUBLIC_CMS:delete'] = true;
      }
      // Casi speciali per permessi FORM_TEMPLATES
      else if (backendKey === 'VIEW_FORM_TEMPLATES') {
        frontendPermissions['form_templates:read'] = true;
        frontendPermissions['form_templates:view'] = true;
      }
      else if (backendKey === 'CREATE_FORM_TEMPLATES') {
        frontendPermissions['form_templates:create'] = true;
      }
      else if (backendKey === 'EDIT_FORM_TEMPLATES') {
        frontendPermissions['form_templates:edit'] = true;
        frontendPermissions['form_templates:update'] = true;
      }
      else if (backendKey === 'DELETE_FORM_TEMPLATES') {
        frontendPermissions['form_templates:delete'] = true;
      }
      else if (backendKey === 'MANAGE_FORM_TEMPLATES') {
        frontendPermissions['form_templates:read'] = true;
        frontendPermissions['form_templates:view'] = true;
        frontendPermissions['form_templates:create'] = true;
        frontendPermissions['form_templates:edit'] = true;
        frontendPermissions['form_templates:update'] = true;
        frontendPermissions['form_templates:delete'] = true;
      }
      // Casi speciali per permessi FORM_SUBMISSIONS
      else if (backendKey === 'VIEW_SUBMISSIONS') {
        frontendPermissions['form_submissions:read'] = true;
        frontendPermissions['form_submissions:view'] = true;
        frontendPermissions['submissions:read'] = true;
        frontendPermissions['submissions:view'] = true;
      }
      else if (backendKey === 'MANAGE_SUBMISSIONS') {
        frontendPermissions['form_submissions:read'] = true;
        frontendPermissions['form_submissions:view'] = true;
        frontendPermissions['form_submissions:create'] = true;
        frontendPermissions['form_submissions:edit'] = true;
        frontendPermissions['form_submissions:update'] = true;
        frontendPermissions['form_submissions:delete'] = true;
        frontendPermissions['submissions:read'] = true;
        frontendPermissions['submissions:view'] = true;
        frontendPermissions['submissions:create'] = true;
        frontendPermissions['submissions:edit'] = true;
        frontendPermissions['submissions:update'] = true;
        frontendPermissions['submissions:delete'] = true;
      }
      else if (backendKey === 'VIEW_FORM_SUBMISSIONS') {
        frontendPermissions['form_submissions:read'] = true;
        frontendPermissions['form_submissions:view'] = true;
        frontendPermissions['submissions:read'] = true;
        frontendPermissions['submissions:view'] = true;
      }
      else if (backendKey === 'MANAGE_FORM_SUBMISSIONS') {
        frontendPermissions['form_submissions:read'] = true;
        frontendPermissions['form_submissions:view'] = true;
        frontendPermissions['form_submissions:create'] = true;
        frontendPermissions['form_submissions:edit'] = true;
        frontendPermissions['form_submissions:update'] = true;
        frontendPermissions['form_submissions:delete'] = true;
        frontendPermissions['submissions:read'] = true;
        frontendPermissions['submissions:view'] = true;
        frontendPermissions['submissions:create'] = true;
        frontendPermissions['submissions:edit'] = true;
        frontendPermissions['submissions:update'] = true;
        frontendPermissions['submissions:delete'] = true;
      }
      else if (backendKey === 'EXPORT_SUBMISSIONS') {
        frontendPermissions['form_submissions:export'] = true;
        frontendPermissions['submissions:export'] = true;
      }
      else if (backendKey === 'EXPORT_FORM_SUBMISSIONS') {
        frontendPermissions['form_submissions:export'] = true;
        frontendPermissions['submissions:export'] = true;
      }
    }
  });
  
  return frontendPermissions;
}

// Simula la funzione hasPermission
function hasPermission(permissions, resourceOrPermission, action) {
  let permissionToCheck;
  
  if (action) {
    permissionToCheck = `${resourceOrPermission}:${action}`;
  } else {
    permissionToCheck = resourceOrPermission;
  }
  
  // Verifica permesso diretto
  if (permissions[permissionToCheck] === true) {
    return true;
  }
  
  // Se abbiamo due parametri, prova anche altri formati
  if (action) {
    // Verifica permesso all:*
    if (permissions['all:' + action] === true) {
      return true;
    }
    
    // Verifica permesso resource:all
    if (permissions[resourceOrPermission + ':all'] === true) {
      return true;
    }
    
    // Per azioni di read, concedi accesso se c'è almeno un permesso per la risorsa
    if (action === 'read') {
      const resourcePermissions = Object.keys(permissions)
        .filter(key => key.startsWith(resourceOrPermission + ':') && permissions[key] === true);
      
      if (resourcePermissions.length > 0) {
        return true;
      }
    }
  }
  
  return false;
}

console.log('🔍 Debug Conversione Permessi');
console.log('=============================');

// Test conversione
const convertedPermissions = convertBackendToFrontendPermissions(adminBackendPermissions);

console.log('\n📋 Permessi Backend (input):');
Object.keys(adminBackendPermissions).forEach(key => {
  if (adminBackendPermissions[key]) {
    console.log(`  ✓ ${key}`);
  }
});

console.log('\n📋 Permessi Frontend (output):');
const frontendKeys = Object.keys(convertedPermissions).filter(key => convertedPermissions[key] === true);
console.log(`Totale: ${frontendKeys.length} permessi`);

// Filtra per categorie
const cmsPermissions = frontendKeys.filter(key => key.includes('CMS') || key.includes('PUBLIC'));
const formTemplatePermissions = frontendKeys.filter(key => key.includes('form_templates'));
const formSubmissionPermissions = frontendKeys.filter(key => key.includes('form_submissions') || key.includes('submissions'));

console.log('\n🏛️ Permessi CMS:');
cmsPermissions.forEach(perm => console.log(`  ✓ ${perm}`));

console.log('\n📝 Permessi Form Templates:');
formTemplatePermissions.forEach(perm => console.log(`  ✓ ${perm}`));

console.log('\n📊 Permessi Form Submissions:');
formSubmissionPermissions.forEach(perm => console.log(`  ✓ ${perm}`));

console.log('\n🧪 Test hasPermission:');
console.log('=====================');

// Test permessi specifici che dovrebbero funzionare
const testsToRun = [
  ['PUBLIC_CMS', 'READ'],
  ['PUBLIC_CMS', 'UPDATE'],
  ['form_templates', 'read'],
  ['form_templates', 'create'],
  ['form_templates', 'update'],
  ['form_templates', 'delete'],
  ['form_submissions', 'read'],
  ['form_submissions', 'update'],
  ['form_submissions', 'delete'],
  ['form_submissions', 'export']
];

testsToRun.forEach(([resource, action]) => {
  const result = hasPermission(convertedPermissions, resource, action);
  console.log(`${result ? '✅' : '❌'} hasPermission('${resource}', '${action}'): ${result}`);
});

console.log('\n🔍 Analisi Problemi:');
console.log('====================');

// Verifica se i permessi chiave sono presenti
const keyPermissions = [
  'PUBLIC_CMS:READ',
  'PUBLIC_CMS:UPDATE',
  'form_templates:read',
  'form_submissions:read'
];

keyPermissions.forEach(perm => {
  const hasIt = convertedPermissions[perm] === true;
  console.log(`${hasIt ? '✅' : '❌'} ${perm}: ${hasIt}`);
});

console.log('\n💡 Se tutti i test sono ✅ ma le pagine non funzionano,');
console.log('   il problema potrebbe essere nel caricamento dei permessi dal backend.');