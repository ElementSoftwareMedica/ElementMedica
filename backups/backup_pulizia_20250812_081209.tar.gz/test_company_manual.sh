#!/bin/bash

# Test Manuale per Ripristino Aziende e Gestione JSON
# Eseguire quando i server sono attivi (API: 4001, Proxy: 4003)

echo "🧪 === TEST MANUALE AZIENDE ==="
echo ""

# Configurazione
API_BASE="http://localhost:4003"
CREDENTIALS='{"identifier":"admin@example.com","password":"Admin123!"}'

echo "📡 1. Test connessione server..."
curl -s -o /dev/null -w "Proxy (4003): %{http_code}\n" http://localhost:4003/health
curl -s -o /dev/null -w "API (4001): %{http_code}\n" http://localhost:4001/health
echo ""

echo "🔐 2. Login e ottenimento token..."
LOGIN_RESPONSE=$(curl -s -X POST "${API_BASE}/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d "${CREDENTIALS}")

echo "Login response: $LOGIN_RESPONSE"

# Estrai token (richiede jq installato, altrimenti copiare manualmente)
if command -v jq &> /dev/null; then
  TOKEN=$(echo "$LOGIN_RESPONSE" | jq -r '.token')
  echo "Token estratto: ${TOKEN:0:20}..."
else
  echo "⚠️ jq non installato. Copia manualmente il token dalla risposta sopra."
  echo "Inserisci il token:"
  read TOKEN
fi

if [ "$TOKEN" = "null" ] || [ -z "$TOKEN" ]; then
  echo "❌ Token non valido. Verifica credenziali e server."
  exit 1
fi

echo ""
echo "🏢 3. Creazione azienda di test..."
COMPANY_DATA='{
  "ragioneSociale": "Test Ripristino SRL",
  "piva": "99887766554",
  "codiceFiscale": "TSTRIPRIST01",
  "indirizzo": "Via Test 123",
  "citta": "Milano",
  "cap": "20100",
  "provincia": "MI"
}'

CREATE_RESPONSE=$(curl -s -X POST "${API_BASE}/api/v1/companies" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d "$COMPANY_DATA")

echo "Creazione response: $CREATE_RESPONSE"

if command -v jq &> /dev/null; then
  COMPANY_ID=$(echo "$CREATE_RESPONSE" | jq -r '.id')
  echo "ID azienda creata: $COMPANY_ID"
else
  echo "⚠️ Copia manualmente l'ID dell'azienda dalla risposta sopra."
  echo "Inserisci l'ID dell'azienda:"
  read COMPANY_ID
fi

if [ "$COMPANY_ID" = "null" ] || [ -z "$COMPANY_ID" ]; then
  echo "❌ Creazione azienda fallita."
  exit 1
fi

echo ""
echo "🗑️ 4. Eliminazione azienda (soft delete)..."
DELETE_RESPONSE=$(curl -s -X DELETE "${API_BASE}/api/v1/companies/$COMPANY_ID" \
  -H "Authorization: Bearer $TOKEN")

echo "Eliminazione response: $DELETE_RESPONSE"

# Verifica che la risposta sia JSON valido
if command -v jq &> /dev/null; then
  if echo "$DELETE_RESPONSE" | jq . > /dev/null 2>&1; then
    echo "✅ Risposta JSON valida per DELETE"
  else
    echo "❌ Risposta JSON NON valida per DELETE"
  fi
fi

echo ""
echo "🔄 5. Ricreazione azienda con stessa P.IVA (test ripristino)..."
UPDATED_COMPANY_DATA='{
  "ragioneSociale": "Test Ripristino SRL - RIPRISTINATA",
  "piva": "99887766554",
  "codiceFiscale": "TSTRIPRIST01",
  "indirizzo": "Via Test Nuova 456",
  "citta": "Roma",
  "cap": "00100",
  "provincia": "RM"
}'

RESTORE_RESPONSE=$(curl -s -X POST "${API_BASE}/api/v1/companies" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d "$UPDATED_COMPANY_DATA")

echo "Ripristino response: $RESTORE_RESPONSE"

if command -v jq &> /dev/null; then
  RESTORED_ID=$(echo "$RESTORE_RESPONSE" | jq -r '.id')
  RESTORED_NAME=$(echo "$RESTORE_RESPONSE" | jq -r '.ragioneSociale')
  RESTORED_CITY=$(echo "$RESTORE_RESPONSE" | jq -r '.citta')
  
  echo ""
  echo "📊 === RISULTATI TEST ==="
  echo "ID originale: $COMPANY_ID"
  echo "ID ripristinato: $RESTORED_ID"
  echo "Nome aggiornato: $RESTORED_NAME"
  echo "Città aggiornata: $RESTORED_CITY"
  
  if [ "$COMPANY_ID" = "$RESTORED_ID" ]; then
    echo "🎉 SUCCESSO: Ripristino avvenuto correttamente (stesso ID)"
  else
    echo "❌ FALLIMENTO: ID diverso, potrebbe essere stata creata nuova azienda"
  fi
else
  echo "⚠️ Verifica manualmente che l'ID sia lo stesso e i dati siano aggiornati"
fi

echo ""
echo "🧪 === FINE TEST ==="
echo ""
echo "📋 Checklist manuale:"
echo "- [ ] Login funziona"
echo "- [ ] Creazione azienda funziona"
echo "- [ ] Eliminazione restituisce JSON valido"
echo "- [ ] Ricreazione con stessa P.IVA ripristina (stesso ID)"
echo "- [ ] Dati aggiornati correttamente"