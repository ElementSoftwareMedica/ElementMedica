#!/usr/bin/env node

/**
 * Test per verificare la persistenza dei permessi nei ruoli
 * Questo script testa il salvataggio e il caricamento dei permessi
 */

import fetch from 'node-fetch';
import fs from 'fs';

const API_BASE = 'http://localhost:4001';
const PROXY_BASE = 'http://localhost:4003';

// Leggi il token dal file temporaneo
let token;
try {
  const loginData = JSON.parse(fs.readFileSync('/Users/matteo.michielon/project 2.0/temp_login.json', 'utf8'));
  token = loginData.tokens.access_token;
  console.log('✅ Token caricato dal file temporaneo');
} catch (error) {
  console.error('❌ Errore nel caricamento del token:', error.message);
  process.exit(1);
}

async function testPermissionsPersistence() {
  console.log('\n🧪 Test di persistenza dei permessi\n');

  try {
    // 1. Ottieni i permessi attuali del ruolo ADMIN
    console.log('1️⃣ Caricamento permessi attuali del ruolo ADMIN...');
    const currentPermissionsResponse = await fetch(`${API_BASE}/api/v1/roles/ADMIN/permissions`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!currentPermissionsResponse.ok) {
      throw new Error(`Errore nel caricamento permessi: ${currentPermissionsResponse.status}`);
    }

    const currentPermissionsData = await currentPermissionsResponse.json();
    console.log('✅ Permessi attuali caricati:', {
      success: currentPermissionsData.success,
      permissionsCount: currentPermissionsData.data?.permissions?.length || 0
    });

    // 2. Prepara un set di permessi di test
    const testPermissions = [
      {
        permissionId: 'VIEW_COMPANIES',
        granted: true,
        scope: 'all',
        tenantIds: [],
        fieldRestrictions: []
      },
      {
        permissionId: 'CREATE_COMPANIES',
        granted: true,
        scope: 'all',
        tenantIds: [],
        fieldRestrictions: []
      },
      {
        permissionId: 'EDIT_COMPANIES',
        granted: true,
        scope: 'all',
        tenantIds: [],
        fieldRestrictions: []
      },
      {
        permissionId: 'DELETE_COMPANIES',
        granted: true,
        scope: 'all',
        tenantIds: [],
        fieldRestrictions: []
      },
      {
        permissionId: 'VIEW_COURSES',
        granted: true,
        scope: 'all',
        tenantIds: [],
        fieldRestrictions: []
      },
      {
        permissionId: 'CREATE_COURSES',
        granted: true,
        scope: 'all',
        tenantIds: [],
        fieldRestrictions: []
      }
    ];

    console.log('\n2️⃣ Salvataggio permessi di test...');
    const saveResponse = await fetch(`${API_BASE}/api/v1/roles/ADMIN/permissions`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(testPermissions)
    });

    if (!saveResponse.ok) {
      const errorText = await saveResponse.text();
      throw new Error(`Errore nel salvataggio: ${saveResponse.status} - ${errorText}`);
    }

    const saveData = await saveResponse.json();
    console.log('✅ Permessi salvati:', {
      success: saveData.success,
      message: saveData.message,
      permissionsCount: saveData.data?.permissionsCount
    });

    // 3. Attendi un momento per assicurarsi che il salvataggio sia completato
    console.log('\n⏳ Attesa 2 secondi per il completamento del salvataggio...');
    await new Promise(resolve => setTimeout(resolve, 2000));

    // 4. Ricarica i permessi per verificare la persistenza
    console.log('\n3️⃣ Verifica della persistenza - ricaricamento permessi...');
    const verifyResponse = await fetch(`${API_BASE}/api/v1/roles/ADMIN/permissions`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!verifyResponse.ok) {
      throw new Error(`Errore nella verifica: ${verifyResponse.status}`);
    }

    const verifyData = await verifyResponse.json();
    console.log('✅ Permessi ricaricati:', {
      success: verifyData.success,
      permissionsCount: verifyData.data?.permissions?.length || 0
    });

    // 5. Confronta i permessi salvati con quelli ricaricati
    const savedPermissionIds = testPermissions.filter(p => p.granted).map(p => p.permissionId);
    const loadedPermissionIds = verifyData.data?.permissions?.filter(p => p.granted).map(p => p.permissionId) || [];

    console.log('\n4️⃣ Confronto permessi:');
    console.log('Permessi salvati:', savedPermissionIds);
    console.log('Permessi ricaricati:', loadedPermissionIds);

    const missingPermissions = savedPermissionIds.filter(id => !loadedPermissionIds.includes(id));
    const extraPermissions = loadedPermissionIds.filter(id => !savedPermissionIds.includes(id));

    if (missingPermissions.length === 0 && extraPermissions.length === 0) {
      console.log('✅ SUCCESSO: Tutti i permessi sono stati salvati e ricaricati correttamente!');
    } else {
      console.log('❌ PROBLEMA: Discrepanza nei permessi:');
      if (missingPermissions.length > 0) {
        console.log('  Permessi mancanti:', missingPermissions);
      }
      if (extraPermissions.length > 0) {
        console.log('  Permessi extra:', extraPermissions);
      }
    }

    // 6. Test con il proxy server (come fa il frontend)
    console.log('\n5️⃣ Test tramite proxy server (come fa il frontend)...');
    const proxyResponse = await fetch(`${PROXY_BASE}/api/roles/ADMIN/permissions`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!proxyResponse.ok) {
      throw new Error(`Errore nel proxy: ${proxyResponse.status}`);
    }

    const proxyData = await proxyResponse.json();
    console.log('✅ Permessi dal proxy:', {
      success: proxyData.success,
      permissionsCount: proxyData.data?.permissions?.length || 0
    });

    const proxyPermissionIds = proxyData.data?.permissions?.filter(p => p.granted).map(p => p.permissionId) || [];
    console.log('Permessi dal proxy:', proxyPermissionIds);

    if (JSON.stringify(loadedPermissionIds.sort()) === JSON.stringify(proxyPermissionIds.sort())) {
      console.log('✅ SUCCESSO: I permessi dal proxy corrispondono a quelli diretti!');
    } else {
      console.log('❌ PROBLEMA: Discrepanza tra API diretta e proxy');
    }

  } catch (error) {
    console.error('❌ Errore nel test:', error.message);
    process.exit(1);
  }
}

// Esegui il test
testPermissionsPersistence();