#!/usr/bin/env node

/**
 * Test completo del flusso permessi per le nuove entità
 * Verifica: salvataggio → caricamento → mappatura → hasPermission
 */

const axios = require('axios');

const PROXY_BASE = 'http://localhost:4003';
const API_BASE = 'http://localhost:4001';

// Credenziali admin
const credentials = {
  identifier: 'admin@example.com',
  password: 'Admin123!'
};

let authToken = null;
let loginData = null;

async function login() {
  try {
    console.log('🔐 Effettuando login...');
    const response = await axios.post(`${PROXY_BASE}/api/v1/auth/login`, credentials);
    
    console.log('📄 Risposta login:', JSON.stringify(response.data, null, 2));
    
    // Salva la risposta del login
    loginData = response;
    
    // Prova diversi formati di risposta
    if (response.data.success && response.data.tokens && response.data.tokens.access_token) {
      authToken = response.data.tokens.access_token;
      console.log('✅ Login effettuato con successo (formato tokens.access_token)');
      return true;
    } else if (response.data.success && response.data.data && response.data.data.token) {
      authToken = response.data.data.token;
      console.log('✅ Login effettuato con successo (formato data.token)');
      return true;
    } else if (response.data.token) {
      authToken = response.data.token;
      console.log('✅ Login effettuato con successo (formato token)');
      return true;
    } else if (response.data.access_token) {
      authToken = response.data.access_token;
      console.log('✅ Login effettuato con successo (formato access_token)');
      return true;
    } else {
      console.error('❌ Login fallito: token non trovato');
      return false;
    }
  } catch (error) {
    console.error('❌ Errore durante il login:', error.message);
    if (error.response) {
      console.error('📄 Dettagli errore:', error.response.data);
    }
    return false;
  }
}

async function testPermissionFlow() {
  try {
    console.log('\n🧪 FASE 1: Verifica permessi utente corrente');
    
    // 1. Ottieni permessi utente corrente usando l'ID dal login
      const userId = loginData.data.user.id;
      console.log('👤 ID utente:', userId);
     
     // Prova prima il proxy, poi l'API diretta
     let permissionsResponse;
     try {
       console.log('🔍 Tentativo con proxy...');
       permissionsResponse = await axios.get(`${PROXY_BASE}/api/v1/auth/permissions/${userId}`, {
         headers: { 'Authorization': `Bearer ${authToken}` }
       });
     } catch (proxyError) {
       console.log('❌ Proxy fallito, provo API diretta...');
       console.log('📄 Errore proxy:', proxyError.message);
       
       permissionsResponse = await axios.get(`${API_BASE}/api/v1/auth/permissions/${userId}`, {
         headers: { 'Authorization': `Bearer ${authToken}` }
       });
     }
    
    console.log('📊 Risposta permessi:', {
      success: permissionsResponse.data.success,
      permissionsCount: Object.keys(permissionsResponse.data.data.permissions || {}).length
    });
    
    const permissions = permissionsResponse.data.data.permissions || {};
    
    // 2. Verifica permessi specifici per le nuove entità
    console.log('\n🔍 FASE 2: Verifica permessi specifici');
    
    const testPermissions = [
      // Form Templates
      'form_templates:read',
      'form_templates:create', 
      'form_templates:update',
      'form_templates:delete',
      'VIEW_FORM_TEMPLATES',
      'CREATE_FORM_TEMPLATES',
      'EDIT_FORM_TEMPLATES',
      'DELETE_FORM_TEMPLATES',
      
      // Form Submissions
      'form_submissions:read',
      'form_submissions:update',
      'form_submissions:delete',
      'VIEW_FORM_SUBMISSIONS',
      'EDIT_FORM_SUBMISSIONS',
      'DELETE_FORM_SUBMISSIONS',
      
      // Public CMS
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE',
      'PUBLIC_CMS:CREATE',
      'PUBLIC_CMS:DELETE',
      'VIEW_PUBLIC_CMS',
      'EDIT_PUBLIC_CMS',
      'CREATE_PUBLIC_CMS',
      'DELETE_PUBLIC_CMS',
      'MANAGE_PUBLIC_CMS'
    ];
    
    console.log('📋 Permessi trovati:');
    testPermissions.forEach(perm => {
      const hasPermission = permissions[perm] === true;
      console.log(`  ${hasPermission ? '✅' : '❌'} ${perm}: ${permissions[perm]}`);
    });
    
    // 3. Simula la logica hasPermission del frontend
    console.log('\n🎯 FASE 3: Simulazione hasPermission frontend');
    
    function simulateHasPermission(resource, action) {
      console.log(`\n🔍 hasPermission('${resource}', '${action}')`);
      
      // Formato diretto (es: form_templates:read)
      const directFormat = `${resource}:${action}`;
      if (permissions[directFormat] === true) {
        console.log(`  ✅ Trovato formato diretto: ${directFormat}`);
        return true;
      }
      
      // Formato maiuscolo (es: PUBLIC_CMS:READ)
      const upperFormat = `${resource.toUpperCase()}:${action.toUpperCase()}`;
      if (permissions[upperFormat] === true) {
        console.log(`  ✅ Trovato formato maiuscolo: ${upperFormat}`);
        return true;
      }
      
      // Formato backend (es: VIEW_FORM_TEMPLATES)
      const actionMap = {
        'read': 'VIEW_',
        'create': 'CREATE_',
        'update': 'EDIT_',
        'delete': 'DELETE_'
      };
      
      const entityMap = {
        'form_templates': 'FORM_TEMPLATES',
        'form_submissions': 'FORM_SUBMISSIONS',
        'PUBLIC_CMS': 'PUBLIC_CMS'
      };
      
      const actionPrefix = actionMap[action] || 'VIEW_';
      const entityName = entityMap[resource] || resource.toUpperCase();
      const backendFormat = `${actionPrefix}${entityName}`;
      
      if (permissions[backendFormat] === true) {
        console.log(`  ✅ Trovato formato backend: ${backendFormat}`);
        return true;
      }
      
      // Permessi universali
      const universalAction = `all:${action}`;
      if (permissions[universalAction] === true) {
        console.log(`  ✅ Trovato permesso universale: ${universalAction}`);
        return true;
      }
      
      const resourceAll = `${resource}:all`;
      if (permissions[resourceAll] === true) {
        console.log(`  ✅ Trovato permesso risorsa completa: ${resourceAll}`);
        return true;
      }
      
      console.log(`  ❌ Nessun permesso trovato per ${resource}:${action}`);
      console.log(`    Formati testati: ${directFormat}, ${upperFormat}, ${backendFormat}, ${universalAction}, ${resourceAll}`);
      return false;
    }
    
    // Test per le pagine specifiche
    const pageTests = [
      { page: 'FormTemplatesPage', resource: 'form_templates', action: 'read' },
      { page: 'FormTemplatesPage', resource: 'form_templates', action: 'update' },
      { page: 'FormSubmissionsPage', resource: 'form_submissions', action: 'read' },
      { page: 'FormSubmissionsPage', resource: 'form_submissions', action: 'update' },
      { page: 'PublicCMSPage', resource: 'PUBLIC_CMS', action: 'READ' },
      { page: 'PublicCMSPage', resource: 'PUBLIC_CMS', action: 'UPDATE' }
    ];
    
    console.log('\n📄 Test accesso pagine:');
    pageTests.forEach(test => {
      const hasAccess = simulateHasPermission(test.resource, test.action);
      console.log(`${hasAccess ? '✅' : '❌'} ${test.page}: ${test.resource}:${test.action}`);
    });
    
    // 4. Verifica ruoli utente
    console.log('\n👤 FASE 4: Verifica ruoli utente');
    
    const userResponse = await axios.get(`${PROXY_BASE}/api/v1/auth/me`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    
    if (userResponse.data.success) {
      const user = userResponse.data.data;
      console.log('👤 Dati utente:', {
        id: user.id,
        email: user.email,
        role: user.role,
        roles: user.roles,
        isAdmin: user.isAdmin
      });
    }
    
  } catch (error) {
    console.error('❌ Errore nel test:', error.message);
    if (error.response) {
      console.error('📄 Dettagli errore:', error.response.data);
    }
  }
}

async function main() {
  console.log('🚀 Test Flusso Permessi - Debug Completo');
  console.log('=====================================');
  
  if (await login()) {
    await testPermissionFlow();
  }
  
  console.log('\n✅ Test completato');
}

main().catch(console.error);