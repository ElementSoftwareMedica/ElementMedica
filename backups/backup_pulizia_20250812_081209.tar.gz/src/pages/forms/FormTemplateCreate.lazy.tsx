import { lazy } from 'react';

export const FormTemplateCreateLazy = lazy(() => import('./FormTemplateCreate'));