const axios = require('axios');

const API_BASE = 'http://localhost:4001';

async function testAdminPermissions() {
  try {
    console.log('🔐 Testing admin permissions...');
    
    // 1. Login as admin
    console.log('\n1️⃣ Login as admin...');
    const loginResponse = await axios.post(`${API_BASE}/api/v1/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    console.log('✅ Login successful');
    console.log('📊 Login response structure:', JSON.stringify(loginResponse.data, null, 2));
    
    // Handle different response structures
    const token = loginResponse.data.tokens?.access_token || loginResponse.data.access_token || loginResponse.data.data?.access_token;
    const userId = loginResponse.data.user?.id || loginResponse.data.data?.user?.id;
    
    console.log('🔑 Token:', token ? 'Found' : 'Not found');
    console.log('👤 User ID:', userId);
    
    // 2. Get user permissions
    console.log('\n2️⃣ Getting user permissions...');
    const permissionsResponse = await axios.get(`${API_BASE}/api/v1/auth/permissions/${userId}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Permissions retrieved successfully');
    console.log('📊 User role:', permissionsResponse.data.data.role);
    console.log('📊 Total permissions:', Object.keys(permissionsResponse.data.data.permissions).length);
    
    // 3. Check specific permissions for new entities
    const permissions = permissionsResponse.data.data.permissions;
    
    console.log('\n3️⃣ Checking specific permissions...');
    
    // Form Templates permissions
    const formTemplatesPermissions = Object.keys(permissions).filter(p => p.includes('form_templates'));
    console.log('📋 Form Templates permissions:', formTemplatesPermissions.length);
    formTemplatesPermissions.forEach(p => console.log(`  - ${p}: ${permissions[p]}`));
    
    // Form Submissions permissions
    const formSubmissionsPermissions = Object.keys(permissions).filter(p => p.includes('form_submissions'));
    console.log('📋 Form Submissions permissions:', formSubmissionsPermissions.length);
    formSubmissionsPermissions.forEach(p => console.log(`  - ${p}: ${permissions[p]}`));
    
    // Public CMS permissions
    const publicCmsPermissions = Object.keys(permissions).filter(p => p.includes('PUBLIC_CMS'));
    console.log('📋 Public CMS permissions:', publicCmsPermissions.length);
    publicCmsPermissions.forEach(p => console.log(`  - ${p}: ${permissions[p]}`));
    
    // 4. Test hasPermission logic simulation
    console.log('\n4️⃣ Testing hasPermission logic...');
    
    function simulateHasPermission(resource, action) {
      const permissionKey = `${resource}:${action}`;
      const altPermissionKey = `${resource.toUpperCase()}:${action.toUpperCase()}`;
      return permissions[permissionKey] === true || permissions[altPermissionKey] === true;
    }
    
    const testCases = [
      { resource: 'form_templates', action: 'read' },
      { resource: 'form_templates', action: 'create' },
      { resource: 'form_submissions', action: 'read' },
      { resource: 'form_submissions', action: 'update' },
      { resource: 'PUBLIC_CMS', action: 'READ' },
      { resource: 'PUBLIC_CMS', action: 'UPDATE' }
    ];
    
    testCases.forEach(test => {
      const hasPermission = simulateHasPermission(test.resource, test.action);
      console.log(`  ${hasPermission ? '✅' : '❌'} ${test.resource}:${test.action} = ${hasPermission}`);
    });
    
    console.log('\n✅ Test completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
  }
}

testAdminPermissions();