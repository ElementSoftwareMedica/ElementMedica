import { lazy } from 'react';

export const FormTemplateEditLazy = lazy(() => import('./FormTemplateEdit'));