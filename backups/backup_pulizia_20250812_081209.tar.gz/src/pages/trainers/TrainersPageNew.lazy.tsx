import { lazy } from 'react';

const TrainersPageNewLazy = lazy(() => import('./TrainersPageNew'));

export default TrainersPageNewLazy;