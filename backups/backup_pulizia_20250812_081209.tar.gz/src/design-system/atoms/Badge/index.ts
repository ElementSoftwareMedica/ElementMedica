/**
 * Design System - Badge Component Export
 */

export { Badge, type BadgeProps, type BadgeVariant, type BadgeSize } from './Badge';
export { default } from './Badge';