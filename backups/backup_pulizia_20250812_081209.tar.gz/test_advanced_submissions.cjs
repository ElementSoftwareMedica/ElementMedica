const axios = require('axios');

async function testAdvancedSubmissions() {
  try {
    console.log('🔍 Testing /api/v1/submissions/advanced endpoint...\n');
    
    // 1. Login to get token
    console.log('1. Login...');
    const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    const token = loginResponse.data.tokens.access_token;
    console.log('✅ Login successful, token obtained');
    
    // 2. Test advanced submissions endpoint
    console.log('\n2. Testing /api/v1/submissions/advanced...');
    const advancedResponse = await axios.get('http://localhost:4003/api/v1/submissions/advanced', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Advanced submissions endpoint successful!');
    console.log('📊 Status:', advancedResponse.status);
    console.log('📄 Response:', JSON.stringify(advancedResponse.data, null, 2));
    
  } catch (error) {
    console.error('❌ Test failed');
    console.error('Status:', error.response?.status);
    console.error('Error data:', error.response?.data);
    console.error('Error message:', error.message);
  }
}

testAdvancedSubmissions();