const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.sqlite');

console.log('🔍 Verifica permessi per admin@example.com...\n');

db.serialize(() => {
  // Prima trova l'utente admin
  db.get('SELECT id, email, role FROM persons WHERE email = ?', ['admin@example.com'], (err, person) => {
    if (err) {
      console.error('❌ Errore nel trovare l\'utente:', err);
      return;
    }
    
    if (!person) {
      console.log('❌ Utente admin@example.com non trovato');
      return;
    }
    
    console.log('👤 Utente trovato:', person);
    
    // Trova il ruolo della persona
    db.get('SELECT id, name FROM person_roles WHERE personId = ?', [person.id], (err, role) => {
      if (err) {
        console.error('❌ Errore nel trovare il ruolo:', err);
        return;
      }
      
      if (!role) {
        console.log('❌ Ruolo non trovato per l\'utente');
        return;
      }
      
      console.log('🎭 Ruolo trovato:', role);
      
      // Trova tutti i permessi del ruolo
      db.all('SELECT permission, isGranted FROM person_role_permissions WHERE personRoleId = ?', [role.id], (err, permissions) => {
        if (err) {
          console.error('❌ Errore nel trovare i permessi:', err);
          return;
        }
        
        console.log('\n📋 Permessi trovati (' + permissions.length + ' totali):');
        
        const grantedPermissions = permissions.filter(p => p.isGranted);
        const deniedPermissions = permissions.filter(p => !p.isGranted);
        
        console.log('\n✅ Permessi concessi (' + grantedPermissions.length + '):');
        grantedPermissions.forEach(p => console.log('  - ' + p.permission));
        
        if (deniedPermissions.length > 0) {
          console.log('\n❌ Permessi negati (' + deniedPermissions.length + '):');
          deniedPermissions.forEach(p => console.log('  - ' + p.permission));
        }
        
        // Verifica specificamente i permessi che ci interessano
        const cmsPermissions = grantedPermissions.filter(p => p.permission.includes('CMS') || p.permission.includes('cms'));
        const formTemplatePermissions = grantedPermissions.filter(p => p.permission.includes('FORM_TEMPLATE') || p.permission.includes('form_template'));
        const formSubmissionPermissions = grantedPermissions.filter(p => p.permission.includes('SUBMISSION') || p.permission.includes('submission'));
        
        console.log('\n🎯 Permessi CMS (' + cmsPermissions.length + '):');
        cmsPermissions.forEach(p => console.log('  - ' + p.permission));
        
        console.log('\n📝 Permessi Form Templates (' + formTemplatePermissions.length + '):');
        formTemplatePermissions.forEach(p => console.log('  - ' + p.permission));
        
        console.log('\n📊 Permessi Form Submissions (' + formSubmissionPermissions.length + '):');
        formSubmissionPermissions.forEach(p => console.log('  - ' + p.permission));
        
        db.close();
      });
    });
  });
});