const axios = require('axios');

async function testEntitiesEndpoint() {
  try {
    console.log('🔍 Testing entities endpoint...');
    
    // Step 1: Login
    console.log('📝 Logging in...');
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    const token = loginResponse.data.token;
    console.log('✅ Login successful');
    
    // Step 2: Test entities endpoint
    console.log('🔍 Testing /api/v1/advanced-permissions/entities...');
    const entitiesResponse = await axios.get('http://localhost:4001/api/v1/advanced-permissions/entities', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Entities endpoint response:');
    console.log('Status:', entitiesResponse.status);
    console.log('Success:', entitiesResponse.data.success);
    console.log('Total entities:', entitiesResponse.data.entities?.length || 0);
    
    // Check for specific entities
    const entities = entitiesResponse.data.entities || [];
    const formTemplates = entities.find(e => e.id === 'form_templates');
    const formSubmissions = entities.find(e => e.id === 'form_submissions');
    const publicCms = entities.find(e => e.id === 'public_cms');
    
    console.log('\n📋 Checking specific entities:');
    console.log('form_templates:', formTemplates ? '✅ Found' : '❌ Missing');
    console.log('form_submissions:', formSubmissions ? '✅ Found' : '❌ Missing');
    console.log('public_cms:', publicCms ? '✅ Found' : '❌ Missing');
    
    if (formTemplates) {
      console.log('form_templates displayName:', formTemplates.displayName);
    }
    if (formSubmissions) {
      console.log('form_submissions displayName:', formSubmissions.displayName);
    }
    if (publicCms) {
      console.log('public_cms displayName:', publicCms.displayName);
    }
    
    // List all entity names
    console.log('\n📝 All entities:');
    entities.forEach((entity, index) => {
      console.log(`${index + 1}. ${entity.id} (${entity.displayName})`);
    });
    
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
    if (error.response?.status) {
      console.error('Status:', error.response.status);
    }
  }
}

testEntitiesEndpoint();