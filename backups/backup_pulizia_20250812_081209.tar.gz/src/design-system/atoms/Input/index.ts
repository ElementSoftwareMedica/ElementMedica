/**
 * Design System - Input Index
 * Week 8 Implementation - Component Library
 */

export { Input, type InputProps, type InputVariant, type InputSize, type InputState } from './Input';
export { default } from './Input';