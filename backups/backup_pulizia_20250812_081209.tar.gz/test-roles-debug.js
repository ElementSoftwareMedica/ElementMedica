const fetch = require('node-fetch');

async function testRoles() {
  try {
    console.log('🔍 Testing roles endpoint...');
    
    // Prima faccio login per ottenere il token
    const loginResponse = await fetch('http://localhost:4003/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });
    
    const loginData = await loginResponse.json();
    console.log('Login response:', loginData.success ? 'SUCCESS' : 'FAILED');
    
    if (!loginData.success) {
      console.error('Login failed:', loginData.error);
      return;
    }
    
    const token = loginData.data.token;
    
    // Ora testo l'endpoint dei ruoli
    const rolesResponse = await fetch('http://localhost:4003/api/roles', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    const rolesData = await rolesResponse.json();
    console.log('\n📊 Roles endpoint response:');
    console.log('Success:', rolesData.success);
    
    if (rolesData.success && rolesData.data) {
      console.log('Total roles found:', rolesData.data.length);
      console.log('\nRoles list:');
      rolesData.data.forEach((role, index) => {
        console.log(`${index + 1}. ${role.roleType} (ID: ${role.id})`);
        if (role.name) console.log(`   Name: ${role.name}`);
        if (role.description) console.log(`   Description: ${role.description}`);
        console.log(`   Active: ${role.isActive}`);
        console.log('');
      });
    } else {
      console.error('Failed to get roles:', rolesData.error);
    }
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

testRoles();