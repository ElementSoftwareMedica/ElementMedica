#!/usr/bin/env node

/**
 * Script di debug semplificato per verificare i permessi
 */

const axios = require('axios');

const PROXY_BASE = 'http://localhost:4003';
const API_BASE_URL = 'http://localhost:4001/api/v1';

// Credenziali admin
const ADMIN_CREDENTIALS = {
  identifier: 'admin@example.com',
  password: 'Admin123!'
};

let authToken = null;
let userId = null;

async function login() {
  try {
    console.log('🔐 Effettuando login...');
    const response = await axios.post(`${PROXY_BASE}/api/v1/auth/login`, ADMIN_CREDENTIALS);

    console.log('📋 Risposta login:', JSON.stringify(response.data, null, 2));

    // Prova diverse strutture di risposta
     let token = null;
     let user = null;

     if (response.data.success && response.data.tokens?.access_token) {
       token = response.data.tokens.access_token;
       user = response.data.user;
     } else if (response.data.success && response.data.data?.token) {
       token = response.data.data.token;
       user = response.data.data.user;
     } else if (response.data.token) {
       token = response.data.token;
       user = response.data.user;
     } else if (response.data.access_token) {
       token = response.data.access_token;
       user = response.data.user;
     }

    if (!token) {
      throw new Error('Token non trovato nella risposta: ' + JSON.stringify(response.data));
    }

    // Estrai l'ID dell'utente
    userId = user?.id || user?.personId || user?.userId || 'person-admin-001';

    authToken = token;
    console.log('✅ Login successful');
    console.log('👤 User:', user?.email || user?.identifier || 'N/A');
    console.log('🆔 User ID:', userId);
    return authToken;
  } catch (error) {
    console.error('❌ Login failed:', error.response?.data || error.message);
    throw error;
  }
}

async function checkPermissions() {
  try {
    console.log('\n📊 Verificando permessi...');
    
    const response = await axios.get(`${PROXY_BASE}/api/v1/auth/permissions/${userId}`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });
    
    if (response.data.success) {
      const permissions = response.data.permissions;
      console.log('📋 Permessi caricati:', Object.keys(permissions).length);
      
      // Verifica permessi specifici per le pagine problematiche
      const targetPermissions = [
        'form_templates:read',
        'form_templates:create', 
        'form_templates:update',
        'form_templates:delete',
        'form_submissions:read',
        'form_submissions:update',
        'form_submissions:delete',
        'form_submissions:export',
        'PUBLIC_CMS:READ',
        'PUBLIC_CMS:UPDATE',
        // Varianti alternative
        'VIEW_FORM_TEMPLATES',
        'CREATE_FORM_TEMPLATES',
        'EDIT_FORM_TEMPLATES',
        'DELETE_FORM_TEMPLATES',
        'VIEW_FORM_SUBMISSIONS',
        'EDIT_FORM_SUBMISSIONS',
        'DELETE_FORM_SUBMISSIONS',
        'VIEW_PUBLIC_CMS',
        'EDIT_PUBLIC_CMS'
      ];
      
      console.log('\n🎯 Permessi per pagine problematiche:');
      targetPermissions.forEach(perm => {
        const hasPermission = permissions[perm] === true;
        console.log(`  ${hasPermission ? '✅' : '❌'} ${perm}`);
      });
      
      // Mostra tutti i permessi che iniziano con form_ o PUBLIC_CMS
      console.log('\n🔍 Tutti i permessi form/CMS trovati:');
      Object.keys(permissions).forEach(key => {
        if (key.toLowerCase().includes('form') || key.includes('PUBLIC_CMS') || key.includes('CMS')) {
          console.log(`  ✅ ${key}: ${permissions[key]}`);
        }
      });
      
      return permissions;
    } else {
      console.error('❌ Errore nel caricamento permessi:', response.data);
      return {};
    }
  } catch (error) {
    console.error('❌ Errore nella verifica permessi:', error.response?.data || error.message);
    return {};
  }
}

async function testHasPermissionLogic() {
  try {
    console.log('\n🧪 Testando logica hasPermission...');
    
    // Simula la funzione hasPermission del frontend
    const permissions = await checkPermissions();
    
    const testCases = [
      { resource: 'form_templates', action: 'read', page: 'FormTemplatesPage' },
      { resource: 'form_templates', action: 'create', page: 'FormTemplatesPage' },
      { resource: 'form_templates', action: 'update', page: 'FormTemplatesPage' },
      { resource: 'form_templates', action: 'delete', page: 'FormTemplatesPage' },
      { resource: 'form_submissions', action: 'read', page: 'FormSubmissionsPage' },
      { resource: 'form_submissions', action: 'update', page: 'FormSubmissionsPage' },
      { resource: 'form_submissions', action: 'delete', page: 'FormSubmissionsPage' },
      { resource: 'form_submissions', action: 'export', page: 'FormSubmissionsPage' },
      { resource: 'PUBLIC_CMS', action: 'READ', page: 'PublicCMSPage' },
      { resource: 'PUBLIC_CMS', action: 'UPDATE', page: 'PublicCMSPage' }
    ];
    
    console.log('\n📋 Test hasPermission per ogni pagina:');
    testCases.forEach(testCase => {
      const { resource, action, page } = testCase;
      
      // Simula la logica hasPermission
      const permissionKey = `${resource}:${action}`;
      const hasPermission = permissions[permissionKey] === true;
      
      console.log(`  ${hasPermission ? '✅' : '❌'} ${page} - ${permissionKey}`);
      
      if (!hasPermission) {
        // Cerca permessi alternativi
        const altKeys = [
          `${resource}:${action.toLowerCase()}`,
          `${resource.toUpperCase()}:${action}`,
          `${resource.toUpperCase()}:${action.toUpperCase()}`,
          `VIEW_${resource.toUpperCase()}`,
          `EDIT_${resource.toUpperCase()}`,
          `CREATE_${resource.toUpperCase()}`,
          `DELETE_${resource.toUpperCase()}`,
          `MANAGE_${resource.toUpperCase()}`
        ];
        
        const foundAlt = altKeys.find(key => permissions[key] === true);
        if (foundAlt) {
          console.log(`    🔍 Trovato permesso alternativo: ${foundAlt}`);
        } else {
          console.log(`    ❌ Nessun permesso alternativo trovato`);
        }
      }
    });
    
  } catch (error) {
    console.error('❌ Errore nel test hasPermission:', error.message);
  }
}

async function main() {
  console.log('🚀 Test Permessi Semplificato\n');
  
  try {
    // 1. Login
    await login();
    
    // 2. Verifica permessi
    await checkPermissions();
    
    // 3. Test logica hasPermission
    await testHasPermissionLogic();
    
    console.log('\n✅ Test completato!');
    
  } catch (error) {
    console.error('💥 Errore fatale:', error.message);
    process.exit(1);
  }
}

// Esegui il test
main();