import { lazy } from 'react';

const EmployeesPageNewLazy = lazy(() => import('./EmployeesPageNew'));

export default EmployeesPageNewLazy;