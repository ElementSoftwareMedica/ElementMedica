const { convertBackendToFrontendPermissions, hasBackendPermission } = require('./src/utils/permissionMapping.ts');

// Simula i permessi che abbiamo visto nei test precedenti
const mockBackendPermissions = {
  'VIEW_COMPANIES': true,
  'CREATE_COMPANIES': true,
  'EDIT_COMPANIES': true,
  'DELETE_COMPANIES': true,
  'VIEW_EMPLOYEES': true,
  'CREATE_EMPLOYEES': true,
  'EDIT_EMPLOYEES': true,
  'DELETE_EMPLOYEES': true,
  'VIEW_TRAINERS': true,
  'CREATE_TRAINERS': true,
  'EDIT_TRAINERS': true,
  'DELETE_TRAINERS': true,
  'VIEW_USERS': true,
  'CREATE_USERS': true,
  'EDIT_USERS': true,
  'DELETE_USERS': true,
  'VIEW_COURSES': true,
  'CREATE_COURSES': true,
  'EDIT_COURSES': true,
  'DELETE_COURSES': true,
  'VIEW_ROLES': true,
  'CREATE_ROLES': true,
  'EDIT_ROLES': true,
  'DELETE_ROLES': true,
  'ASSIGN_ROLES': true,
  'REVOKE_ROLES': true,
  'ROLE_MANAGEMENT': true,
  'VIEW_ADMINISTRATION': true,
  'EDIT_ADMINISTRATION': true,
  'VIEW_GDPR': true,
  'EDIT_GDPR': true,
  'VIEW_REPORTS': true,
  'CREATE_REPORTS': true,
  'EDIT_REPORTS': true,
  'DELETE_REPORTS': true,
  'VIEW_HIERARCHY': true,
  'CREATE_HIERARCHY': true,
  'EDIT_HIERARCHY': true,
  'DELETE_HIERARCHY': true,
  'VIEW_PERSONS': true,
  'CREATE_PERSONS': true,
  'EDIT_PERSONS': true,
  'DELETE_PERSONS': true,
  'VIEW_SCHEDULES': true,
  'CREATE_SCHEDULES': true,
  'EDIT_SCHEDULES': true,
  'DELETE_SCHEDULES': true,
  'VIEW_QUOTES': true,
  'CREATE_QUOTES': true,
  'EDIT_QUOTES': true,
  'DELETE_QUOTES': true,
  'VIEW_INVOICES': true,
  'CREATE_INVOICES': true,
  'EDIT_INVOICES': true,
  'DELETE_INVOICES': true,
  'VIEW_CMS': true,
  'CREATE_CMS': true,
  'EDIT_CMS': true,
  'DELETE_CMS': true,
  'VIEW_PUBLIC_CMS': true,
  'CREATE_PUBLIC_CMS': true,
  'EDIT_PUBLIC_CMS': true,
  'DELETE_PUBLIC_CMS': true,
  'MANAGE_PUBLIC_CMS': true,
  'VIEW_SUBMISSIONS': true,
  'CREATE_SUBMISSIONS': true,
  'EDIT_SUBMISSIONS': true,
  'DELETE_SUBMISSIONS': true,
  'VIEW_FORM_SUBMISSIONS': true,
  'CREATE_FORM_SUBMISSIONS': true,
  'EDIT_FORM_SUBMISSIONS': true,
  'DELETE_FORM_SUBMISSIONS': true,
  'VIEW_FORM_TEMPLATES': true,
  'CREATE_FORM_TEMPLATES': true,
  'EDIT_FORM_TEMPLATES': true,
  'DELETE_FORM_TEMPLATES': true,
  'VIEW_TEMPLATES': true,
  'CREATE_TEMPLATES': true,
  'EDIT_TEMPLATES': true,
  'DELETE_TEMPLATES': true,
  'VIEW_NOTIFICATIONS': true,
  'CREATE_NOTIFICATIONS': true,
  'EDIT_NOTIFICATIONS': true,
  'DELETE_NOTIFICATIONS': true,
  'MANAGE_NOTIFICATIONS': true,
  'SEND_NOTIFICATIONS': true,
  'VIEW_AUDIT_LOGS': true,
  'CREATE_AUDIT_LOGS': true,
  'EDIT_AUDIT_LOGS': true,
  'DELETE_AUDIT_LOGS': true,
  'MANAGE_AUDIT_LOGS': true,
  'EXPORT_AUDIT_LOGS': true,
  'VIEW_API_KEYS': true,
  'CREATE_API_KEYS': true,
  'EDIT_API_KEYS': true,
  'DELETE_API_KEYS': true,
  'MANAGE_API_KEYS': true,
  'REGENERATE_API_KEYS': true
};

// Simula la funzione hasPermission dell'AuthContext
function simulateHasPermission(resourceOrPermission, action, permissions) {
  let permissionToCheck;
  
  if (action) {
    // Formato con due parametri: resource e action
    permissionToCheck = `${resourceOrPermission}:${action}`;
    console.log(`🔐 Checking permission (two params): ${resourceOrPermission}:${action}`);
  } else {
    // Formato con un parametro: permesso diretto
    permissionToCheck = resourceOrPermission;
    console.log(`🔐 Checking permission (single param): ${resourceOrPermission}`);
  }
  
  console.log(`🔐 Permission check details:`, { 
    permissionToCheck,
    hasSpecificPermission: permissions[permissionToCheck],
    allPermissions: Object.keys(permissions).filter(key => permissions[key] === true).slice(0, 10) // primi 10 per brevità
  });
  
  // Verifica permesso diretto (sia formato frontend che backend)
  if (permissions[permissionToCheck] === true) {
    console.log(`✅ Access granted: user has ${permissionToCheck} permission (direct match)`);
    return true;
  }
  
  // Se abbiamo due parametri, prova anche altri formati
  if (action) {
    // Verifica permesso all:* (permesso universale)
    if (permissions['all:' + action] === true) {
      console.log('✅ Access granted: user has all:' + action + ' permission');
      return true;
    }
    
    // Verifica permesso resource:all (permesso per tutte le azioni sulla risorsa)
    if (permissions[resourceOrPermission + ':all'] === true) {
      console.log('✅ Access granted: user has ' + resourceOrPermission + ':all permission');
      return true;
    }
    
    // Prova anche il formato backend usando hasBackendPermission
    try {
      const backendPermissionResult = hasBackendPermission(permissionToCheck, permissions);
      if (backendPermissionResult) {
        console.log(`✅ Access granted: user has ${permissionToCheck} permission (backend format match)`);
        return true;
      }
    } catch (error) {
      console.log('⚠️ Error checking backend permission:', error.message);
    }
    
    // Concedi accesso se c'è almeno un permesso con quel resource
    if (action === 'read') {
      // For 'read' actions, check if the user has any permission for this resource
      const resourcePermissions = Object.keys(permissions)
        .filter(key => key.startsWith(resourceOrPermission + ':') && permissions[key] === true);
      
      console.log(`🔍 Found ${resourcePermissions.length} permissions for resource '${resourceOrPermission}':`, resourcePermissions);
      
      if (resourcePermissions.length > 0) {
        console.log('✅ Access granted: user has some permission for ' + resourceOrPermission);
        return true;
      }
    }
  } else {
    // Se è un singolo parametro, prova anche il formato backend
    try {
      const backendPermissionResult = hasBackendPermission(permissionToCheck, permissions);
      if (backendPermissionResult) {
        console.log(`✅ Access granted: user has ${permissionToCheck} permission (backend format match)`);
        return true;
      }
    } catch (error) {
      console.log('⚠️ Error checking backend permission:', error.message);
    }
  }
  
  console.log(`❌ Permission check result: false for ${permissionToCheck}`);
  return false;
}

async function testPageLogic() {
  console.log('🧪 Test logica pagine con permessi simulati...\n');
  
  try {
    // 1. Converti i permessi backend in frontend
    console.log('1. Conversione permessi backend -> frontend...');
    const frontendPermissions = convertBackendToFrontendPermissions(mockBackendPermissions);
    
    console.log('Backend permissions count:', Object.keys(mockBackendPermissions).filter(p => mockBackendPermissions[p]).length);
    console.log('Frontend permissions count:', Object.keys(frontendPermissions).filter(p => frontendPermissions[p]).length);
    
    // 2. Test specifici per le pagine problematiche
    console.log('\n2. Test pagine problematiche...\n');
    
    // PublicCMSPage
    console.log('=== TEST PublicCMSPage ===');
    const canViewCMS = simulateHasPermission('PUBLIC_CMS', 'READ', frontendPermissions);
    const canEditCMS = simulateHasPermission('PUBLIC_CMS', 'UPDATE', frontendPermissions);
    console.log(`PublicCMSPage - canView: ${canViewCMS}, canEdit: ${canEditCMS}\n`);
    
    // FormTemplatesPage
    console.log('=== TEST FormTemplatesPage ===');
    const canViewTemplates = simulateHasPermission('form_templates', 'read', frontendPermissions);
    const canEditTemplates = simulateHasPermission('form_templates', 'update', frontendPermissions);
    console.log(`FormTemplatesPage - canView: ${canViewTemplates}, canEdit: ${canEditTemplates}\n`);
    
    // FormSubmissionsPage
    console.log('=== TEST FormSubmissionsPage ===');
    const canViewSubmissions = simulateHasPermission('form_submissions', 'read', frontendPermissions);
    const canEditSubmissions = simulateHasPermission('form_submissions', 'update', frontendPermissions);
    console.log(`FormSubmissionsPage - canView: ${canViewSubmissions}, canEdit: ${canEditSubmissions}\n`);
    
    // 3. Debug permessi specifici
    console.log('3. Debug permessi specifici...');
    const debugPermissions = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE',
      'form_templates:read',
      'form_templates:update',
      'form_submissions:read',
      'form_submissions:update',
      'VIEW_PUBLIC_CMS',
      'EDIT_PUBLIC_CMS',
      'VIEW_FORM_TEMPLATES',
      'EDIT_FORM_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS',
      'EDIT_FORM_SUBMISSIONS'
    ];
    
    debugPermissions.forEach(permission => {
      const hasPermission = frontendPermissions[permission] === true;
      console.log(`${hasPermission ? '✅' : '❌'} ${permission}: ${hasPermission}`);
    });
    
    console.log('\n🎯 === CONCLUSIONI ===');
    if (canViewCMS && canViewTemplates && canViewSubmissions) {
      console.log('✅ Tutti i permessi di visualizzazione sono presenti');
      console.log('💡 Se le pagine mostrano ancora "accesso negato", il problema è probabilmente:');
      console.log('   1. Timing del caricamento dei permessi');
      console.log('   2. Cache del browser');
      console.log('   3. Stato di loading non gestito correttamente');
      console.log('   4. Errore nella logica di rendering condizionale');
    } else {
      console.log('❌ Alcuni permessi mancano - questo spiega il problema');
    }
    
  } catch (error) {
    console.error('❌ Errore durante il test:', error);
  }
}

testPageLogic();