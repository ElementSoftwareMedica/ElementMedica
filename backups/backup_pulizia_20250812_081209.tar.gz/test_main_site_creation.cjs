#!/usr/bin/env node

/**
 * Test Script per la Creazione Automatica della Sede Principale
 * 
 * Questo script testa che quando si crea un'azienda con dati di indirizzo,
 * venga automaticamente creata una sede principale nella tabella CompanySite.
 */

const axios = require('axios');

const API_BASE = 'http://localhost:4003';
const PROXY_BASE = 'http://localhost:4003';

// Configurazione axios con timeout
const api = axios.create({
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Aggiungi interceptor per logging delle richieste
api.interceptors.request.use(request => {
  console.log('🔄 Richiesta HTTP:', {
    method: request.method?.toUpperCase(),
    url: request.url,
    data: request.data
  });
  return request;
});

api.interceptors.response.use(
  response => {
    console.log('✅ Risposta HTTP:', {
      status: response.status,
      url: response.config.url,
      data: response.data
    });
    return response;
  },
  error => {
    console.log('❌ Errore HTTP:', {
      status: error.response?.status,
      url: error.config?.url,
      message: error.message,
      data: error.response?.data
    });
    return Promise.reject(error);
  }
);

let authToken = null;

/**
 * Effettua il login e ottiene il token di autenticazione
 */
async function login() {
  try {
    console.log('🔐 Effettuando login...');
    
    const response = await api.post(`${PROXY_BASE}/api/v1/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    if (response.data && response.data.tokens && response.data.tokens.access_token) {
      authToken = response.data.tokens.access_token;
      api.defaults.headers.common['Authorization'] = `Bearer ${authToken}`;
      console.log('✅ Login effettuato con successo');
      return true;
    } else if (response.data && response.data.token) {
      authToken = response.data.token;
      api.defaults.headers.common['Authorization'] = `Bearer ${authToken}`;
      console.log('✅ Login effettuato con successo');
      return true;
    } else {
      console.error('❌ Risposta di login non valida:', response.data);
      return false;
    }
  } catch (error) {
    console.error('❌ Errore durante il login:', {
      message: error.message,
      status: error.response?.status,
      data: error.response?.data
    });
    return false;
  }
}

/**
 * Crea un'azienda con dati di indirizzo
 */
async function createCompanyWithAddress() {
  try {
    console.log('🏢 Creando azienda con dati di indirizzo...');
    
    const companyData = {
      ragioneSociale: 'Test Azienda Sede Principale',
      piva: '12345678901',
      sedeAzienda: 'Via Test 123',
      citta: 'Milano',
      cap: '20100',
      provincia: 'MI',
      telefono: '02-1234567',
      mail: 'test@testazienda.it',
      personaRiferimento: 'Mario Rossi'
    };

    const response = await api.post(`${PROXY_BASE}/api/v1/companies`, companyData);
    
    if (response.data && response.data.id) {
      console.log('✅ Azienda creata con successo:', {
        id: response.data.id,
        ragioneSociale: response.data.ragioneSociale,
        piva: response.data.piva
      });
      return response.data;
    } else {
      console.error('❌ Risposta di creazione azienda non valida:', response.data);
      return null;
    }
  } catch (error) {
    console.error('❌ Errore durante la creazione dell\'azienda:', {
      message: error.message,
      status: error.response?.status,
      data: error.response?.data
    });
    return null;
  }
}

/**
 * Verifica che sia stata creata automaticamente la sede principale
 */
async function checkMainSiteCreated(companyId) {
  try {
    console.log('🔍 Verificando creazione automatica sede principale...');
    
    // Attendi un momento per assicurarsi che la sede sia stata creata
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const response = await api.get(`${PROXY_BASE}/api/v1/company-sites/company/${companyId}`);
    
    if (response.data && response.data.sites) {
      const sites = response.data.sites;
      console.log(`📍 Trovate ${sites.length} sedi per l'azienda`);
      
      if (sites.length > 0) {
        const mainSite = sites[0];
        console.log('✅ Sede principale creata automaticamente:', {
          id: mainSite.id,
          siteName: mainSite.siteName,
          citta: mainSite.citta,
          indirizzo: mainSite.indirizzo,
          cap: mainSite.cap,
          provincia: mainSite.provincia
        });
        return true;
      } else {
        console.error('❌ Nessuna sede trovata per l\'azienda');
        return false;
      }
    } else {
      console.error('❌ Risposta non valida dalla ricerca sedi:', response.data);
      return false;
    }
  } catch (error) {
    console.error('❌ Errore durante la verifica delle sedi:', {
      message: error.message,
      status: error.response?.status,
      data: error.response?.data
    });
    return false;
  }
}

/**
 * Pulisce i dati di test eliminando l'azienda creata
 */
async function cleanup(companyId) {
  try {
    console.log('🧹 Pulizia dati di test...');
    
    await api.delete(`${PROXY_BASE}/api/v1/companies/${companyId}`);
    console.log('✅ Azienda di test eliminata');
  } catch (error) {
    console.warn('⚠️ Errore durante la pulizia (non critico):', error.message);
  }
}

/**
 * Test principale
 */
async function runTest() {
  console.log('🚀 Avvio test creazione automatica sede principale\n');
  console.log('📋 Configurazione test:', {
    API_BASE,
    PROXY_BASE,
    timestamp: new Date().toISOString()
  });
  console.log('');
  
  try {
    // 1. Login
    console.log('📍 Step 1: Tentativo di login...');
    const loginSuccess = await login();
    if (!loginSuccess) {
      console.error('❌ Test fallito: impossibile effettuare il login');
      process.exit(1);
    }
    console.log('✅ Step 1 completato: Login riuscito');
    
    console.log('');
    
    // 2. Crea azienda con dati di indirizzo
    console.log('📍 Step 2: Creazione azienda...');
    const company = await createCompanyWithAddress();
    if (!company) {
      console.error('❌ Test fallito: impossibile creare l\'azienda');
      process.exit(1);
    }
    console.log('✅ Step 2 completato: Azienda creata con ID:', company.id);
    
    console.log('');
    
    // 3. Verifica che sia stata creata la sede principale
    console.log('📍 Step 3: Verifica creazione sede principale...');
    const siteCreated = await checkMainSiteCreated(company.id);
    console.log('✅ Step 3 completato: Verifica sede principale -', siteCreated ? 'TROVATA' : 'NON TROVATA');
    
    console.log('');
    
    // 4. Pulizia
    console.log('📍 Step 4: Pulizia dati di test...');
    await cleanup(company.id);
    console.log('✅ Step 4 completato: Pulizia terminata');
    
    console.log('');
    
    // 5. Risultato finale
    if (siteCreated) {
      console.log('🎉 TEST SUPERATO: La sede principale viene creata automaticamente!');
      process.exit(0);
    } else {
      console.log('❌ TEST FALLITO: La sede principale NON viene creata automaticamente');
      process.exit(1);
    }
    
  } catch (error) {
    console.error('❌ Errore generale durante il test:', error.message);
    process.exit(1);
  }
}

// Gestione degli errori non catturati
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
  process.exit(1);
});

// Avvia il test
runTest();