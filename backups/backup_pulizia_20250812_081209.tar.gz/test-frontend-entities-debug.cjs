const puppeteer = require('puppeteer');

async function testFrontendEntities() {
  const browser = await puppeteer.launch({ 
    headless: false,
    defaultViewport: null,
    args: ['--start-maximized']
  });
  
  try {
    const page = await browser.newPage();
    
    // Intercetta le richieste di rete per vedere cosa viene caricato
    page.on('response', async (response) => {
      const url = response.url();
      if (url.includes('/api/') && (url.includes('entities') || url.includes('permissions'))) {
        console.log(`🌐 API Response: ${response.status()} - ${url}`);
        try {
          const responseText = await response.text();
          if (url.includes('entities')) {
            console.log('📋 Entities Response:', responseText.substring(0, 500) + '...');
          } else if (url.includes('permissions')) {
            console.log('🔐 Permissions Response:', responseText.substring(0, 500) + '...');
          }
        } catch (e) {
          console.log('❌ Error reading response:', e.message);
        }
      }
    });

    // Intercetta gli errori della console
    page.on('console', msg => {
      if (msg.type() === 'error') {
        console.log('🚨 Console Error:', msg.text());
      }
    });

    console.log('🚀 Navigating to frontend...');
    await page.goto('http://localhost:5173', { waitUntil: 'networkidle0' });

    // Verifica se siamo già loggati o se dobbiamo fare login
    console.log('🔍 Checking if already logged in...');
    
    try {
      // Prova a vedere se c'è il campo di login
      await page.waitForSelector('input[name="identifier"]', { timeout: 3000 });
      
      // Se arriviamo qui, dobbiamo fare login
      console.log('🔐 Performing login...');
      await page.type('input[name="identifier"]', 'admin@example.com');
      await page.type('input[name="password"]', 'Admin123!');
      await page.click('button[type="submit"]');

      // Aspetta il redirect dopo login
      await page.waitForNavigation({ waitUntil: 'networkidle0' });
      console.log('✅ Login successful');
    } catch (e) {
      // Se non troviamo il campo di login, probabilmente siamo già loggati
      console.log('✅ Already logged in or different login structure');
    }

    // Naviga alla pagina dei ruoli
    console.log('📋 Navigating to roles page...');
    await page.goto('http://localhost:5173/settings/roles', { waitUntil: 'networkidle0' });

    // Aspetta un po' per il caricamento
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Prendi uno screenshot della pagina dei ruoli per debug
    await page.screenshot({ path: '/Users/matteo.michielon/project 2.0/debug-roles-page.png', fullPage: true });
    console.log('📸 Roles page screenshot saved as debug-roles-page.png');

    // Cerca tutti i pulsanti disponibili
    console.log('🔍 Looking for create role button...');
    const buttons = await page.$$('button');
    let createButton = null;
    
    for (const button of buttons) {
      try {
        const text = await page.evaluate(el => el.textContent?.trim(), button);
        console.log(`🔍 Found button: "${text}"`);
        if (text && (text.includes('Crea') || text.includes('Nuovo') || text.includes('Ruolo') || text.includes('+'))) {
          console.log(`✅ Potential create button found: "${text}"`);
          createButton = button;
          break;
        }
      } catch (e) {
        // Continua
      }
    }

    if (createButton) {
      console.log('➕ Clicking create role button...');
      await createButton.click();
    } else {
      console.log('❌ No create button found, trying alternative approach...');
      
      // Prova a cercare link o altri elementi
      const allElements = await page.$$('a, div[role="button"], span[role="button"]');
      for (const element of allElements) {
        try {
          const text = await page.evaluate(el => el.textContent?.trim(), element);
          if (text && (text.includes('Crea') || text.includes('Nuovo') || text.includes('Ruolo'))) {
            console.log(`🔍 Found alternative element: "${text}"`);
            await element.click();
            createButton = element;
            break;
          }
        } catch (e) {
          // Continua
        }
      }
    }

    if (!createButton) {
      console.log('❌ No create button found at all. Checking page content...');
      const pageContent = await page.content();
      console.log('📄 Page title:', await page.title());
      
      // Verifica se siamo effettivamente nella pagina corretta
      if (pageContent.includes('Accesso negato') || pageContent.includes('Access denied')) {
        console.log('🚫 Access denied to roles page');
        return;
      }
    }

    // Aspetta che il modal si apra
    await page.waitForSelector('[role="dialog"], .modal, [data-testid="role-modal"]', { timeout: 5000 });
    console.log('✅ Modal opened');

    // Aspetta un po' per permettere il caricamento dei permessi
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Verifica se ci sono entità visibili nel modal
    console.log('🔍 Checking for entities in modal...');
    
    // Cerca le entità specifiche
    const entitySelectors = [
      'text=Form Templates',
      'text=Form Submissions', 
      'text=Public CMS',
      'text=Template Form',
      'text=Risposte Form',
      'text=CMS Pubblico',
      'text=form_templates',
      'text=form_submissions',
      'text=public_cms'
    ];

    let foundEntities = [];
    for (const selector of entitySelectors) {
      try {
        const element = await page.$(selector);
        if (element) {
          const text = await page.evaluate(el => el.textContent, element);
          foundEntities.push(text);
          console.log(`✅ Found entity: ${text}`);
        }
      } catch (e) {
        // Continua con il prossimo selettore
      }
    }

    // Cerca tutti gli elementi che potrebbero essere entità
    console.log('🔍 Searching for all potential entities...');
    const allButtons = await page.$$('button');
    const allDivs = await page.$$('div');
    
    let allTexts = [];
    for (const element of [...allButtons, ...allDivs]) {
      try {
        const text = await page.evaluate(el => el.textContent?.trim(), element);
        if (text && text.length > 0 && text.length < 100) {
          allTexts.push(text);
        }
      } catch (e) {
        // Continua
      }
    }

    // Filtra i testi che potrebbero essere entità
    const potentialEntities = allTexts.filter(text => 
      text.toLowerCase().includes('form') ||
      text.toLowerCase().includes('cms') ||
      text.toLowerCase().includes('template') ||
      text.toLowerCase().includes('submission') ||
      text.toLowerCase().includes('pubblico')
    );

    console.log('🎯 Potential entities found:', [...new Set(potentialEntities)]);

    // Prendi uno screenshot per debug
    await page.screenshot({ path: '/Users/matteo.michielon/project 2.0/debug-role-modal.png', fullPage: true });
    console.log('📸 Screenshot saved as debug-role-modal.png');

    if (foundEntities.length === 0) {
      console.log('❌ No target entities found in modal');
    } else {
      console.log(`✅ Found ${foundEntities.length} target entities:`, foundEntities);
    }

  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await browser.close();
  }
}

testFrontendEntities().catch(console.error);