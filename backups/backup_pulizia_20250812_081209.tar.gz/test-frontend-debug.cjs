#!/usr/bin/env node

const axios = require('axios');

async function testFrontendDebug() {
  try {
    console.log('🔐 Step 1: Login to get token and tenant...');
    const loginResponse = await axios.post('http://localhost:4003/api/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    const token = loginResponse.data.tokens.access_token;
    const tenantId = loginResponse.data.user.tenantId;
    console.log('✅ Login successful');
    console.log('🔑 Token:', token.substring(0, 20) + '...');
    console.log('🏢 Tenant ID:', tenantId);

    
    console.log('\n🔄 Step 2: Test /api/counters exactly like apiGet...');
    
    // Simula esattamente come apiGet fa la chiamata
    const countersResponse = await axios.get('http://localhost:4003/api/counters', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'X-Tenant-ID': tenantId
      },
      withCredentials: true,
      timeout: 20000,
      params: {}
    });
    
    console.log('✅ Counters response:', JSON.stringify(countersResponse.data, null, 2));
    
    console.log('\n🔄 Step 3: Test without X-Tenant-ID header...');
    
    try {
      const countersResponseNoTenant = await axios.get('http://localhost:4003/api/counters', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        withCredentials: true,
        timeout: 20000
      });
      
      console.log('✅ Counters response (no tenant header):', JSON.stringify(countersResponseNoTenant.data, null, 2));
    } catch (error) {
      console.error('❌ Error without tenant header:', error.response?.status, error.response?.data);
    }
    
    console.log('\n🔄 Step 4: Test with wrong tenant ID...');
    
    try {
      const countersResponseWrongTenant = await axios.get('http://localhost:4003/api/counters', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'X-Tenant-ID': 'wrong-tenant-id'
        },
        withCredentials: true,
        timeout: 20000
      });
      
      console.log('✅ Counters response (wrong tenant):', JSON.stringify(countersResponseWrongTenant.data, null, 2));
    } catch (error) {
      console.error('❌ Error with wrong tenant:', error.response?.status, error.response?.data);
    }

    
  } catch (error) {
    console.error('❌ Error:', error.response?.status, error.response?.data || error.message);
  }
}

testFrontendDebug();