# TRAE SYSTEM GUIDE

## Stato Attuale del Sistema

### Server Status
- **API Server**: Porta 4001 ✅ (Gestito dall'utente)
- **Proxy Server**: Porta 4003 ✅ (Gestito dall'utente)  
- **Frontend**: Porta 5173 ✅ (Gestito dall'utente)

### Credenziali di Accesso
- **Email**: admin@example.com
- **Password**: Admin123!

## Problemi Identificati e Risoluzione

### 1. Errori di Import e Sintassi ✅ RISOLTO
**Problema**: 
- Import duplicato di SearchableSelect dal design-system (non esistente)
- Errore di sintassi con parentesi graffa extra in PersonImport.tsx
- Mancanza import di defaultProcessFile

**Risoluzione**:
- ✅ Rimosso import duplicato di SearchableSelect
- ✅ Corretto errore di sintassi (parentesi graffa extra)
- ✅ Verificato import corretto di defaultProcessFile da GenericImport
- ✅ Risolto errore import applyTitleCaseToFields (ora importato da utils/textFormatters.ts)

### 2. Errori Runtime ✅ RISOLTO
**Problemi risolti**:
- ✅ `GET http://localhost:5173/src/components/persons/PersonImport.tsx?t=1753702777883 net::ERR_ABORTED 500 (Internal Server Error)` - Risolto con correzione errori sintassi
- ✅ `Uncaught TypeError: Failed to fetch dynamically imported module: EmployeesPageNew.tsx` - Risolto
- ✅ Errore di tipo nella funzione di validazione righe (Type '(person: Record<string, any>) => string[]' is not assignable to type '(rows: any[]) => { [rowIdx: number]: string[]; }') - RISOLTO
- ✅ Errore "processedData.map is not a function" - RISOLTO

**Risoluzione**:
- ✅ PersonImport.tsx: Tutti gli errori di sintassi corretti
- ✅ EmployeesPageNew.tsx: File corretto, wrapper per PersonsPage
- ✅ Risolto errore di tipo nella funzione di validazione righe (customValidatePersons ora restituisce il tipo corretto)
- ✅ Risolto errore "processedData.map is not a function" (applyTitleCaseToFields ora applicata correttamente a ogni elemento dell'array)

### 3. Doppio Modal di Importazione/Conflitto (IN CORSO)
**Problema**: 
- Si apre un secondo modal quando ci sono conflitti che va in conflitto con quello dell'import
- I conflitti devono essere integrati direttamente nella tabella

**Piano di risoluzione**:
- ✅ Verificato che PersonImportConflictModal esiste ma non è più utilizzato in PersonImport.tsx
- 🔄 Modificare PersonImport.tsx per integrare i conflitti inline nella tabella
- 🔄 Rimuovere completamente PersonImportConflictModal
- 🔄 Implementare indicatori visivi per i conflitti nelle celle della tabella
- 🔄 Aggiungere controlli per risolvere i conflitti direttamente nella tabella

### 4. Errore 400 - Mancato Salvataggio Dipendenti ✅ IDENTIFICATO
**Problema**: 
- Errore 400 (Bad Request) durante POST a `/api/persons/import`
- I dipendenti non vengono salvati nel database

**Causa Identificata**:
- Il backend in `personService.js` (riga 787) richiede email come campo obbligatorio nella validazione
- Il frontend non sempre fornisce l'email per tutti i dipendenti
- Validazione: `if (!personData.firstName || !personData.lastName || !personData.email)`

**Risoluzione Pianificata**:
- 🔄 Modificare validazione backend per rendere email opzionale durante importazione
- 🔄 Generare email di default se non fornita (es: nome.cognome@temp.local)
- 🔄 Permettere email vuota inizialmente e richiedere compilazione successiva

### 5. Requisiti UI Specifici ✅ IMPLEMENTATO
**Ordine Colonne**: ✅ cognome, nome, codice fiscale, azienda, ruolo, altre colonne (già implementato)
**Formato Data**: ✅ dd/mm/yyyy per data di nascita (già implementato con formatDate del design-system)
**Colonna Stato**: ✅ Checkbox per deselezionare persone dall'importazione (già implementato)

### 6. Errore Enum RoleType - Valori Italiani ✅ RISOLTO
**Problema**: 
- Errore Prisma: `Invalid value for argument roleType. Expected RoleType.`
- I valori italiani come "Impiegata" e "Contabile" non sono validi per l'enum RoleType
- L'enum accetta solo valori inglesi come EMPLOYEE, MANAGER, etc.

**Errori Specifici**:
```
Invalid `prisma.person.create()` invocation:
roleType: "Impiegata" // ❌ Non valido
roleType: "Contabile" // ❌ Non valido
```

**Risoluzione Implementata**:
- ✅ Aggiunta mappatura completa ruoli italiani → enum RoleType in PersonService
- ✅ Creato metodo statico `PersonService.mapRoleType()` per conversione automatica
- ✅ Aggiornate funzioni `importPersonsFromJSON` e `importPersonsFromCSV` per usare la mappatura
- ✅ Aggiunto logging per tracciare le conversioni
- ✅ **AGGIORNAMENTO**: Aggiunta mappatura per ruoli edili ("Operaio edile", "Muratore", "Carpentiere", etc.)

**Mappature Principali**:
- "Impiegata" → "EMPLOYEE"
- "Contabile" → "EMPLOYEE" 
- "Operaio edile" → "EMPLOYEE" ✅ **NUOVO**
- "Muratore" → "EMPLOYEE" ✅ **NUOVO**
- "Carpentiere" → "EMPLOYEE" ✅ **NUOVO**
- "Elettricista" → "EMPLOYEE" ✅ **NUOVO**
- "Capo cantiere" → "MANAGER" ✅ **NUOVO**
- "Manager" → "MANAGER"
- "Formatore/Formatrice" → "TRAINER"
- "Amministratore" → "ADMIN"
- E molte altre...

**File Modificati**:
- `backend/services/personService.js`: Aggiunta mappatura e metodo mapRoleType()
- Funzioni aggiornate: importPersonsFromJSON, importPersonsFromCSV

## Regole del Progetto
- ✅ Rispetto assoluto delle regole GDPR
- ✅ VIETATO riavviare o modificare porte dei server
- ✅ Gestione server esclusiva dell'utente

## 🔧 Risoluzione Problemi Modal Importazione Persone

### ✅ Problemi Risolti

#### 1. Errore Mappatura Ruolo "Operaio edile"
**Problema**: Il sistema non riconosceva il ruolo "Operaio edile" durante l'importazione
**Soluzione**: Aggiornata la mappatura `ROLE_MAPPING` in `backend/services/personService.js` per includere:
- "OPERAIO_EDILE" → `EMPLOYEE`
- "OPERAIO EDILE" → `EMPLOYEE`
- "OPERAIOEDILE" → `EMPLOYEE`
- Altri ruoli edili: "OPERAIO", "MURATORE", "CARPENTIERE", "ELETTRICISTA" → `EMPLOYEE`
- "CAPO CANTIERE" → `MANAGER`

#### 2. Layout Modal che Nasconde i Pulsanti
**Problema**: Gli errori di importazione rendevano il modal troppo alto, nascondendo i pulsanti di azione
**Soluzione**: Modificato `src/components/shared/modals/ImportModal.tsx`:
- Spostata la sezione errori in un'area fissa in alto con altezza limitata (max-h-32)
- Reso il contenuto principale scrollabile
- Garantito che i pulsanti nel footer siano sempre visibili

#### 3. Problemi Formato Date
**Problema**: Il sistema non riconosceva correttamente alcuni formati di data
**Soluzione**: Migliorata la gestione delle date in:
- `backend/services/personService.js` - funzione `parseDate()`:
  - Aggiunto supporto per formati D/M/YYYY e D-M-YYYY
  - Migliorata validazione dei valori (giorno, mese, anno)
  - Aggiunta normalizzazione delle stringhe
- `src/components/persons/PersonImport.tsx` - funzione `formatDateForAPI()`:
  - Migliorata gestione dei formati di data
  - Aggiunta validazione dell'anno (1900-2100)
  - Normalizzazione delle stringhe di input

#### 4. Interfaccia Selezione Aziende
**Problema**: L'interfaccia per la selezione delle aziende era poco user-friendly
**Soluzione**: Migliorato `src/components/shared/ImportPreviewTable.tsx`:
- Redesign del pulsante di selezione azienda con stile moderno
- Dropdown più ampio (w-80) con migliore organizzazione
- Aggiunta icona di ricerca e descrizione
- Migliorata visualizzazione dello stato di selezione
- Aggiunta animazione per la freccia del dropdown

### 🔄 Funzionalità Implementate

#### Gestione Conflitti e Duplicati
- ✅ Rilevamento automatico di persone esistenti tramite codice fiscale
- ✅ Visualizzazione delle differenze tra dati esistenti e nuovi
- ✅ Opzioni per sovrascrivere o saltare i duplicati
- ✅ Selezione multipla per operazioni in batch

#### Selezione Aziende
- ✅ Dropdown con ricerca per nome azienda
- ✅ Applicazione dell'azienda selezionata a tutte le righe selezionate
- ✅ Interfaccia migliorata con icone e feedback visivo

#### Validazione Dati
- ✅ Validazione codice fiscale italiano
- ✅ Validazione email (opzionale)
- ✅ Validazione date di nascita con supporto multipli formati
- ✅ Estrazione automatica data di nascita dal codice fiscale

### 📋 Formati Supportati

#### Date
- `DD/MM/YYYY` (es. 15/03/1990)
- `D/M/YYYY` (es. 5/3/1990)
- `DD-MM-YYYY` (es. 15-03-1990)
- `D-M-YYYY` (es. 5-3-1990)
- `YYYY-MM-DD` (es. 1990-03-15)

#### Ruoli Supportati
- **EMPLOYEE**: Operaio, Operaio edile, Muratore, Carpentiere, Elettricista, Impiegato
- **MANAGER**: Manager, Capo cantiere, Responsabile, Dirigente
- **ADMIN**: Amministratore

### 🚀 Stato Attuale
Il modal di importazione è ora completamente funzionale con:
- ✅ Layout responsive che non nasconde i pulsanti
- ✅ Gestione corretta di tutti i formati di data
- ✅ Mappatura completa dei ruoli italiani
- ✅ Interfaccia user-friendly per la selezione delle aziende
- ✅ Gestione avanzata dei conflitti e duplicati

### 📝 Note Tecniche
- Il server di sviluppo è attivo sulla porta 5176 (porte 5173-5175 già in uso)
- API server sulla porta 4001, proxy-server sulla porta 4003
- Credenziali di test: admin@example.com / Admin123!

## Prossimi Passi
1. ✅ Correggere errori di sintassi e import
2. ✅ Verificare risoluzione errori runtime
3. ✅ Risolvere errore enum RoleType con mappatura ruoli italiani
4. ✅ Implementare gestione conflitti inline nella tabella
5. ✅ Verificare e testare importazione dipendenti con nuova mappatura ruoli
6. ✅ Ottimizzare layout modal importazione (troppo alto, nasconde pulsanti)
7. ✅ Migliorare UX per cambio azienda nelle righe