const axios = require('axios');

const API_BASE = 'http://localhost:4001/api/v1';

async function testPermissionsBypass() {
  console.log('🔐 Testing permissions with bypass approach...\n');

  try {
    // 1. Login
    console.log('1️⃣ Login...');
    const loginResponse = await axios.post(`${API_BASE}/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    console.log('Login response:', loginResponse.data);
    const { tokens, user, person } = loginResponse.data;
    const access_token = tokens?.access_token;
    const userId = person?.id || user?.id || user?.personId;
    console.log('✅ Login successful - User ID:', userId);
    console.log('🔑 Token:', access_token ? 'Present' : 'Missing');

    // 2. Test simplified permissions endpoint
    console.log('\n2️⃣ Testing simplified permissions endpoint...');
    const permissionsResponse = await axios.get(
      `${API_BASE}/auth/permissions-simple/${userId}`,
      {
        headers: {
          'Authorization': `Bearer ${access_token}`
        },
        timeout: 5000
      }
    );

    console.log('✅ Simplified permissions endpoint works!');
    console.log('📋 Permissions received:', Object.keys(permissionsResponse.data.permissions).length, 'permissions');
    
    // Check specific permissions
    const permissions = permissionsResponse.data.permissions;
    console.log('\n🔍 Checking specific permissions:');
    console.log('- PUBLIC_CMS:READ:', permissions['PUBLIC_CMS:READ'] ? '✅' : '❌');
    console.log('- form_templates:read:', permissions['form_templates:read'] ? '✅' : '❌');
    console.log('- FORM_SUBMISSIONS:READ:', permissions['FORM_SUBMISSIONS:READ'] ? '✅' : '❌');

  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

testPermissionsBypass();