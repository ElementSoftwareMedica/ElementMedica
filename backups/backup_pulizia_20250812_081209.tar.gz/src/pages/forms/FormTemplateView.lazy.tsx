import { lazy } from 'react';

export const FormTemplateViewLazy = lazy(() => import('./FormTemplateView'));