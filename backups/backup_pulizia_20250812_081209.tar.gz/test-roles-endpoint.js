const fetch = require('node-fetch');

async function testRolesEndpoint() {
  try {
    console.log('🔍 Testing roles endpoint...');
    
    // Prima fai login per ottenere il token
    const loginResponse = await fetch('http://localhost:4001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      console.error('❌ Login failed:', loginResponse.status, loginResponse.statusText);
      const errorText = await loginResponse.text();
      console.error('Error details:', errorText);
      return;
    }

    const loginData = await loginResponse.json();
    console.log('✅ Login successful');
    
    if (!loginData.success || !loginData.data?.token) {
      console.error('❌ No token in login response:', loginData);
      return;
    }

    const token = loginData.data.token;
    console.log('🔑 Token obtained');

    // Ora testa l'endpoint dei ruoli
    const rolesResponse = await fetch('http://localhost:4001/api/roles', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
    });

    console.log('📊 Roles endpoint response status:', rolesResponse.status);

    if (!rolesResponse.ok) {
      console.error('❌ Roles request failed:', rolesResponse.status, rolesResponse.statusText);
      const errorText = await rolesResponse.text();
      console.error('Error details:', errorText);
      return;
    }

    const rolesData = await rolesResponse.json();
    console.log('✅ Roles data received');
    console.log('📋 Response structure:', {
      success: rolesData.success,
      hasData: !!rolesData.data,
      dataKeys: rolesData.data ? Object.keys(rolesData.data) : null
    });

    if (rolesData.data && rolesData.data.data) {
      console.log(`📊 Found ${rolesData.data.data.length} roles:`);
      rolesData.data.data.forEach((role, index) => {
        console.log(`  ${index + 1}. ${role.name} (${role.roleType}) - ${role.userCount} users`);
      });
    }

    // Testa anche l'endpoint dei permessi
    console.log('\n🔍 Testing permissions endpoint...');
    const permissionsResponse = await fetch('http://localhost:4001/api/roles/permissions', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
    });

    console.log('📊 Permissions endpoint response status:', permissionsResponse.status);

    if (permissionsResponse.ok) {
      const permissionsData = await permissionsResponse.json();
      console.log('✅ Permissions data received');
      console.log('📋 Permissions structure:', {
        success: permissionsData.success,
        hasData: !!permissionsData.data,
        dataKeys: permissionsData.data ? Object.keys(permissionsData.data) : null
      });
    } else {
      const errorText = await permissionsResponse.text();
      console.error('❌ Permissions request failed:', errorText);
    }

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testRolesEndpoint();