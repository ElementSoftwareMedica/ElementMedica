const fetch = require('node-fetch');

const BASE_URL = 'http://localhost:3001';

async function testFullFlow() {
  try {
    console.log('🧪 TEST COMPLETO FLUSSO ADMIN');
    console.log('==============================\n');

    // 1. Login
    console.log('1️⃣ Tentativo di login...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      console.log(`❌ Login fallito: ${loginResponse.status}`);
      const errorText = await loginResponse.text();
      console.log('Errore:', errorText);
      return;
    }

    const loginData = await loginResponse.json();
    console.log('✅ Login riuscito');
    console.log(`👤 Utente: ${loginData.user?.email}`);
    console.log(`🔑 Token: ${loginData.token ? 'presente' : 'mancante'}`);
    
    // 2. Verifica permessi nel token
    if (loginData.user?.permissions) {
      console.log(`\n📋 Permessi totali: ${loginData.user.permissions.length}`);
      
      const rolePermissions = loginData.user.permissions.filter(p => 
        p.includes('ROLE') || p.includes('role')
      );
      console.log(`🎯 Permessi ruoli: ${rolePermissions.length}`);
      rolePermissions.forEach(p => console.log(`   - ${p}`));
      
      const hasRoleManagement = loginData.user.permissions.includes('ROLE_MANAGEMENT');
      console.log(`\n🔍 ROLE_MANAGEMENT: ${hasRoleManagement ? '✅ PRESENTE' : '❌ MANCANTE'}`);
    }

    // 3. Test endpoint ruoli
    console.log('\n2️⃣ Test endpoint /api/roles...');
    const rolesResponse = await fetch(`${BASE_URL}/api/roles`, {
      headers: {
        'Authorization': `Bearer ${loginData.token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log(`📊 Status: ${rolesResponse.status}`);
    
    if (rolesResponse.ok) {
      const rolesData = await rolesResponse.json();
      console.log('✅ Endpoint ruoli accessibile!');
      console.log(`📋 Ruoli trovati: ${rolesData.data?.length || 0}`);
      
      if (rolesData.data?.length > 0) {
        console.log('\n🔍 Primi 3 ruoli:');
        rolesData.data.slice(0, 3).forEach((role, index) => {
          console.log(`   ${index + 1}. ${role.name || role.type} (${role.category || 'N/A'})`);
        });
      }
    } else {
      const errorText = await rolesResponse.text();
      console.log('❌ Errore endpoint ruoli:');
      console.log(errorText);
    }

    // 4. Test endpoint permessi ruoli
    console.log('\n3️⃣ Test endpoint /api/roles/permissions...');
    const permissionsResponse = await fetch(`${BASE_URL}/api/roles/permissions`, {
      headers: {
        'Authorization': `Bearer ${loginData.token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log(`📊 Status: ${permissionsResponse.status}`);
    
    if (permissionsResponse.ok) {
      const permissionsData = await permissionsResponse.json();
      console.log('✅ Endpoint permessi accessibile!');
      console.log(`📋 Entità trovate: ${permissionsData.entities?.length || 0}`);
    } else {
      const errorText = await permissionsResponse.text();
      console.log('❌ Errore endpoint permessi:');
      console.log(errorText);
    }

    // 5. Riepilogo finale
    console.log('\n📊 RIEPILOGO FINALE');
    console.log('===================');
    console.log(`Login: ${loginResponse.ok ? '✅' : '❌'}`);
    console.log(`Endpoint ruoli: ${rolesResponse.ok ? '✅' : '❌'}`);
    console.log(`Endpoint permessi: ${permissionsResponse.ok ? '✅' : '❌'}`);
    
    if (loginResponse.ok && rolesResponse.ok && permissionsResponse.ok) {
      console.log('\n🎉 TUTTO FUNZIONA! L\'admin può accedere alla gestione ruoli.');
    } else {
      console.log('\n⚠️ Alcuni problemi persistono. Verifica i log sopra.');
    }

  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
  }
}

testFullFlow();