const axios = require('axios');
const jwt = require('jsonwebtoken');

const BASE_URL = 'http://localhost:4003';

async function testJWTValidation() {
  try {
    console.log('🔍 Testing JWT Token Validation');
    console.log('===============================');

    // 1. Effettua il login per ottenere un nuovo token
    console.log('1. Performing login...');
    const loginResponse = await axios.post(`${BASE_URL}/api/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    if (!loginResponse.data.success) {
      console.log('❌ Login failed:', loginResponse.data);
      return;
    }

    const token = loginResponse.data.tokens?.access_token;
    console.log('✅ Login successful');
    console.log('📄 Full login response:', loginResponse.data);
    
    if (!token) {
      console.log('❌ No token received in response');
      return;
    }
    
    console.log('🔑 Token received (first 50 chars):', token.substring(0, 50) + '...');

    // 2. Decodifica il token senza verifica per vedere il contenuto
    console.log('\n2. Decoding token without verification...');
    const decodedWithoutVerification = jwt.decode(token, { complete: true });
    console.log('📄 Token header:', decodedWithoutVerification.header);
    console.log('📄 Token payload:', decodedWithoutVerification.payload);

    // 3. Prova a verificare il token con diversi secret
    console.log('\n3. Testing token verification with different secrets...');
    
    const secretsToTry = [
      process.env.JWT_SECRET,
      'your-super-secret-jwt-key-change-in-production',
      'super-secret-jwt-key-for-development-change-in-production-2024',
      'your-super-secret-jwt-key-change-this-in-production'
    ].filter(Boolean);

    for (let i = 0; i < secretsToTry.length; i++) {
      const secret = secretsToTry[i];
      console.log(`\n   Testing secret ${i + 1}: ${secret.substring(0, 20)}...`);
      
      try {
        const decoded = jwt.verify(token, secret, {
          issuer: 'training-platform',
          audience: 'training-platform-users'
        });
        console.log('   ✅ Token verified successfully with this secret!');
        console.log('   📄 Decoded payload:', decoded);
        break;
      } catch (error) {
        console.log('   ❌ Verification failed:', error.message);
      }
    }

    // 4. Testa una chiamata API semplice per vedere l'errore esatto
    console.log('\n4. Testing API call to see exact error...');
    try {
      const response = await axios.get(`${BASE_URL}/api/auth/verify`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      console.log('✅ API call successful:', response.data);
    } catch (error) {
      console.log('❌ API call failed:');
      console.log('   Status:', error.response?.status);
      console.log('   Data:', error.response?.data);
      console.log('   Headers:', error.response?.headers);
    }

  } catch (error) {
    console.error('❌ Error during test:', error.message);
  }
}

testJWTValidation();