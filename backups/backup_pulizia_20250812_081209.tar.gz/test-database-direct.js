import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function testSoftDelete() {
  try {
    console.log('🔍 Testing soft delete functionality...');
    
    // 1. Ottieni tutte le persone con roleType EMPLOYEE
    console.log('\n1. Getting all EMPLOYEE persons...');
    const allEmployees = await prisma.person.findMany({
      where: {
        personRoles: {
          some: {
            roleType: 'EMPLOYEE'
          }
        }
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        deletedAt: true,
        personRoles: {
          select: {
            roleType: true
          }
        }
      }
    });
    
    console.log(`Found ${allEmployees.length} employees total:`);
    allEmployees.forEach(emp => {
      console.log(`- ${emp.firstName} ${emp.lastName} (${emp.id}) - deletedAt: ${emp.deletedAt}`);
    });
    
    // 2. Ottieni solo le persone NON eliminate
    console.log('\n2. Getting only NON-DELETED EMPLOYEE persons...');
    const activeEmployees = await prisma.person.findMany({
      where: {
        deletedAt: null,
        personRoles: {
          some: {
            roleType: 'EMPLOYEE'
          }
        }
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        deletedAt: true
      }
    });
    
    console.log(`Found ${activeEmployees.length} active employees:`);
    activeEmployees.forEach(emp => {
      console.log(`- ${emp.firstName} ${emp.lastName} (${emp.id})`);
    });
    
    // 3. Verifica se ci sono persone con deletedAt impostato
    console.log('\n3. Checking for soft-deleted persons...');
    const deletedPersons = await prisma.person.findMany({
      where: {
        deletedAt: {
          not: null
        }
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        deletedAt: true,
        personRoles: {
          select: {
            roleType: true
          }
        }
      }
    });
    
    console.log(`Found ${deletedPersons.length} soft-deleted persons:`);
    deletedPersons.forEach(person => {
      console.log(`- ${person.firstName} ${person.lastName} (${person.id}) - deleted at: ${person.deletedAt}`);
      console.log(`  Roles: ${person.personRoles.map(r => r.roleType).join(', ')}`);
    });
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testSoftDelete();