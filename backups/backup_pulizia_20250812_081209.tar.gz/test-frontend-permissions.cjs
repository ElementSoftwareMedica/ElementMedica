const axios = require('axios');

async function testFrontendPermissions() {
  try {
    console.log('🔍 Testing frontend permissions loading...\n');
    
    // 1. Login tramite proxy (come fa il frontend)
    console.log('1. Login tramite proxy...');
    const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    if (!loginResponse.data.tokens?.access_token) {
      console.error('❌ Login failed - no access token');
      return;
    }
    
    const token = loginResponse.data.tokens.access_token;
    console.log('✅ Login successful');
    console.log('👤 User:', {
      email: loginResponse.data.user?.email,
      role: loginResponse.data.user?.role,
      roles: loginResponse.data.user?.roles
    });
    
    // 2. Test verify endpoint tramite proxy (come fa il frontend)
    console.log('\n2. Testing verify endpoint tramite proxy...');
    const verifyResponse = await axios.get('http://localhost:4003/api/v1/auth/verify', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('✅ Verify successful');
    console.log('📋 Verify response:', {
      valid: verifyResponse.data.valid,
      userRole: verifyResponse.data.user?.role,
      userRoles: verifyResponse.data.user?.roles,
      permissionsCount: Object.keys(verifyResponse.data.permissions || {}).length
    });
    
    // 3. Simula la conversione dei permessi come fa il frontend
    console.log('\n3. Simulating frontend permission conversion...');
    const backendPermissions = verifyResponse.data.permissions || {};
    
    // Simula convertBackendToFrontendPermissions
    const frontendPermissions = {};
    
    Object.keys(backendPermissions).forEach(backendKey => {
      if (backendPermissions[backendKey] === true) {
        // Copia il permesso così com'è
        frontendPermissions[backendKey] = true;
        
        // Aggiungi conversioni specifiche per i permessi che ci interessano
        if (backendKey === 'MANAGE_PUBLIC_CMS') {
          frontendPermissions['PUBLIC_CMS:READ'] = true;
          frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
          frontendPermissions['PUBLIC_CMS:read'] = true;
          frontendPermissions['PUBLIC_CMS:update'] = true;
        }
        if (backendKey === 'MANAGE_FORM_TEMPLATES') {
          frontendPermissions['form_templates:read'] = true;
          frontendPermissions['form_templates:update'] = true;
        }
        if (backendKey === 'MANAGE_FORM_SUBMISSIONS') {
          frontendPermissions['form_submissions:read'] = true;
          frontendPermissions['form_submissions:update'] = true;
        }
      }
    });
    
    console.log('📊 Frontend permissions count:', Object.keys(frontendPermissions).length);
    
    // 4. Test dei permessi specifici che servono alle pagine
    console.log('\n4. Testing specific page permissions...');
    const permissionsToTest = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE', 
      'form_templates:read',
      'form_submissions:read'
    ];
    
    permissionsToTest.forEach(permission => {
      const hasPermission = frontendPermissions[permission] === true;
      console.log(`  ${hasPermission ? '✅' : '❌'} ${permission}: ${hasPermission}`);
    });
    
    // 5. Simula hasPermission del frontend
    console.log('\n5. Simulating frontend hasPermission function...');
    
    function simulateHasPermission(resourceOrPermission, action) {
      let permissionToCheck;
      
      if (action) {
        permissionToCheck = `${resourceOrPermission}:${action}`;
      } else {
        permissionToCheck = resourceOrPermission;
      }
      
      // Verifica permesso diretto
      if (frontendPermissions[permissionToCheck] === true) {
        return true;
      }
      
      // Se abbiamo due parametri e action è 'read', verifica se c'è qualche permesso per la risorsa
      if (action === 'read') {
        const resourcePermissions = Object.keys(frontendPermissions)
          .filter(key => key.startsWith(resourceOrPermission + ':') && frontendPermissions[key] === true);
        
        if (resourcePermissions.length > 0) {
          return true;
        }
      }
      
      return false;
    }
    
    // Test delle chiamate che fanno le pagine
    const pageTests = [
      { page: 'PublicCMSPage', call: "hasPermission('PUBLIC_CMS', 'READ')", resource: 'PUBLIC_CMS', action: 'READ' },
      { page: 'PublicCMSPage', call: "hasPermission('PUBLIC_CMS', 'UPDATE')", resource: 'PUBLIC_CMS', action: 'UPDATE' },
      { page: 'FormTemplatesPage', call: "hasPermission('form_templates', 'read')", resource: 'form_templates', action: 'read' },
      { page: 'FormSubmissionsPage', call: "hasPermission('form_submissions', 'read')", resource: 'form_submissions', action: 'read' }
    ];
    
    pageTests.forEach(test => {
      const result = simulateHasPermission(test.resource, test.action);
      console.log(`  ${result ? '✅' : '❌'} ${test.page}: ${test.call} = ${result}`);
    });
    
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

testFrontendPermissions();