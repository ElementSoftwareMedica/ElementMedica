/**
 * Test per verificare l'importazione CSV con codice fiscale
 */

import fs from 'fs';
import FormData from 'form-data';
import fetch from 'node-fetch';

const API_BASE = 'http://localhost:4003';
const TEST_CSV_PATH = './test-codice-fiscale.csv';

async function testImportCSV() {
  console.log('🧪 Test importazione CSV con codice fiscale\n');

  try {
    // 1. Login per ottenere il token
    console.log('1. 🔐 Login...');
    const loginResponse = await fetch(`${API_BASE}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      throw new Error(`Login failed: ${loginResponse.status}`);
    }

    const loginData = await loginResponse.json();
    const token = loginData.tokens.access_token;
    console.log('   ✅ Login riuscito');

    // 2. Importa il file CSV
    console.log('\n2. 📤 Importazione CSV...');
    const formData = new FormData();
    formData.append('file', fs.createReadStream(TEST_CSV_PATH));
    formData.append('options', JSON.stringify({
      skipDuplicates: false,
      updateExisting: true
    }));

    const importResponse = await fetch(`${API_BASE}/api/v1/persons/import`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        ...formData.getHeaders()
      },
      body: formData
    });

    if (!importResponse.ok) {
      const errorText = await importResponse.text();
      throw new Error(`Import failed: ${importResponse.status} - ${errorText}`);
    }

    const importResult = await importResponse.json();
    console.log('   ✅ Importazione completata');
    console.log(`   📊 Risultato: ${JSON.stringify(importResult, null, 2)}`);

    // 3. Verifica le persone importate
    console.log('\n3. 🔍 Verifica persone importate...');
    const personsResponse = await fetch(`${API_BASE}/api/v1/persons?limit=10`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!personsResponse.ok) {
      throw new Error(`Get persons failed: ${personsResponse.status}`);
    }

    const personsData = await personsResponse.json();
    console.log('   ✅ Persone recuperate');

    // Filtra le persone appena importate
    const importedPersons = personsData.data.filter(person => 
      ['mario.rossi@test.com', 'giulia.verdi@test.com', 'luca.bianchi@test.com'].includes(person.email)
    );

    console.log(`\n📋 Persone importate (${importedPersons.length}):`);
    importedPersons.forEach((person, index) => {
      const birthDateFormatted = person.birthDate ? 
        new Date(person.birthDate).toLocaleDateString('it-IT') : 
        'Non disponibile';
      
      console.log(`   ${index + 1}. ${person.firstName} ${person.lastName}`);
      console.log(`      Email: ${person.email}`);
      console.log(`      Codice Fiscale: ${person.taxCode || 'Non disponibile'}`);
      console.log(`      Data di nascita: ${birthDateFormatted}`);
      console.log(`      Username: ${person.username || 'Non disponibile'}`);
      console.log('');
    });

    // 4. Test dettaglio persona
    if (importedPersons.length > 0) {
      console.log('4. 🔍 Test dettaglio persona...');
      const firstPerson = importedPersons[0];
      
      const detailResponse = await fetch(`${API_BASE}/api/v1/persons/${firstPerson.id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (detailResponse.ok) {
        const detailData = await detailResponse.json();
        console.log('   ✅ Dettaglio persona recuperato');
        console.log(`   📋 Dati completi: ${JSON.stringify(detailData, null, 2)}`);
      } else {
        console.log('   ❌ Errore nel recupero dettaglio persona');
      }
    }

    console.log('\n🎉 Test completato con successo!');

  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
    process.exit(1);
  }
}

testImportCSV();