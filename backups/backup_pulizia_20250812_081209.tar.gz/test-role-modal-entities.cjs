const axios = require('axios');

async function testRoleModalEntities() {
  console.log('🔍 Test caricamento entità per modal ruoli...');
  
  try {
    // 1. Login per ottenere token
    console.log('📝 Effettuo login...');
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    console.log('📄 Risposta login:', JSON.stringify(loginResponse.data, null, 2));
    
    if (!loginResponse.data.success) {
      throw new Error('Login fallito');
    }
    
    const token = loginResponse.data.tokens?.access_token || loginResponse.data.data?.token || loginResponse.data.token;
    console.log('✅ Login effettuato con successo');
    
    // 2. Test endpoint entità
    console.log('🔍 Test endpoint /api/advanced-permissions/entities...');
    const entitiesResponse = await axios.get('http://localhost:4001/api/advanced-permissions/entities', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Endpoint entità risponde correttamente');
    console.log(`📊 Totale entità: ${entitiesResponse.data.entities.length}`);
    
    // 3. Verifica entità specifiche
    const entities = entitiesResponse.data.entities;
    const formTemplates = entities.find(e => e.id === 'form_templates');
    const formSubmissions = entities.find(e => e.id === 'form_submissions');
    const publicCms = entities.find(e => e.id === 'public_cms');
    
    console.log('\n📋 Verifica entità specifiche:');
    console.log(`form_templates: ${formTemplates ? '✅ Presente' : '❌ Mancante'}`);
    if (formTemplates) {
      console.log(`  - displayName: ${formTemplates.displayName}`);
      console.log(`  - campi: ${formTemplates.fields.length}`);
    }
    
    console.log(`form_submissions: ${formSubmissions ? '✅ Presente' : '❌ Mancante'}`);
    if (formSubmissions) {
      console.log(`  - displayName: ${formSubmissions.displayName}`);
      console.log(`  - campi: ${formSubmissions.fields.length}`);
    }
    
    console.log(`public_cms: ${publicCms ? '✅ Presente' : '❌ Mancante'}`);
    if (publicCms) {
      console.log(`  - displayName: ${publicCms.displayName}`);
      console.log(`  - campi: ${publicCms.fields.length}`);
    }
    
    // Test endpoint permessi
    console.log('\n🔍 Testing permissions endpoint...');
    const permissionsResponse = await axios.get('http://localhost:4003/api/v1/roles/permissions', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Endpoint permessi risponde correttamente');
    
    // La struttura è { success: true, data: { permissions: {...}, tenants: [...] } }
    const permissionsData = permissionsResponse.data.data?.permissions || {};
    console.log('📊 Struttura permessi:', Object.keys(permissionsData));
    
    // Debug: mostra la struttura delle entità che ci interessano
    console.log('\n🔍 Debug struttura entità specifiche:');
    ['form_templates', 'form_submissions', 'public_cms'].forEach(entity => {
      if (permissionsData[entity]) {
        console.log(`${entity}:`, JSON.stringify(permissionsData[entity], null, 2));
      } else {
        console.log(`${entity}: NON TROVATO`);
      }
    });
    
    // 5. Simula la creazione dei permessi CRUD come nel RoleModal
    console.log('\n🔧 Simulazione creazione permessi CRUD...');
    
    // Converte la struttura raggruppata in un array piatto come fa il RolesService
    const permissionsArray = [];
    Object.entries(permissionsData).forEach(([category, categoryData]) => {
      if (categoryData.permissions && Array.isArray(categoryData.permissions)) {
        categoryData.permissions.forEach((perm) => {
          // I permessi hanno già action e resource definiti
          if (perm.key && perm.action && perm.resource) {
            permissionsArray.push({
              id: perm.key,
              name: perm.label || perm.name,
              category: category,
              description: perm.description,
              resource: perm.resource,
              action: perm.action,
              entity: perm.resource, // entity è uguale a resource
              scope: perm.scope || 'all'
            });
          } else {
            // Fallback per permessi con formato diverso
            const parts = perm.key?.split('.') || [];
            if (parts.length >= 2) {
              const action = parts[0]?.toLowerCase() || 'view';
              const entity = parts.slice(1).join('_').toLowerCase() || category;
              
              if (action && entity) {
                permissionsArray.push({
                  id: perm.key,
                  name: perm.label || perm.name,
                  category: category,
                  description: perm.description,
                  resource: category,
                  action: action,
                  entity: entity,
                  scope: 'all'
                });
              }
            }
          }
        });
      }
    });
    
    console.log('📊 Totale permessi convertiti:', permissionsArray.length);
    
    // Verifica permessi specifici per le entità
    const permissions = permissionsArray;
    const formTemplatePerms = permissions.filter(p => 
      p.entity === 'form_templates' || p.resource === 'form_templates'
    );
    const formSubmissionPerms = permissions.filter(p => 
      p.entity === 'form_submissions' || p.resource === 'form_submissions'
    );
    const publicCmsPerms = permissions.filter(p => 
      p.entity === 'public_cms' || p.resource === 'public_cms'
    );
    
    console.log('\n📋 Verifica permessi specifici:');
    console.log(`form_templates permessi: ${formTemplatePerms.length}`);
    if (formTemplatePerms.length > 0) {
      console.log('  - Permessi trovati:', formTemplatePerms.map(p => p.id || p.name).join(', '));
    }
    
    console.log(`form_submissions permessi: ${formSubmissionPerms.length}`);
    if (formSubmissionPerms.length > 0) {
      console.log('  - Permessi trovati:', formSubmissionPerms.map(p => p.id || p.name).join(', '));
    }
    
    console.log(`public_cms permessi: ${publicCmsPerms.length}`);
    if (publicCmsPerms.length > 0) {
      console.log('  - Permessi trovati:', publicCmsPerms.map(p => p.id || p.name).join(', '));
    }
    
    // 6. Simula creazione permessi CRUD come fa il RoleModal
    console.log('\n🔧 Simulazione creazione permessi CRUD (come RoleModal):');
    
    const testEntities = [formTemplates, formSubmissions, publicCms].filter(Boolean);
    
    testEntities.forEach(entity => {
      console.log(`\n📝 Entità: ${entity.displayName} (${entity.name})`);
      const normalizedName = entity.name.trim().toUpperCase();
      
      const crudPermissions = [
        `CREATE_${normalizedName}`,
        `VIEW_${normalizedName}`,
        `EDIT_${normalizedName}`,
        `DELETE_${normalizedName}`
      ];
      
      console.log('  Permessi CRUD generati:');
      crudPermissions.forEach(perm => {
        console.log(`    - ${perm}`);
      });
    });
    
    console.log('\n✅ Test completato con successo!');
    
  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
    if (error.response) {
      console.error('📄 Dettagli risposta:', {
        status: error.response.status,
        data: error.response.data
      });
    }
  }
}

testRoleModalEntities();