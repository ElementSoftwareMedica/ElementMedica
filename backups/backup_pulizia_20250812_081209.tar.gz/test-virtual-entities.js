#!/usr/bin/env node

/**
 * Test delle Route delle Entità Virtuali
 * Verifica il funzionamento delle API per Dipendenti e Formatori
 */

import fetch from 'node-fetch';

const API_BASE = 'http://localhost:4001';
const PROXY_BASE = 'http://localhost:4003';

// Credenziali di test
const TEST_CREDENTIALS = {
  identifier: 'admin@example.com',
  password: 'Admin123!'
};

let authToken = null;

/**
 * Effettua il login e ottiene il token di autenticazione
 */
async function login() {
  console.log('🔐 Effettuando login...');
  
  try {
    const response = await fetch(`${PROXY_BASE}/api/v1/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(TEST_CREDENTIALS)
    });
    
    if (!response.ok) {
      throw new Error(`Login failed: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    authToken = data.tokens.access_token;
    
    console.log('✅ Login effettuato con successo');
    return authToken;
  } catch (error) {
    console.error('❌ Errore durante il login:', error.message);
    throw error;
  }
}

/**
 * Testa un endpoint specifico
 */
async function testEndpoint(method, url, body = null, description = '') {
  console.log(`\n🧪 Test: ${description || `${method} ${url}`}`);
  
  try {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      }
    };
    
    if (body) {
      options.body = JSON.stringify(body);
    }
    
    const response = await fetch(url, options);
    const responseText = await response.text();
    
    let responseData;
    try {
      responseData = JSON.parse(responseText);
    } catch {
      responseData = responseText;
    }
    
    console.log(`   Status: ${response.status}`);
    console.log(`   Response:`, JSON.stringify(responseData, null, 2).substring(0, 200) + '...');
    
    if (response.ok) {
      console.log('   ✅ Test PASSED');
    } else {
      console.log('   ❌ Test FAILED');
    }
    
    return { success: response.ok, status: response.status, data: responseData };
  } catch (error) {
    console.log(`   ❌ Test ERROR: ${error.message}`);
    return { success: false, error: error.message };
  }
}

/**
 * Test delle route dei dipendenti
 */
async function testEmployeesRoutes() {
  console.log('\n📋 === TEST ROUTE DIPENDENTI ===');
  
  // Test GET /api/employees
  await testEndpoint('GET', `${API_BASE}/api/employees`, null, 'Lista dipendenti (API diretta)');
  await testEndpoint('GET', `${PROXY_BASE}/api/employees`, null, 'Lista dipendenti (tramite proxy)');
  
  // Test GET /api/v1/employees
  await testEndpoint('GET', `${PROXY_BASE}/api/v1/employees`, null, 'Lista dipendenti (v1)');
  
  // Test export dipendenti
  await testEndpoint('GET', `${PROXY_BASE}/api/employees/export`, null, 'Export dipendenti');
}

/**
 * Test delle route dei formatori
 */
async function testTrainersRoutes() {
  console.log('\n👨‍🏫 === TEST ROUTE FORMATORI ===');
  
  // Test GET /api/trainers
  await testEndpoint('GET', `${API_BASE}/api/trainers`, null, 'Lista formatori (API diretta)');
  await testEndpoint('GET', `${PROXY_BASE}/api/trainers`, null, 'Lista formatori (tramite proxy)');
  
  // Test GET /api/v1/trainers
  await testEndpoint('GET', `${PROXY_BASE}/api/v1/trainers`, null, 'Lista formatori (v1)');
  
  // Test export formatori
  await testEndpoint('GET', `${PROXY_BASE}/api/trainers/export`, null, 'Export formatori');
}

/**
 * Test delle route comuni delle entità virtuali
 */
async function testVirtualEntitiesRoutes() {
  console.log('\n🔧 === TEST ROUTE ENTITÀ VIRTUALI ===');
  
  // Test permessi entità virtuali
  await testEndpoint('GET', `${API_BASE}/api/virtual-entities/permissions`, null, 'Permessi entità virtuali (API diretta)');
  await testEndpoint('GET', `${PROXY_BASE}/api/virtual-entities/permissions`, null, 'Permessi entità virtuali (tramite proxy)');
  await testEndpoint('GET', `${PROXY_BASE}/api/v1/virtual-entities/permissions`, null, 'Permessi entità virtuali (v1)');
}

/**
 * Test di health check
 */
async function testHealthChecks() {
  console.log('\n🏥 === TEST HEALTH CHECKS ===');
  
  await testEndpoint('GET', `${API_BASE}/health`, null, 'Health check API server');
  await testEndpoint('GET', `${PROXY_BASE}/health`, null, 'Health check proxy server');
}

/**
 * Funzione principale
 */
async function main() {
  console.log('🚀 Avvio test delle entità virtuali...\n');
  
  try {
    // 1. Health checks
    await testHealthChecks();
    
    // 2. Login
    await login();
    
    // 3. Test route dipendenti
    await testEmployeesRoutes();
    
    // 4. Test route formatori
    await testTrainersRoutes();
    
    // 5. Test route comuni
    await testVirtualEntitiesRoutes();
    
    console.log('\n🎉 Test completati!');
    
  } catch (error) {
    console.error('\n💥 Errore durante i test:', error.message);
    process.exit(1);
  }
}

// Avvia i test
main().catch(console.error);