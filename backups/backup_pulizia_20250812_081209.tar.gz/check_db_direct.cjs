const { Client } = require('pg');

async function checkDatabase() {
  const client = new Client({
    connectionString: "postgresql://postgres:password@localhost:5432/training_platform?schema=public"
  });

  try {
    await client.connect();
    console.log('🔗 Connesso al database PostgreSQL\n');

    // Verifica se la tabella Person esiste
    const tableCheck = await client.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'Person'
      );
    `);
    
    console.log('📋 Tabella Person esiste:', tableCheck.rows[0].exists);

    if (tableCheck.rows[0].exists) {
      // Conta totale persone
      const countResult = await client.query('SELECT COUNT(*) FROM "Person"');
      console.log('📊 Totale persone nel database:', countResult.rows[0].count);

      // Cerca persone con il codice fiscale del test
      const taxCodeResult = await client.query(`
        SELECT id, "firstName", "lastName", email, "taxCode", "deletedAt"
        FROM "Person" 
        WHERE "taxCode" = $1
      `, ['RSSMRA80A01H501Z']);
      
      console.log('\n🔍 Persone con taxCode RSSMRA80A01H501Z:');
      console.log(JSON.stringify(taxCodeResult.rows, null, 2));

      // Mostra le prime 5 persone
      const sampleResult = await client.query(`
        SELECT id, "firstName", "lastName", email, "taxCode", "deletedAt"
        FROM "Person" 
        ORDER BY "createdAt" DESC
        LIMIT 5
      `);
      
      console.log('\n📋 Prime 5 persone (più recenti):');
      console.log(JSON.stringify(sampleResult.rows, null, 2));
    }

  } catch (error) {
    console.error('❌ Errore:', error);
  } finally {
    await client.end();
  }
}

checkDatabase();