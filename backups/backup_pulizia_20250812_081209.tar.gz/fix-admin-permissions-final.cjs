const { PrismaClient } = require('./backend/node_modules/@prisma/client');
const prisma = new PrismaClient();

async function fixAdminPermissions() {
  try {
    console.log('🔧 Fixing admin permissions for new entities...');
    
    // Trova l'admin
    const admin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' }
    });
    
    if (!admin) {
      console.log('❌ Admin not found');
      return;
    }
    
    console.log('👤 Admin found:', admin.id);
    
    // Permessi richiesti per le nuove entità
    const requiredPermissions = [
      // CMS Permissions
      'VIEW_CMS',
      'CREATE_CMS', 
      'EDIT_CMS',
      'DELETE_CMS',
      'MANAGE_PUBLIC_CONTENT',
      'READ_PUBLIC_CONTENT',
      
      // Form Templates Permissions
      'VIEW_FORM_TEMPLATES',
      'CREATE_FORM_TEMPLATES',
      'EDIT_FORM_TEMPLATES', 
      'DELETE_FORM_TEMPLATES',
      'MANAGE_FORM_TEMPLATES',
      
      // Form Submissions Permissions
      'VIEW_FORM_SUBMISSIONS',
      'CREATE_FORM_SUBMISSIONS',
      'EDIT_FORM_SUBMISSIONS',
      'DELETE_FORM_SUBMISSIONS',
      'MANAGE_FORM_SUBMISSIONS',
      'EXPORT_FORM_SUBMISSIONS',
      
      // Submissions Permissions (legacy compatibility)
      'VIEW_SUBMISSIONS',
      'CREATE_SUBMISSIONS',
      'EDIT_SUBMISSIONS',
      'DELETE_SUBMISSIONS',
      'MANAGE_SUBMISSIONS',
      'EXPORT_SUBMISSIONS',
      
      // Templates Permissions
      'VIEW_TEMPLATES',
      'CREATE_TEMPLATES',
      'EDIT_TEMPLATES',
      'DELETE_TEMPLATES',
      'MANAGE_TEMPLATES'
    ];
    
    console.log('📋 Required permissions:', requiredPermissions.length);
    
    // Trova i ruoli dell'admin
    const adminRoles = await prisma.personRole.findMany({
      where: { 
        personId: admin.id,
        isActive: true
      },
      include: {
        permissions: true
      }
    });
    
    console.log('👥 Admin roles found:', adminRoles.length);
    
    if (adminRoles.length === 0) {
      console.log('❌ No active roles found for admin');
      return;
    }
    
    // Prendi il primo ruolo attivo (o quello principale)
    const primaryRole = adminRoles.find(role => role.isPrimary) || adminRoles[0];
    console.log('🎯 Using role:', primaryRole.id, 'Type:', primaryRole.roleType);
    
    // Verifica permessi esistenti per questo ruolo
    const existingPermissions = await prisma.rolePermission.findMany({
      where: { 
        personRoleId: primaryRole.id,
        isGranted: true
      }
    });
    
    const existingPermissionNames = existingPermissions.map(p => p.permission);
    console.log('✅ Existing permissions:', existingPermissionNames.length);
    
    // Trova permessi mancanti
    const missingPermissions = requiredPermissions.filter(
      perm => !existingPermissionNames.includes(perm)
    );
    
    console.log('❌ Missing permissions:', missingPermissions.length);
    missingPermissions.forEach(perm => console.log('  -', perm));
    
    if (missingPermissions.length === 0) {
      console.log('✅ All permissions already assigned!');
      
      // Verifica comunque che siano isGranted=true
      const notGrantedPermissions = await prisma.rolePermission.findMany({
        where: {
          personRoleId: primaryRole.id,
          isGranted: false,
          permission: { in: requiredPermissions }
        }
      });
      
      if (notGrantedPermissions.length > 0) {
        console.log('🔄 Updating not granted permissions...');
        for (const perm of notGrantedPermissions) {
          await prisma.rolePermission.update({
            where: { id: perm.id },
            data: { isGranted: true }
          });
          console.log('  ✅ Granted:', perm.permission);
        }
      }
      
      return;
    }
    
    // Aggiungi permessi mancanti
    for (const permission of missingPermissions) {
      // Verifica se esiste già (anche se non granted)
      const existing = await prisma.rolePermission.findFirst({
        where: {
          personRoleId: primaryRole.id,
          permission: permission
        }
      });
      
      if (existing) {
        // Aggiorna a isGranted=true
        await prisma.rolePermission.update({
          where: { id: existing.id },
          data: { isGranted: true }
        });
        console.log('  🔄 Updated:', permission);
      } else {
        // Crea nuovo permesso
        await prisma.rolePermission.create({
          data: {
            personRoleId: primaryRole.id,
            permission: permission,
            isGranted: true,
            grantedBy: admin.id
          }
        });
        console.log('  ➕ Added:', permission);
      }
    }
    
    console.log('✅ Admin permissions fixed successfully!');
    
    // Verifica finale
    const finalPermissions = await prisma.rolePermission.findMany({
      where: { 
        personRoleId: primaryRole.id,
        isGranted: true
      }
    });
    
    const finalPermissionNames = finalPermissions.map(p => p.permission);
    const hasAllRequired = requiredPermissions.every(perm => 
      finalPermissionNames.includes(perm)
    );
    
    console.log('📊 Final verification:');
    console.log('  Total permissions:', finalPermissions.length);
    console.log('  Has all required:', hasAllRequired ? '✅' : '❌');
    
    if (!hasAllRequired) {
      const stillMissing = requiredPermissions.filter(
        perm => !finalPermissionNames.includes(perm)
      );
      console.log('  Still missing:', stillMissing);
    }
    
  } catch (error) {
    console.error('❌ Error fixing admin permissions:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixAdminPermissions();