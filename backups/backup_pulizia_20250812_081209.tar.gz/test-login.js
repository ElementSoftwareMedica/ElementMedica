#!/usr/bin/env node

import fetch from 'node-fetch';

async function testLogin() {
  try {
    console.log('🔐 Testing login...');
    
    const response = await fetch('http://localhost:4003/api/v1/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });
    
    const data = await response.json();
    console.log('Login response:', JSON.stringify(data, null, 2));
    
    if (data.tokens?.access_token) {
      console.log('\n✅ Login successful!');
      console.log('Token:', data.tokens.access_token);
      console.log('Tenant ID:', data.user?.tenantId);
      
      // Test advanced submissions endpoint
      console.log('\n🔍 Testing /api/v1/submissions/advanced...');
      const advancedResponse = await fetch('http://localhost:4003/api/v1/submissions/advanced', {
        headers: {
          'Authorization': `Bearer ${data.tokens.access_token}`,
          'X-Tenant-ID': data.user?.tenantId || 'default-company'
        }
      });
      
      console.log('Advanced submissions status:', advancedResponse.status);
      const advancedData = await advancedResponse.text();
      console.log('Advanced submissions response:', advancedData);
    } else {
      console.log('❌ Login failed');
    }
    
  } catch (error) {
    console.error('Error:', error);
  }
}

testLogin();