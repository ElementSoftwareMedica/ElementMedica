const axios = require('axios');

const BASE_URL = 'http://localhost:4003';

async function testLoginWithTenant() {
  try {
    console.log('🔍 Testing Login with Updated Tenant');
    console.log('====================================');

    // 1. Effettua il login per ottenere un nuovo token
    console.log('1. Performing fresh login...');
    const loginResponse = await axios.post(`${BASE_URL}/api/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    if (loginResponse.data.success) {
      console.log('✅ Login successful');
      const token = loginResponse.data.tokens?.access_token;
      const user = loginResponse.data.user;
      
      console.log('👤 User data from login:', {
        id: user.id,
        email: user.email,
        tenantId: user.tenantId,
        roles: user.roles
      });

      // 2. Testa l'endpoint /api/tenants/current con il nuovo token
      console.log('\n2. Testing /api/tenants/current with fresh token...');
      try {
        const tenantResponse = await axios.get(`${BASE_URL}/api/tenants/current`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        console.log('✅ Tenant endpoint successful');
        console.log('🏢 Tenant data:', tenantResponse.data);
        
      } catch (tenantError) {
        console.log('❌ Tenant endpoint failed:', tenantError.response?.data || tenantError.message);
      }

      // 3. Testa l'endpoint /api/persons con il nuovo token
      console.log('\n3. Testing /api/persons with fresh token...');
      try {
        const personsResponse = await axios.get(`${BASE_URL}/api/persons`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        console.log('✅ Persons endpoint successful');
        console.log('👥 Persons data:', {
          total: personsResponse.data.total,
          count: personsResponse.data.persons?.length || 0,
          page: personsResponse.data.page
        });
        
      } catch (personsError) {
        console.log('❌ Persons endpoint failed:', personsError.response?.data || personsError.message);
      }

      // 4. Testa l'endpoint /api/counters con il nuovo token
      console.log('\n4. Testing /api/counters with fresh token...');
      try {
        const countersResponse = await axios.get(`${BASE_URL}/api/counters`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        console.log('✅ Counters endpoint successful');
        console.log('📊 Counters data:', countersResponse.data);
        
      } catch (countersError) {
        console.log('❌ Counters endpoint failed:', countersError.response?.data || countersError.message);
      }

    } else {
      console.log('❌ Login failed:', loginResponse.data);
    }

  } catch (error) {
    console.error('❌ Error during test:', error.response?.data || error.message);
  }
}

testLoginWithTenant();