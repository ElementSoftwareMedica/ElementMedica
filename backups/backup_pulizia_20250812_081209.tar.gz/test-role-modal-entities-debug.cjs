#!/usr/bin/env node

/**
 * Test per verificare il caricamento delle entità nel RoleModal
 * Simula la chiamata che fa il frontend per caricare le entità
 */

const axios = require('axios');

const API_BASE_URL = 'http://localhost:4001';

async function login() {
  try {
    const response = await axios.post(`${API_BASE_URL}/api/v1/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    return response.data.token;
  } catch (error) {
    console.error('❌ Errore login:', error.message);
    throw error;
  }
}

async function testEntityLoading() {
  console.log('🧪 Test caricamento entità per RoleModal');
  console.log('=' .repeat(50));
  
  try {
    // Login per ottenere il token
    console.log('🔐 Effettuo login...');
    const token = await login();
    console.log('✅ Login effettuato con successo');
    
    // Configura headers per le richieste autenticate
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    
    // Test 1: Verifica endpoint entità
    console.log('\n📡 Test 1: Chiamata API entità');
    const entitiesResponse = await axios.get(`${API_BASE_URL}/api/advanced-permissions/entities`, { headers });
    
    console.log('✅ Status:', entitiesResponse.status);
    console.log('📊 Numero entità:', entitiesResponse.data.length);
    
    // Verifica entità critiche
    const criticalEntities = ['form_templates', 'form_submissions', 'public_cms'];
    const foundCritical = criticalEntities.filter(entity => 
      entitiesResponse.data.some(e => e.name === entity)
    );
    
    console.log('\n🔍 Entità critiche trovate:', foundCritical);
    console.log('❌ Entità critiche mancanti:', criticalEntities.filter(e => !foundCritical.includes(e)));
    
    // Mostra dettagli entità critiche
    console.log('\n📋 Dettagli entità critiche:');
    criticalEntities.forEach(entityName => {
      const entity = entitiesResponse.data.find(e => e.name === entityName);
      if (entity) {
        console.log(`  ✅ ${entityName}:`);
        console.log(`     - Display Name: ${entity.displayName}`);
        console.log(`     - Fields: ${entity.fields?.length || 0}`);
        console.log(`     - Icon: ${entity.icon || 'N/A'}`);
      } else {
        console.log(`  ❌ ${entityName}: NON TROVATA`);
      }
    });
    
    // Test 2: Simula creazione permessi CRUD per entità critiche
    console.log('\n🔧 Test 2: Generazione permessi CRUD');
    criticalEntities.forEach(entityName => {
      const entity = entitiesResponse.data.find(e => e.name === entityName);
      if (entity) {
        const normalizedName = entity.name.trim().toUpperCase();
        const crudPermissions = [
          `CREATE_${normalizedName}`,
          `VIEW_${normalizedName}`,
          `EDIT_${normalizedName}`,
          `DELETE_${normalizedName}`
        ];
        
        console.log(`\n  📝 ${entity.displayName} (${entity.name}):`);
        crudPermissions.forEach(perm => {
          console.log(`     - ${perm}`);
        });
      }
    });
    
    // Test 3: Verifica se le entità hanno tutti i campi necessari
    console.log('\n🔍 Test 3: Validazione struttura entità');
    const requiredFields = ['name', 'displayName', 'fields', 'icon'];
    
    entitiesResponse.data.forEach(entity => {
      const missingFields = requiredFields.filter(field => !entity[field]);
      if (missingFields.length > 0) {
        console.log(`⚠️  ${entity.name || 'UNNAMED'}: campi mancanti: ${missingFields.join(', ')}`);
      }
    });
    
    // Test 4: Verifica endpoint permessi
    console.log('\n📡 Test 4: Chiamata API permessi');
    const permissionsResponse = await axios.get(`${API_BASE_URL}/api/roles/permissions`, { headers });
    console.log('✅ Permessi caricati:', permissionsResponse.data.length);
    
    // Cerca permessi relativi alle entità critiche
    console.log('\n🔍 Permessi per entità critiche:');
    criticalEntities.forEach(entityName => {
      const normalizedName = entityName.toUpperCase();
      const relatedPermissions = permissionsResponse.data.filter(p => 
        p.id.includes(normalizedName) || p.name.toLowerCase().includes(entityName)
      );
      
      console.log(`\n  📝 ${entityName}:`);
      if (relatedPermissions.length > 0) {
        relatedPermissions.forEach(perm => {
          console.log(`     - ${perm.id}: ${perm.name}`);
        });
      } else {
        console.log(`     ❌ Nessun permesso trovato`);
      }
    });
    
    console.log('\n✅ Test completato con successo');
    
  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
    if (error.response) {
      console.error('📄 Response status:', error.response.status);
      console.error('📄 Response data:', error.response.data);
    }
  }
}

// Esegui il test
testEntityLoading();