import axios from 'axios';

async function debugAuth() {
  try {
    console.log('🔐 Testing authentication...');
    
    // Login to get token
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    console.log('✅ Login successful');
    console.log('Full response:', JSON.stringify(loginResponse.data, null, 2));
    
    const token = loginResponse.data.data.accessToken;
    console.log('Token extracted:', token ? 'YES' : 'NO');
    console.log('Token length:', token ? token.length : 'N/A');
    
    if (token) {
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };
      
      console.log('\n🧪 Testing authenticated endpoint...');
      try {
        const testResponse = await axios.get('http://localhost:4001/api/v1/companies', { headers });
        console.log('✅ Authenticated request successful:', testResponse.status);
      } catch (error) {
        console.log('❌ Authenticated request failed:', error.response?.status, error.response?.statusText);
        console.log('Error details:', JSON.stringify(error.response?.data, null, 2));
      }
    }
    
  } catch (error) {
    console.error('❌ Login failed:', error.response?.status, error.response?.statusText);
    if (error.response?.data) {
      console.error('Error details:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

debugAuth();