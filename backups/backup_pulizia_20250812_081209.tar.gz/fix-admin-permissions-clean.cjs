const { PrismaClient } = require('./backend/node_modules/@prisma/client');
const axios = require('axios');

const prisma = new PrismaClient();

async function fixAdminPermissions() {
  try {
    console.log('🔧 Verifica e correzione permessi admin...\n');

    // 1. Trova l'utente admin
    const admin = await prisma.person.findFirst({
      where: {
        email: 'admin@example.com'
      }
    });

    if (!admin) {
      console.log('❌ Admin non trovato');
      return;
    }

    console.log(`✅ Admin trovato: ${admin.email} (ID: ${admin.id})`);

    // 2. Trova o crea il ruolo ADMIN
    let adminRole = await prisma.personRole.findFirst({
      where: {
        personId: admin.id,
        roleType: 'ADMIN'
      },
      include: {
        permissions: true
      }
    });

    if (!adminRole) {
      console.log('🔧 Creazione ruolo ADMIN...');
      adminRole = await prisma.personRole.create({
        data: {
          personId: admin.id,
          roleType: 'ADMIN',
          isActive: true,
          tenantId: admin.tenantId || 'default-tenant',
          companyId: admin.companyId
        },
        include: {
          permissions: true
        }
      });
      console.log('✅ Ruolo ADMIN creato');
    } else {
      console.log(`✅ Ruolo ADMIN esistente trovato (ID: ${adminRole.id})`);
    }

    console.log(`   Permessi attuali: ${adminRole.permissions?.length || 0}`);

    // 3. Lista COMPLETA di tutti i permessi validi dall'enum PersonPermission
    const allValidPermissions = [
      'VIEW_COMPANIES', 'CREATE_COMPANIES', 'EDIT_COMPANIES', 'DELETE_COMPANIES',
      'VIEW_EMPLOYEES', 'CREATE_EMPLOYEES', 'EDIT_EMPLOYEES', 'DELETE_EMPLOYEES',
      'VIEW_TRAINERS', 'CREATE_TRAINERS', 'EDIT_TRAINERS', 'DELETE_TRAINERS',
      'VIEW_USERS', 'CREATE_USERS', 'EDIT_USERS', 'DELETE_USERS',
      'VIEW_COURSES', 'CREATE_COURSES', 'EDIT_COURSES', 'DELETE_COURSES',
      'MANAGE_ENROLLMENTS',
      'CREATE_DOCUMENTS', 'EDIT_DOCUMENTS', 'DELETE_DOCUMENTS', 'DOWNLOAD_DOCUMENTS',
      'ADMIN_PANEL', 'SYSTEM_SETTINGS', 'USER_MANAGEMENT', 'ROLE_MANAGEMENT',
      'TENANT_MANAGEMENT',
      'VIEW_GDPR_DATA', 'EXPORT_GDPR_DATA', 'DELETE_GDPR_DATA', 'MANAGE_CONSENTS',
      'VIEW_REPORTS', 'CREATE_REPORTS', 'EXPORT_REPORTS',
      'VIEW_DOCUMENTS',
      'ROLE_CREATE', 'ROLE_EDIT', 'ROLE_DELETE',
      'VIEW_ROLES', 'CREATE_ROLES', 'EDIT_ROLES', 'DELETE_ROLES',
      'MANAGE_USERS', 'ASSIGN_ROLES', 'REVOKE_ROLES',
      'VIEW_TENANTS', 'CREATE_TENANTS', 'EDIT_TENANTS', 'DELETE_TENANTS',
      'VIEW_ADMINISTRATION', 'CREATE_ADMINISTRATION', 'EDIT_ADMINISTRATION', 'DELETE_ADMINISTRATION',
      'VIEW_GDPR', 'CREATE_GDPR', 'EDIT_GDPR', 'DELETE_GDPR',
      'EDIT_REPORTS', 'DELETE_REPORTS',
      'VIEW_HIERARCHY', 'CREATE_HIERARCHY', 'EDIT_HIERARCHY', 'DELETE_HIERARCHY',
      'MANAGE_HIERARCHY', 'HIERARCHY_MANAGEMENT',
      'VIEW_PERSONS', 'CREATE_PERSONS', 'EDIT_PERSONS', 'DELETE_PERSONS',
      'VIEW_SCHEDULES', 'CREATE_SCHEDULES', 'EDIT_SCHEDULES', 'DELETE_SCHEDULES',
      'VIEW_QUOTES', 'CREATE_QUOTES', 'EDIT_QUOTES', 'DELETE_QUOTES',
      'VIEW_INVOICES', 'CREATE_INVOICES', 'EDIT_INVOICES', 'DELETE_INVOICES',
      'VIEW_CMS', 'CREATE_CMS', 'EDIT_CMS', 'DELETE_CMS',
      'MANAGE_PUBLIC_CONTENT', 'READ_PUBLIC_CONTENT',
      'VIEW_SUBMISSIONS', 'CREATE_SUBMISSIONS', 'EDIT_SUBMISSIONS', 'DELETE_SUBMISSIONS',
      'MANAGE_SUBMISSIONS', 'EXPORT_SUBMISSIONS',
      'VIEW_FORM_SUBMISSIONS', 'CREATE_FORM_SUBMISSIONS', 'EDIT_FORM_SUBMISSIONS', 'DELETE_FORM_SUBMISSIONS',
      'VIEW_FORM_TEMPLATES', 'CREATE_FORM_TEMPLATES', 'EDIT_FORM_TEMPLATES', 'DELETE_FORM_TEMPLATES',
      'MANAGE_FORM_TEMPLATES',
      'VIEW_PUBLIC_CMS', 'CREATE_PUBLIC_CMS', 'EDIT_PUBLIC_CMS', 'DELETE_PUBLIC_CMS',
      'MANAGE_PUBLIC_CMS',
      'VIEW_TEMPLATES', 'CREATE_TEMPLATES', 'EDIT_TEMPLATES', 'DELETE_TEMPLATES',
      'MANAGE_TEMPLATES',
      'MANAGE_FORM_SUBMISSIONS', 'EXPORT_FORM_SUBMISSIONS',
      'VIEW_NOTIFICATIONS', 'CREATE_NOTIFICATIONS', 'EDIT_NOTIFICATIONS', 'DELETE_NOTIFICATIONS',
      'MANAGE_NOTIFICATIONS', 'SEND_NOTIFICATIONS',
      'VIEW_AUDIT_LOGS', 'CREATE_AUDIT_LOGS', 'EDIT_AUDIT_LOGS', 'DELETE_AUDIT_LOGS',
      'MANAGE_AUDIT_LOGS', 'EXPORT_AUDIT_LOGS',
      'VIEW_API_KEYS', 'CREATE_API_KEYS', 'EDIT_API_KEYS', 'DELETE_API_KEYS',
      'MANAGE_API_KEYS', 'REGENERATE_API_KEYS'
    ];

    // 4. Trova permessi mancanti
    const existingPermissions = adminRole.permissions.map(p => p.permission);
    const missingPermissions = allValidPermissions.filter(p => !existingPermissions.includes(p));

    console.log(`\n📊 Analisi permessi:`);
    console.log(`   Permessi esistenti: ${existingPermissions.length}`);
    console.log(`   Permessi mancanti: ${missingPermissions.length}`);
    console.log(`   Totale permessi validi: ${allValidPermissions.length}`);

    if (missingPermissions.length > 0) {
      console.log(`\n🔧 Aggiunta ${missingPermissions.length} permessi mancanti...`);
      
      for (const permission of missingPermissions) {
        try {
          await prisma.rolePermission.create({
            data: {
              personRoleId: adminRole.id,
              permission: permission,
              isGranted: true,
              grantedBy: admin.id
            }
          });
          console.log(`   ✅ Aggiunto: ${permission}`);
        } catch (error) {
          console.log(`   ❌ Errore aggiungendo ${permission}:`, error.message);
        }
      }
    } else {
      console.log('\n✅ Tutti i permessi sono già presenti');
    }

    // 5. Verifica finale
    const finalRole = await prisma.personRole.findUnique({
      where: { id: adminRole.id },
      include: { permissions: true }
    });

    console.log(`\n✅ Permessi finali: ${finalRole.permissions.length}`);

    // 6. Test API
    console.log('\n🧪 Test API permessi...');
    try {
      // Login
      const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
        identifier: 'admin@example.com',
        password: 'Admin123!'
      });

      const token = loginResponse.data.data.accessToken;
      console.log('✅ Login riuscito');

      // Test permessi
      const permissionsResponse = await axios.get(`http://localhost:4001/api/v1/auth/permissions/${admin.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      const permissions = permissionsResponse.data.data.permissions;
      const permissionCount = Object.keys(permissions).length;
      
      console.log(`✅ API Test riuscito - Permessi attivi: ${permissionCount}`);
      
      // Verifica permessi critici
      const criticalPermissions = [
        'form_templates:read', 'form_templates:manage',
        'form_submissions:read', 'form_submissions:manage',
        'PUBLIC_CMS:read', 'PUBLIC_CMS:manage'
      ];
      
      console.log('\n🔍 Verifica permessi critici:');
      for (const perm of criticalPermissions) {
        const hasPermission = permissions[perm] === true;
        console.log(`   ${hasPermission ? '✅' : '❌'} ${perm}: ${hasPermission}`);
      }

    } catch (error) {
      console.log('❌ Errore test API:', error.message);
    }

  } catch (error) {
    console.error('❌ Errore:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixAdminPermissions();