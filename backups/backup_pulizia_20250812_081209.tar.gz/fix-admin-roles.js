#!/usr/bin/env node

/**
 * Script per verificare e correggere i ruoli dell'admin
 */

import { PrismaClient } from './backend/node_modules/.prisma/client/index.js';

const prisma = new PrismaClient();

async function fixAdminRoles() {
  try {
    console.log('🔧 Verifica e correzione ruoli admin...\n');

    // 1. Trova l'utente admin
    const admin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: {
          where: { isActive: true }
        }
      }
    });

    if (!admin) {
      console.log('❌ Admin non trovato!');
      return;
    }

    console.log(`✅ Admin trovato: ${admin.firstName} ${admin.lastName}`);
    console.log(`📧 Email: ${admin.email}`);
    console.log(`🎭 Global Role attuale: ${admin.globalRole}`);
    
    // 2. Verifica ruoli attuali
    console.log('\n🎭 Ruoli attuali:');
    admin.personRoles.forEach(role => {
      console.log(`  - ${role.roleType} (Primary: ${role.isPrimary}, Active: ${role.isActive})`);
    });

    // 3. Verifica se ha il ruolo ADMIN
    const hasAdminRole = admin.personRoles.some(role => role.roleType === 'ADMIN');
    const hasSuperAdminRole = admin.personRoles.some(role => role.roleType === 'SUPER_ADMIN');

    if (hasAdminRole || hasSuperAdminRole) {
      console.log('\n✅ L\'admin ha già un ruolo amministrativo appropriato.');
      
      // Aggiorna il globalRole se necessario
      if (admin.globalRole !== 'ADMIN' && admin.globalRole !== 'SUPER_ADMIN') {
        const newGlobalRole = hasSuperAdminRole ? 'SUPER_ADMIN' : 'ADMIN';
        await prisma.person.update({
          where: { id: admin.id },
          data: { globalRole: newGlobalRole }
        });
        console.log(`🔄 Global role aggiornato a: ${newGlobalRole}`);
      }
    } else {
      console.log('\n⚠️  L\'admin non ha un ruolo amministrativo. Aggiungendo ruolo ADMIN...');
      
      // Aggiungi il ruolo ADMIN
      await prisma.personRole.create({
        data: {
          personId: admin.id,
          roleType: 'ADMIN',
          isActive: true,
          isPrimary: true,
          tenantId: admin.tenantId,
          companyId: admin.companyId
        }
      });

      // Aggiorna il globalRole
      await prisma.person.update({
        where: { id: admin.id },
        data: { globalRole: 'ADMIN' }
      });

      console.log('✅ Ruolo ADMIN aggiunto con successo!');
    }

    // 4. Verifica finale
    const updatedAdmin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: {
          where: { isActive: true }
        }
      }
    });

    console.log('\n📊 Stato finale:');
    console.log(`🎭 Global Role: ${updatedAdmin.globalRole}`);
    console.log('🎭 Ruoli attivi:');
    updatedAdmin.personRoles.forEach(role => {
      console.log(`  - ${role.roleType} (Primary: ${role.isPrimary})`);
    });

    console.log('\n✅ Correzione completata!');

  } catch (error) {
    console.error('❌ Errore:', error.message);
    console.error(error.stack);
  } finally {
    await prisma.$disconnect();
  }
}

fixAdminRoles();