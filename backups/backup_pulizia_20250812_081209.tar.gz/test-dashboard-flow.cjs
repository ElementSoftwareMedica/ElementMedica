#!/usr/bin/env node

const axios = require('axios');

// Configurazione
const PROXY_URL = 'http://localhost:4003';
const API_URL = 'http://localhost:4001';

async function testDashboardFlow() {
  console.log('🧪 Testing Dashboard Flow...\n');

  try {
    // 1. Login per ottenere token
    console.log('1️⃣ Performing login...');
    const loginResponse = await axios.post(`${PROXY_URL}/api/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    console.log('✅ Login successful');
    
    const { user, tokens } = loginResponse.data;
    const actualToken = tokens?.access_token;
    console.log('   Token:', actualToken ? 'Present' : 'Missing');
    console.log('   User ID:', user?.id);
    console.log('   User Role:', user?.role);
    console.log('   Tenant ID:', user?.tenantId);

    // 2. Ottenere tenant corrente
    console.log('\n2️⃣ Getting current tenant...');
    const tenantResponse = await axios.get(`${PROXY_URL}/api/tenants/current`, {
      headers: {
        'Authorization': `Bearer ${actualToken}`,
        'Content-Type': 'application/json'
      }
    });

    const tenant = tenantResponse.data;
    console.log('✅ Tenant retrieved');
    console.log('   Tenant ID:', tenant?.id);
    console.log('   Tenant Name:', tenant?.name);

    // 3. Testare endpoint /api/counters con gli stessi header del frontend
    console.log('\n3️⃣ Testing /api/counters endpoint (via proxy)...');
    const countersResponse = await axios.get(`${PROXY_URL}/api/counters`, {
      headers: {
        'Authorization': `Bearer ${actualToken}`,
        'X-Tenant-ID': tenant.id,
        'Content-Type': 'application/json'
      }
    });

    console.log('✅ Counters response:', countersResponse.data);

    // 4. Testare endpoint /api/counters direttamente all'API server
    console.log('\n4️⃣ Testing /api/counters endpoint (direct to API)...');
    try {
      const directCountersResponse = await axios.get(`${API_URL}/api/counters`, {
        headers: {
          'Authorization': `Bearer ${actualToken}`,
          'X-Tenant-ID': tenant.id,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Direct counters response:', directCountersResponse.data);
    } catch (error) {
      console.log('❌ Direct API call failed:', error.response?.status, error.response?.data || error.message);
    }

    // 5. Verificare permessi utente
    console.log('\n5️⃣ Checking user permissions...');
    console.log('   User permissions:', user?.permissions || 'Not available');
    console.log('   User role:', user?.role);

    // 6. Testare altri endpoint correlati
    console.log('\n6️⃣ Testing related endpoints...');
    
    const endpoints = [
      '/api/companies',
      '/api/employees', 
      '/api/persons'
    ];

    for (const endpoint of endpoints) {
      try {
        const response = await axios.get(`${PROXY_URL}${endpoint}`, {
          headers: {
            'Authorization': `Bearer ${actualToken}`,
            'X-Tenant-ID': tenant.id,
            'Content-Type': 'application/json'
          }
        });
        console.log(`   ✅ ${endpoint}: ${Array.isArray(response.data) ? response.data.length : 'Not array'} items`);
      } catch (error) {
        console.log(`   ❌ ${endpoint}: ${error.response?.status} - ${error.response?.data?.message || error.message}`);
      }
    }

    // 7. Simulare chiamata con withCredentials (come fa il frontend)
    console.log('\n7️⃣ Testing with withCredentials (frontend simulation)...');
    try {
      const frontendResponse = await axios.get(`${PROXY_URL}/api/counters`, {
        headers: {
          'Authorization': `Bearer ${actualToken}`,
          'X-Tenant-ID': tenant.id,
          'Content-Type': 'application/json'
        },
        withCredentials: true
      });
      console.log('✅ Frontend simulation response:', frontendResponse.data);
    } catch (error) {
      console.log('❌ Frontend simulation failed:', error.response?.status, error.response?.data || error.message);
    }

  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
    if (error.response) {
      console.error('   Status:', error.response.status);
      console.error('   Headers:', error.response.headers);
    }
  }
}

testDashboardFlow();