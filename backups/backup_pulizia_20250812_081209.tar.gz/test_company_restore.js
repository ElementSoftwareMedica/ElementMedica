#!/usr/bin/env node

/**
 * Test Script per Ripristino Aziende Soft-Deleted
 * Verifica che la logica di ripristino funzioni correttamente
 */

import axios from 'axios';

const API_BASE = 'http://localhost:4003';
const CREDENTIALS = {
  identifier: 'admin@example.com',
  password: 'Admin123!'
};

let authToken = null;

async function login() {
  try {
    console.log('🔐 Effettuando login...');
    console.log(`📡 Connessione a: ${API_BASE}/api/v1/auth/login`);
    
    const response = await axios.post(`${API_BASE}/api/v1/auth/login`, CREDENTIALS, {
      timeout: 5000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    authToken = response.data.token;
    console.log('✅ Login effettuato con successo');
    console.log(`🔑 Token ricevuto: ${authToken.substring(0, 20)}...`);
    return true;
  } catch (error) {
    if (error.code === 'ECONNREFUSED') {
      console.error('❌ Errore di connessione: Server non raggiungibile');
      console.error(`   Verifica che il server sia attivo su ${API_BASE}`);
    } else if (error.response) {
      console.error('❌ Errore durante il login:', error.response.data);
      console.error(`   Status: ${error.response.status}`);
    } else {
      console.error('❌ Errore durante il login:', error.message);
    }
    return false;
  }
}

async function createCompany(companyData) {
  try {
    console.log(`🏢 Creando azienda: ${companyData.ragioneSociale}...`);
    const response = await axios.post(`${API_BASE}/api/v1/companies`, companyData, {
      headers: { Authorization: `Bearer ${authToken}` }
    });
    console.log('✅ Azienda creata:', response.data.id);
    return response.data;
  } catch (error) {
    console.error('❌ Errore creazione azienda:', error.response?.data || error.message);
    return null;
  }
}

async function deleteCompany(companyId) {
  try {
    console.log(`🗑️ Eliminando azienda: ${companyId}...`);
    const response = await axios.delete(`${API_BASE}/api/v1/companies/${companyId}`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });
    console.log('✅ Azienda eliminata (soft delete)');
    return true;
  } catch (error) {
    console.error('❌ Errore eliminazione azienda:', error.response?.data || error.message);
    return false;
  }
}

async function testCompanyRestore() {
  console.log('\n🧪 === TEST RIPRISTINO AZIENDA SOFT-DELETED ===\n');
  
  // 1. Login
  if (!await login()) {
    return;
  }
  
  // 2. Crea azienda di test
  const testCompany = {
    ragioneSociale: 'Test Azienda Ripristino SRL',
    piva: '12345678901',
    codiceFiscale: 'TSTAZR23T01H501Z',
    indirizzo: 'Via Test 123',
    citta: 'Milano',
    cap: '20100',
    provincia: 'MI'
  };
  
  const createdCompany = await createCompany(testCompany);
  if (!createdCompany) {
    return;
  }
  
  // 3. Elimina azienda (soft delete)
  if (!await deleteCompany(createdCompany.id)) {
    return;
  }
  
  // 4. Prova a ricreare la stessa azienda (dovrebbe ripristinare)
  console.log('\n🔄 Tentativo di ricreare azienda con stessa P.IVA...');
  const restoredCompany = await createCompany({
    ...testCompany,
    ragioneSociale: 'Test Azienda Ripristino SRL - AGGIORNATA',
    indirizzo: 'Via Test Nuova 456'
  });
  
  if (restoredCompany) {
    console.log('✅ SUCCESSO: Azienda ripristinata con ID:', restoredCompany.id);
    console.log('✅ Ragione sociale aggiornata:', restoredCompany.ragioneSociale);
    console.log('✅ Indirizzo aggiornato:', restoredCompany.indirizzo);
    
    // Verifica che sia lo stesso ID (ripristino)
    if (restoredCompany.id === createdCompany.id) {
      console.log('🎉 PERFETTO: Stesso ID confermato - ripristino avvenuto correttamente!');
    } else {
      console.log('⚠️ ATTENZIONE: ID diverso - potrebbe essere stata creata una nuova azienda');
    }
  } else {
    console.log('❌ FALLIMENTO: Ripristino non riuscito');
  }
  
  console.log('\n🧪 === FINE TEST ===\n');
}

// Esegui test
testCompanyRestore().catch(console.error);