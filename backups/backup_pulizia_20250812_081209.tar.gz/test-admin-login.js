import fetch from 'node-fetch';

async function testAdminLogin() {
  try {
    console.log('🔍 Testing admin login and permissions...');
    
    // Test login
    const loginResponse = await fetch('http://localhost:4001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    console.log('📊 Login response status:', loginResponse.status);

    if (!loginResponse.ok) {
      const errorText = await loginResponse.text();
      console.error('❌ Login failed:', errorText);
      return;
    }

    const loginData = await loginResponse.json();
    console.log('✅ Login successful');
    
    console.log('📋 Login response structure:', {
      success: loginData.success,
      hasUser: !!loginData.user,
      hasTokens: !!loginData.tokens,
      hasAccessToken: !!(loginData.tokens && loginData.tokens.access_token)
    });

    if (loginData.user) {
      console.log('\n👤 User info:', {
        id: loginData.user.id,
        email: loginData.user.email,
        firstName: loginData.user.firstName,
        lastName: loginData.user.lastName,
        globalRole: loginData.user.globalRole,
        tenantId: loginData.user.tenantId,
        companyId: loginData.user.companyId,
        status: loginData.user.status
      });
    }

    // Test employees route
    if (loginData.tokens && loginData.tokens.access_token) {
      console.log('\n🧪 Testing employees route...');
      
      const employeesResponse = await fetch('http://localhost:4001/api/employees', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${loginData.tokens.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      console.log('📊 Employees response status:', employeesResponse.status);
      
      if (employeesResponse.ok) {
        const employeesData = await employeesResponse.json();
        console.log('✅ Employees route accessible');
        console.log('📋 Employees data:', {
          success: employeesData.success,
          total: employeesData.total || 0,
          hasData: !!employeesData.data
        });
      } else {
        const errorText = await employeesResponse.text();
        console.error('❌ Employees route failed:', errorText);
      }
    }

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testAdminLogin();