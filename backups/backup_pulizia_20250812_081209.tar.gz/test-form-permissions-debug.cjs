// Simula i permessi dell'admin che abbiamo visto nel database
const adminBackendPermissions = {
  'VIEW_FORM_TEMPLATES': true,
  'CREATE_FORM_TEMPLATES': true,
  'EDIT_FORM_TEMPLATES': true,
  'DELETE_FORM_TEMPLATES': true,
  'MANAGE_FORM_TEMPLATES': true,
  'VIEW_SUBMISSIONS': true,
  'CREATE_SUBMISSIONS': true,
  'EDIT_SUBMISSIONS': true,
  'DELETE_SUBMISSIONS': true,
  'MANAGE_SUBMISSIONS': true,
  'EXPORT_SUBMISSIONS': true,
  'VIEW_FORM_SUBMISSIONS': true,
  'CREATE_FORM_SUBMISSIONS': true,
  'EDIT_FORM_SUBMISSIONS': true,
  'DELETE_FORM_SUBMISSIONS': true,
  'MANAGE_FORM_SUBMISSIONS': true,
  'EXPORT_FORM_SUBMISSIONS': true,
  'VIEW_CMS': true,
  'CREATE_CMS': true,
  'EDIT_CMS': true,
  'DELETE_CMS': true,
  'MANAGE_PUBLIC_CONTENT': true,
  'READ_PUBLIC_CONTENT': true,
  'VIEW_PUBLIC_CMS': true,
  'CREATE_PUBLIC_CMS': true,
  'EDIT_PUBLIC_CMS': true,
  'DELETE_PUBLIC_CMS': true,
  'MANAGE_PUBLIC_CMS': true
};

// Replica della funzione hasBackendPermission dal file permissionMapping.ts
function hasBackendPermission(frontendPermission, backendPermissions) {
  console.log(`🔍 Checking backend permission: ${frontendPermission}`);
  
  // Se il permesso è già nel formato backend, controllalo direttamente
  if (backendPermissions[frontendPermission] === true) {
    console.log(`✅ Direct match found: ${frontendPermission}`);
    return true;
  }
  
  // Gestione speciale per permessi FORM_TEMPLATES
  if (frontendPermission === 'form_templates:read' || frontendPermission === 'form_templates:view' ||
      frontendPermission === 'FORM_TEMPLATES:read' || frontendPermission === 'FORM_TEMPLATES:READ') {
    const hasPermission = backendPermissions['VIEW_FORM_TEMPLATES'] === true || 
           backendPermissions['MANAGE_FORM_TEMPLATES'] === true;
    console.log(`📋 Form templates read check: VIEW_FORM_TEMPLATES=${backendPermissions['VIEW_FORM_TEMPLATES']}, MANAGE_FORM_TEMPLATES=${backendPermissions['MANAGE_FORM_TEMPLATES']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'form_templates:create' || 
      frontendPermission === 'FORM_TEMPLATES:create' || frontendPermission === 'FORM_TEMPLATES:CREATE') {
    const hasPermission = backendPermissions['CREATE_FORM_TEMPLATES'] === true || 
           backendPermissions['MANAGE_FORM_TEMPLATES'] === true;
    console.log(`📋 Form templates create check: CREATE_FORM_TEMPLATES=${backendPermissions['CREATE_FORM_TEMPLATES']}, MANAGE_FORM_TEMPLATES=${backendPermissions['MANAGE_FORM_TEMPLATES']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'form_templates:update' || frontendPermission === 'form_templates:edit' ||
      frontendPermission === 'FORM_TEMPLATES:update' || frontendPermission === 'FORM_TEMPLATES:UPDATE') {
    const hasPermission = backendPermissions['EDIT_FORM_TEMPLATES'] === true || 
           backendPermissions['MANAGE_FORM_TEMPLATES'] === true;
    console.log(`📋 Form templates update check: EDIT_FORM_TEMPLATES=${backendPermissions['EDIT_FORM_TEMPLATES']}, MANAGE_FORM_TEMPLATES=${backendPermissions['MANAGE_FORM_TEMPLATES']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'form_templates:delete' ||
      frontendPermission === 'FORM_TEMPLATES:delete' || frontendPermission === 'FORM_TEMPLATES:DELETE') {
    const hasPermission = backendPermissions['DELETE_FORM_TEMPLATES'] === true || 
           backendPermissions['MANAGE_FORM_TEMPLATES'] === true;
    console.log(`📋 Form templates delete check: DELETE_FORM_TEMPLATES=${backendPermissions['DELETE_FORM_TEMPLATES']}, MANAGE_FORM_TEMPLATES=${backendPermissions['MANAGE_FORM_TEMPLATES']} -> ${hasPermission}`);
    return hasPermission;
  }

  // Gestione speciale per permessi FORM_SUBMISSIONS
  if (frontendPermission === 'form_submissions:read' || frontendPermission === 'form_submissions:view' || 
      frontendPermission === 'submissions:read' || frontendPermission === 'submissions:view' ||
      frontendPermission === 'FORM_SUBMISSIONS:read' || frontendPermission === 'FORM_SUBMISSIONS:READ') {
    const hasPermission = backendPermissions['VIEW_SUBMISSIONS'] === true || 
           backendPermissions['VIEW_FORM_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_FORM_SUBMISSIONS'] === true;
    console.log(`📋 Form submissions read check: VIEW_SUBMISSIONS=${backendPermissions['VIEW_SUBMISSIONS']}, VIEW_FORM_SUBMISSIONS=${backendPermissions['VIEW_FORM_SUBMISSIONS']}, MANAGE_SUBMISSIONS=${backendPermissions['MANAGE_SUBMISSIONS']}, MANAGE_FORM_SUBMISSIONS=${backendPermissions['MANAGE_FORM_SUBMISSIONS']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'form_submissions:create' || frontendPermission === 'submissions:create' ||
      frontendPermission === 'FORM_SUBMISSIONS:create' || frontendPermission === 'FORM_SUBMISSIONS:CREATE') {
    const hasPermission = backendPermissions['CREATE_SUBMISSIONS'] === true || 
           backendPermissions['CREATE_FORM_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_FORM_SUBMISSIONS'] === true;
    console.log(`📋 Form submissions create check: CREATE_SUBMISSIONS=${backendPermissions['CREATE_SUBMISSIONS']}, CREATE_FORM_SUBMISSIONS=${backendPermissions['CREATE_FORM_SUBMISSIONS']}, MANAGE_SUBMISSIONS=${backendPermissions['MANAGE_SUBMISSIONS']}, MANAGE_FORM_SUBMISSIONS=${backendPermissions['MANAGE_FORM_SUBMISSIONS']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'form_submissions:update' || frontendPermission === 'form_submissions:edit' ||
      frontendPermission === 'submissions:update' || frontendPermission === 'submissions:edit' ||
      frontendPermission === 'FORM_SUBMISSIONS:update' || frontendPermission === 'FORM_SUBMISSIONS:UPDATE') {
    const hasPermission = backendPermissions['EDIT_SUBMISSIONS'] === true || 
           backendPermissions['EDIT_FORM_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_FORM_SUBMISSIONS'] === true;
    console.log(`📋 Form submissions update check: EDIT_SUBMISSIONS=${backendPermissions['EDIT_SUBMISSIONS']}, EDIT_FORM_SUBMISSIONS=${backendPermissions['EDIT_FORM_SUBMISSIONS']}, MANAGE_SUBMISSIONS=${backendPermissions['MANAGE_SUBMISSIONS']}, MANAGE_FORM_SUBMISSIONS=${backendPermissions['MANAGE_FORM_SUBMISSIONS']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'form_submissions:delete' || frontendPermission === 'submissions:delete' ||
      frontendPermission === 'FORM_SUBMISSIONS:delete' || frontendPermission === 'FORM_SUBMISSIONS:DELETE') {
    const hasPermission = backendPermissions['DELETE_SUBMISSIONS'] === true || 
           backendPermissions['DELETE_FORM_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_FORM_SUBMISSIONS'] === true;
    console.log(`📋 Form submissions delete check: DELETE_SUBMISSIONS=${backendPermissions['DELETE_SUBMISSIONS']}, DELETE_FORM_SUBMISSIONS=${backendPermissions['DELETE_FORM_SUBMISSIONS']}, MANAGE_SUBMISSIONS=${backendPermissions['MANAGE_SUBMISSIONS']}, MANAGE_FORM_SUBMISSIONS=${backendPermissions['MANAGE_FORM_SUBMISSIONS']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'form_submissions:export' || frontendPermission === 'submissions:export' ||
      frontendPermission === 'FORM_SUBMISSIONS:export' || frontendPermission === 'FORM_SUBMISSIONS:EXPORT') {
    const hasPermission = backendPermissions['EXPORT_SUBMISSIONS'] === true || 
           backendPermissions['EXPORT_FORM_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_SUBMISSIONS'] === true ||
           backendPermissions['MANAGE_FORM_SUBMISSIONS'] === true;
    console.log(`📋 Form submissions export check: EXPORT_SUBMISSIONS=${backendPermissions['EXPORT_SUBMISSIONS']}, EXPORT_FORM_SUBMISSIONS=${backendPermissions['EXPORT_FORM_SUBMISSIONS']}, MANAGE_SUBMISSIONS=${backendPermissions['MANAGE_SUBMISSIONS']}, MANAGE_FORM_SUBMISSIONS=${backendPermissions['MANAGE_FORM_SUBMISSIONS']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  // Gestione speciale per permessi PUBLIC_CMS
  if (frontendPermission === 'PUBLIC_CMS:READ' || frontendPermission === 'PUBLIC_CMS:read') {
    const hasPermission = backendPermissions['VIEW_CMS'] === true || 
           backendPermissions['VIEW_PUBLIC_CMS'] === true ||
           backendPermissions['MANAGE_PUBLIC_CONTENT'] === true ||
           backendPermissions['READ_PUBLIC_CONTENT'] === true;
    console.log(`📋 Public CMS read check: VIEW_CMS=${backendPermissions['VIEW_CMS']}, VIEW_PUBLIC_CMS=${backendPermissions['VIEW_PUBLIC_CMS']}, MANAGE_PUBLIC_CONTENT=${backendPermissions['MANAGE_PUBLIC_CONTENT']}, READ_PUBLIC_CONTENT=${backendPermissions['READ_PUBLIC_CONTENT']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'PUBLIC_CMS:CREATE' || frontendPermission === 'PUBLIC_CMS:create') {
    const hasPermission = backendPermissions['CREATE_CMS'] === true || 
           backendPermissions['CREATE_PUBLIC_CMS'] === true ||
           backendPermissions['MANAGE_PUBLIC_CONTENT'] === true;
    console.log(`📋 Public CMS create check: CREATE_CMS=${backendPermissions['CREATE_CMS']}, CREATE_PUBLIC_CMS=${backendPermissions['CREATE_PUBLIC_CMS']}, MANAGE_PUBLIC_CONTENT=${backendPermissions['MANAGE_PUBLIC_CONTENT']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'PUBLIC_CMS:UPDATE' || frontendPermission === 'PUBLIC_CMS:update') {
    const hasPermission = backendPermissions['EDIT_CMS'] === true || 
           backendPermissions['EDIT_PUBLIC_CMS'] === true ||
           backendPermissions['MANAGE_PUBLIC_CONTENT'] === true;
    console.log(`📋 Public CMS update check: EDIT_CMS=${backendPermissions['EDIT_CMS']}, EDIT_PUBLIC_CMS=${backendPermissions['EDIT_PUBLIC_CMS']}, MANAGE_PUBLIC_CONTENT=${backendPermissions['MANAGE_PUBLIC_CONTENT']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  if (frontendPermission === 'PUBLIC_CMS:DELETE' || frontendPermission === 'PUBLIC_CMS:delete') {
    const hasPermission = backendPermissions['DELETE_CMS'] === true || 
           backendPermissions['DELETE_PUBLIC_CMS'] === true ||
           backendPermissions['MANAGE_PUBLIC_CONTENT'] === true;
    console.log(`📋 Public CMS delete check: DELETE_CMS=${backendPermissions['DELETE_CMS']}, DELETE_PUBLIC_CMS=${backendPermissions['DELETE_PUBLIC_CMS']}, MANAGE_PUBLIC_CONTENT=${backendPermissions['MANAGE_PUBLIC_CONTENT']} -> ${hasPermission}`);
    return hasPermission;
  }
  
  console.log(`❌ No backend permission mapping found for: ${frontendPermission}`);
  return false;
}

// Simula la funzione hasPermission dell'AuthContext
function simulateHasPermission(resourceOrPermission, action, permissions) {
  let permissionToCheck;
  
  if (action) {
    // Formato con due parametri: resource e action
    permissionToCheck = `${resourceOrPermission}:${action}`;
    console.log(`\n🔐 Checking permission (two params): ${resourceOrPermission}:${action}`);
  } else {
    // Formato con un parametro: permesso diretto
    permissionToCheck = resourceOrPermission;
    console.log(`\n🔐 Checking permission (single param): ${resourceOrPermission}`);
  }
  
  // Verifica permesso diretto (sia formato frontend che backend)
  if (permissions[permissionToCheck] === true) {
    console.log(`✅ Access granted: user has ${permissionToCheck} permission (direct match)`);
    return true;
  }
  
  // Se abbiamo due parametri, prova anche altri formati
  if (action) {
    // Verifica permesso all:* (permesso universale)
    if (permissions['all:' + action] === true) {
      console.log('✅ Access granted: user has all:' + action + ' permission');
      return true;
    }
    
    // Verifica permesso resource:all (permesso per tutte le azioni sulla risorsa)
    if (permissions[resourceOrPermission + ':all'] === true) {
      console.log('✅ Access granted: user has ' + resourceOrPermission + ':all permission');
      return true;
    }
    
    // Prova anche il formato backend usando hasBackendPermission
    const backendPermissionResult = hasBackendPermission(permissionToCheck, permissions);
    if (backendPermissionResult) {
      console.log(`✅ Access granted: user has ${permissionToCheck} permission (backend format match)`);
      return true;
    }
    
    // Concedi accesso se c'è almeno un permesso con quel resource
    if (action === 'read') {
      // For 'read' actions, check if the user has any permission for this resource
      const resourcePermissions = Object.keys(permissions)
        .filter(key => key.startsWith(resourceOrPermission + ':') && permissions[key] === true);
      
      console.log(`🔍 Found ${resourcePermissions.length} permissions for resource '${resourceOrPermission}':`, resourcePermissions);
      
      if (resourcePermissions.length > 0) {
        console.log('✅ Access granted: user has some permission for ' + resourceOrPermission);
        return true;
      }
    }
  } else {
    // Se è un singolo parametro, prova anche il formato backend
    const backendPermissionResult = hasBackendPermission(permissionToCheck, permissions);
    if (backendPermissionResult) {
      console.log(`✅ Access granted: user has ${permissionToCheck} permission (backend format match)`);
      return true;
    }
  }
  
  console.log(`❌ Permission check result: false for ${permissionToCheck}`);
  return false;
}

console.log('🧪 === TEST FORM PERMISSIONS ===\n');

// Test FormTemplatesPage permissions
console.log('📋 FormTemplatesPage permissions:');
const canViewFormTemplates = simulateHasPermission('form_templates', 'read', adminBackendPermissions);
const canEditFormTemplates = simulateHasPermission('form_templates', 'update', adminBackendPermissions);
const canDeleteFormTemplates = simulateHasPermission('form_templates', 'delete', adminBackendPermissions);
const canCreateFormTemplates = simulateHasPermission('form_templates', 'create', adminBackendPermissions);

console.log('\n📊 FormTemplatesPage Summary:');
console.log(`  - canView: ${canViewFormTemplates ? '✅' : '❌'}`);
console.log(`  - canEdit: ${canEditFormTemplates ? '✅' : '❌'}`);
console.log(`  - canDelete: ${canDeleteFormTemplates ? '✅' : '❌'}`);
console.log(`  - canCreate: ${canCreateFormTemplates ? '✅' : '❌'}`);

console.log('\n' + '='.repeat(50) + '\n');

// Test FormSubmissionsPage permissions
console.log('📋 FormSubmissionsPage permissions:');
const canViewFormSubmissions = simulateHasPermission('form_submissions', 'read', adminBackendPermissions);
const canEditFormSubmissions = simulateHasPermission('form_submissions', 'update', adminBackendPermissions);
const canDeleteFormSubmissions = simulateHasPermission('form_submissions', 'delete', adminBackendPermissions);
const canExportFormSubmissions = simulateHasPermission('form_submissions', 'export', adminBackendPermissions);

console.log('\n📊 FormSubmissionsPage Summary:');
console.log(`  - canView: ${canViewFormSubmissions ? '✅' : '❌'}`);
console.log(`  - canEdit: ${canEditFormSubmissions ? '✅' : '❌'}`);
console.log(`  - canDelete: ${canDeleteFormSubmissions ? '✅' : '❌'}`);
console.log(`  - canExport: ${canExportFormSubmissions ? '✅' : '❌'}`);

console.log('\n' + '='.repeat(50) + '\n');

// Test PublicCMSPage permissions
console.log('📋 PublicCMSPage permissions:');
const canViewPublicCMS = simulateHasPermission('PUBLIC_CMS', 'READ', adminBackendPermissions);
const canEditPublicCMS = simulateHasPermission('PUBLIC_CMS', 'UPDATE', adminBackendPermissions);

console.log('\n📊 PublicCMSPage Summary:');
console.log(`  - canView: ${canViewPublicCMS ? '✅' : '❌'}`);
console.log(`  - canEdit: ${canEditPublicCMS ? '✅' : '❌'}`);

console.log('\n🔍 === DETAILED BACKEND PERMISSION MAPPING ===\n');

// Test specifici per il mapping backend
const formTemplateTests = [
  'form_templates:read',
  'form_templates:view', 
  'form_templates:create',
  'form_templates:update',
  'form_templates:edit',
  'form_templates:delete'
];

console.log('📋 Form Templates Backend Mapping:');
formTemplateTests.forEach(permission => {
  const result = hasBackendPermission(permission, adminBackendPermissions);
  console.log(`  ${permission}: ${result ? '✅' : '❌'}`);
});

const formSubmissionTests = [
  'form_submissions:read',
  'form_submissions:view',
  'form_submissions:create', 
  'form_submissions:update',
  'form_submissions:edit',
  'form_submissions:delete',
  'form_submissions:export'
];

console.log('\n📋 Form Submissions Backend Mapping:');
formSubmissionTests.forEach(permission => {
  const result = hasBackendPermission(permission, adminBackendPermissions);
  console.log(`  ${permission}: ${result ? '✅' : '❌'}`);
});

const publicCMSTests = [
  'PUBLIC_CMS:READ',
  'PUBLIC_CMS:read',
  'PUBLIC_CMS:CREATE', 
  'PUBLIC_CMS:create',
  'PUBLIC_CMS:UPDATE',
  'PUBLIC_CMS:update',
  'PUBLIC_CMS:DELETE',
  'PUBLIC_CMS:delete'
];

console.log('\n📋 Public CMS Backend Mapping:');
publicCMSTests.forEach(permission => {
  const result = hasBackendPermission(permission, adminBackendPermissions);
  console.log(`  ${permission}: ${result ? '✅' : '❌'}`);
});