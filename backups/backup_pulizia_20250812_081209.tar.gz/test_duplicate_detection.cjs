const http = require('http');

// Configurazione base
const BASE_URL = 'localhost';
const PORT = 4001; // API server diretto
const LOGIN_CREDENTIALS = {
  identifier: 'admin@example.com',
  password: 'Admin123!'
};

// Funzione per fare richieste HTTP
function makeRequest(options, data = null) {
  return new Promise((resolve, reject) => {
    console.log(`🔍 Making request to: ${options.method} ${options.hostname}:${options.port}${options.path}`);
    if (data) {
      console.log(`📤 Request data:`, JSON.stringify(data, null, 2));
    }
    
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        console.log(`📥 Response status: ${res.statusCode}`);
        console.log(`📥 Response headers:`, res.headers);
        console.log(`📥 Response body:`, body);
        
        try {
          const parsedBody = body ? JSON.parse(body) : null;
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: parsedBody
          });
        } catch (e) {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: body,
            parseError: e.message
          });
        }
      });
    });

    req.on('error', (err) => {
      console.error(`❌ Request error:`, err);
      reject(err);
    });

    if (data) {
      req.write(JSON.stringify(data));
    }
    req.end();
  });
}

async function testDuplicateDetection() {
  try {
    console.log('🔐 Step 1: Login...');
    
    // Login
    const loginOptions = {
      hostname: BASE_URL,
      port: PORT,
      path: '/api/v1/auth/login',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const loginResponse = await makeRequest(loginOptions, LOGIN_CREDENTIALS);

    if (loginResponse.statusCode !== 200) {
      console.error('❌ Login failed:', loginResponse.statusCode, loginResponse.body);
      return;
    }

    const token = loginResponse.body?.tokens?.access_token;
    if (!token) {
      console.error('❌ No token received');
      return;
    }

    console.log('✅ Login successful');

    // Test 1: Crea una azienda di test
    console.log('\n📋 Step 2: Creating test company...');
    const testCompany = {
      ragioneSociale: "Test Duplicati SRL",
      piva: "12345678901",
      codiceFiscale: "TSTDUP12345678901",
      citta: "Milano",
      indirizzo: "Via Test 123"
    };

    const createOptions = {
      hostname: BASE_URL,
      port: PORT,
      path: '/api/v1/companies',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };

    const createResponse = await makeRequest(createOptions, testCompany);
    console.log('Create company status:', createResponse.statusCode);

    let companyId = null;
    if (createResponse.statusCode === 201) {
      companyId = createResponse.body?.id;
      console.log('✅ Test company created with ID:', companyId);
    } else if (createResponse.statusCode === 400 && createResponse.body?.error?.includes('P.IVA')) {
      console.log('ℹ️ Company with this P.IVA already exists (expected for duplicate test)');
    } else {
      console.log('⚠️ Unexpected response:', createResponse.statusCode, createResponse.body);
    }

    // Test 2: Tenta di importare aziende con P.IVA duplicata
    console.log('\n🔄 Step 3: Testing import with duplicate P.IVA...');
    const duplicateCompanies = [
      {
        ragioneSociale: "Test Duplicati SRL - Originale",
        piva: "12345678901", // Stessa P.IVA
        codiceFiscale: "TSTDUP12345678901",
        citta: "Milano",
        indirizzo: "Via Test 123"
      },
      {
        ragioneSociale: "Test Duplicati SRL - Duplicata",
        piva: "12345678901", // Stessa P.IVA - dovrebbe essere rilevata come duplicato
        codiceFiscale: "TSTDUP12345678902",
        citta: "Roma",
        indirizzo: "Via Roma 456"
      },
      {
        ragioneSociale: "Azienda Valida SRL",
        piva: "98765432109", // P.IVA diversa - dovrebbe essere accettata
        codiceFiscale: "AZVLD98765432109",
        citta: "Torino",
        indirizzo: "Via Torino 789"
      }
    ];

    const importOptions = {
      hostname: BASE_URL,
      port: PORT,
      path: '/api/v1/companies/import',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };

    const importResponse = await makeRequest(importOptions, { companies: duplicateCompanies });
    console.log('Import response status:', importResponse.statusCode);
    console.log('Import response data:', JSON.stringify(importResponse.body, null, 2));

    // Analizza i risultati
    if (importResponse.statusCode === 200) {
      const results = importResponse.body;
      console.log('\n📊 ANALISI RISULTATI IMPORT:');
      console.log(`✅ Aziende create: ${results.created?.length || 0}`);
      console.log(`🔄 Aziende aggiornate: ${results.updated?.length || 0}`);
      console.log(`🏢 Sedi create: ${results.sitesCreated?.length || 0}`);
      console.log(`❌ Errori rilevati: ${results.errors?.length || 0}`);

      if (results.errors && results.errors.length > 0) {
        console.log('\n🔍 DETTAGLIO ERRORI:');
        results.errors.forEach((error, index) => {
          console.log(`${index + 1}. Riga ${error.index + 1}: ${error.error}`);
          if (error.data) {
            console.log(`   Dati: ${error.data.ragioneSociale} (P.IVA: ${error.data.piva})`);
          }
        });

        // Verifica se il duplicato è stato rilevato correttamente
        const duplicateError = results.errors.find(error => 
          error.error.includes('P.IVA') && error.error.includes('duplicata')
        );

        if (duplicateError) {
          console.log('\n✅ RILEVAMENTO DUPLICATI FUNZIONA CORRETTAMENTE!');
          console.log(`   Errore rilevato: ${duplicateError.error}`);
        } else {
          console.log('\n❌ RILEVAMENTO DUPLICATI NON FUNZIONA!');
          console.log('   Nessun errore di P.IVA duplicata trovato negli errori');
        }
      } else {
        console.log('\n⚠️ POSSIBILE PROBLEMA: Nessun errore rilevato, ma dovrebbe esserci almeno un duplicato');
      }

      if (results.created && results.created.length > 0) {
        console.log('\n📋 AZIENDE CREATE:');
        results.created.forEach((company, index) => {
          console.log(`${index + 1}. ${company.ragioneSociale} (P.IVA: ${company.piva})`);
        });
      }
    } else {
      console.log('❌ Import failed:', importResponse.statusCode, importResponse.body);
    }

    // Test 3: Verifica con Codice Fiscale duplicato per le persone
    console.log('\n👤 Step 4: Testing person import with duplicate tax code...');
    const duplicatePersons = [
      {
        firstName: "Mario",
        lastName: "Rossi",
        email: "mario.rossi1@test.com",
        taxCode: "RSSMRA80A01H501Z", // Stesso codice fiscale
        roleType: "EMPLOYEE"
      },
      {
        firstName: "Mario",
        lastName: "Rossi",
        email: "mario.rossi2@test.com", 
        taxCode: "RSSMRA80A01H501Z", // Stesso codice fiscale - dovrebbe essere rilevato
        roleType: "EMPLOYEE"
      },
      {
        firstName: "Giulia",
        lastName: "Bianchi",
        email: "giulia.bianchi@test.com",
        taxCode: "BNCGLI85B02H501Y", // Codice fiscale diverso - dovrebbe essere accettato
        roleType: "EMPLOYEE"
      }
    ];

    const personImportOptions = {
      hostname: BASE_URL,
      port: PORT,
      path: '/api/v1/persons/import',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };

    const personImportResponse = await makeRequest(personImportOptions, { persons: duplicatePersons });
    console.log('Person import response status:', personImportResponse.statusCode);
    console.log('Person import response data:', JSON.stringify(personImportResponse.body, null, 2));

    // Analizza i risultati delle persone
    if (personImportResponse.statusCode === 200) {
      const results = personImportResponse.body;
      console.log('\n📊 ANALISI RISULTATI IMPORT PERSONE:');
      console.log(`✅ Persone create: ${results.created?.length || 0}`);
      console.log(`🔄 Persone aggiornate: ${results.updated?.length || 0}`);
      console.log(`❌ Errori rilevati: ${results.errors?.length || 0}`);

      if (results.errors && results.errors.length > 0) {
        console.log('\n🔍 DETTAGLIO ERRORI PERSONE:');
        results.errors.forEach((error, index) => {
          console.log(`${index + 1}. Riga ${error.row}: ${error.error}`);
        });

        // Verifica se il duplicato è stato rilevato correttamente
        const duplicateError = results.errors.find(error => 
          error.error.includes('codice fiscale') && error.error.includes('esistente')
        );

        if (duplicateError) {
          console.log('\n✅ RILEVAMENTO DUPLICATI PERSONE FUNZIONA CORRETTAMENTE!');
          console.log(`   Errore rilevato: ${duplicateError.error}`);
        } else {
          console.log('\n❌ RILEVAMENTO DUPLICATI PERSONE NON FUNZIONA!');
          console.log('   Nessun errore di codice fiscale duplicato trovato negli errori');
        }
      } else {
        console.log('\n⚠️ POSSIBILE PROBLEMA: Nessun errore rilevato per le persone, ma dovrebbe esserci almeno un duplicato');
      }
    } else {
      console.log('❌ Person import failed:', personImportResponse.statusCode, personImportResponse.body);
    }

    console.log('\n🏁 Test completato!');

  } catch (error) {
    console.error('💥 Test failed with error:', error.message);
  }
}

testDuplicateDetection();