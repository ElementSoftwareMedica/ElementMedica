const axios = require('axios');

async function testPermissions() {
  try {
    console.log('🔐 Testing permissions for new entities...\n');

    // 1. Login
    console.log('1️⃣ Login as admin...');
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    if (!loginResponse.data.success) {
      throw new Error('Login failed');
    }

    const token = loginResponse.data.tokens.access_token;
    const userId = loginResponse.data.user.id;
    console.log('✅ Login successful');
    console.log('👤 User ID:', userId);
    console.log('🎭 User Role:', loginResponse.data.user.role);

    // 2. Get permissions
    console.log('\n2️⃣ Getting user permissions...');
    const permissionsResponse = await axios.get(
      `http://localhost:4001/api/v1/auth/permissions/${userId}`,
      {
        headers: { Authorization: `Bearer ${token}` }
      }
    );

    if (!permissionsResponse.data.success) {
      throw new Error('Failed to get permissions');
    }

    const permissions = permissionsResponse.data.data.permissions;
    console.log('✅ Permissions loaded');
    console.log('📊 Total permissions:', Object.keys(permissions).length);

    // 3. Check specific permissions for new entities
    console.log('\n3️⃣ Checking specific permissions...');
    
    // Form Templates permissions
    const formTemplatesPermissions = Object.keys(permissions).filter(p => 
      p.includes('form_templates') || p.includes('FORM_TEMPLATES')
    );
    console.log('📋 Form Templates permissions:', formTemplatesPermissions.length);
    formTemplatesPermissions.forEach(p => console.log(`  - ${p}: ${permissions[p]}`));
    
    // Form Submissions permissions
    const formSubmissionsPermissions = Object.keys(permissions).filter(p => 
      p.includes('form_submissions') || p.includes('FORM_SUBMISSIONS')
    );
    console.log('📋 Form Submissions permissions:', formSubmissionsPermissions.length);
    formSubmissionsPermissions.forEach(p => console.log(`  - ${p}: ${permissions[p]}`));
    
    // Public CMS permissions
    const publicCmsPermissions = Object.keys(permissions).filter(p => 
      p.includes('PUBLIC_CMS') || p.includes('public_cms')
    );
    console.log('📋 Public CMS permissions:', publicCmsPermissions.length);
    publicCmsPermissions.forEach(p => console.log(`  - ${p}: ${permissions[p]}`));

    // 4. Test specific permission checks that pages use
    console.log('\n4️⃣ Testing page-specific permission checks...');
    
    const pageTests = [
      { page: 'PublicCMSPage', resource: 'PUBLIC_CMS', action: 'READ' },
      { page: 'PublicCMSPage', resource: 'PUBLIC_CMS', action: 'UPDATE' },
      { page: 'FormTemplatesPage', resource: 'form_templates', action: 'read' },
      { page: 'FormTemplatesPage', resource: 'form_templates', action: 'update' },
      { page: 'FormSubmissionsPage', resource: 'form_submissions', action: 'read' },
      { page: 'FormSubmissionsPage', resource: 'form_submissions', action: 'update' }
    ];

    pageTests.forEach(test => {
      const permissionKey = `${test.resource}:${test.action}`;
      const hasPermission = permissions[permissionKey] === true;
      console.log(`${hasPermission ? '✅' : '❌'} ${test.page}: ${permissionKey} = ${hasPermission}`);
    });

    // 5. Show all permissions for debugging
    console.log('\n5️⃣ All permissions (for debugging):');
    Object.keys(permissions)
      .filter(key => permissions[key] === true)
      .sort()
      .forEach(key => console.log(`  ✅ ${key}`));

  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data);
    }
  }
}

testPermissions();