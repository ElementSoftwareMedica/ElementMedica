const axios = require('axios');

// Configurazione axios per il proxy
const axiosInstance = axios.create({
  baseURL: 'http://localhost:4003',
  timeout: 10000,
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json'
  }
});

async function testTenantResponse() {
  console.log('🔍 Testing /tenants/current response structure...\n');

  try {
    // 1. Login
    console.log('1️⃣ Login...');
    const loginResponse = await axiosInstance.post('/api/auth/login', {
      identifier: 'admin',
      password: 'Admin123!'
    });

    const token = loginResponse.data.tokens?.access_token;
    console.log('✅ Login successful, Token:', token ? 'Present' : 'Missing');

    if (!token) {
      console.error('❌ No token received');
      return;
    }

    // 2. Test /tenants/current
    console.log('\n2️⃣ Testing /tenants/current...');
    const tenantResponse = await axiosInstance.get('/api/tenants/current', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('✅ Tenant response status:', tenantResponse.status);
    console.log('📄 Full response structure:');
    console.log(JSON.stringify(tenantResponse.data, null, 2));

    // 3. Analizza la struttura
    console.log('\n3️⃣ Response structure analysis:');
    console.log('- response.data type:', typeof tenantResponse.data);
    console.log('- response.data.success:', tenantResponse.data.success);
    console.log('- response.data.data exists:', !!tenantResponse.data.data);
    console.log('- response.data.data.tenant exists:', !!tenantResponse.data.data?.tenant);
    console.log('- response.data.data.tenant.id:', tenantResponse.data.data?.tenant?.id);
    console.log('- response.data.data.tenant.name:', tenantResponse.data.data?.tenant?.name);

    // 4. Simula cosa riceve getCurrentTenant
    console.log('\n4️⃣ What getCurrentTenant receives:');
    const whatGetCurrentTenantReceives = tenantResponse.data;
    console.log('- Type:', typeof whatGetCurrentTenantReceives);
    console.log('- Has id property:', !!whatGetCurrentTenantReceives.id);
    console.log('- Has name property:', !!whatGetCurrentTenantReceives.name);
    console.log('- Actual id value:', whatGetCurrentTenantReceives.id);
    console.log('- Actual name value:', whatGetCurrentTenantReceives.name);

    // 5. Cosa dovrebbe ricevere
    console.log('\n5️⃣ What it should receive (tenant object):');
    const correctTenantObject = tenantResponse.data.data?.tenant;
    console.log('- Type:', typeof correctTenantObject);
    console.log('- Has id property:', !!correctTenantObject?.id);
    console.log('- Has name property:', !!correctTenantObject?.name);
    console.log('- Actual id value:', correctTenantObject?.id);
    console.log('- Actual name value:', correctTenantObject?.name);

  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data);
    }
  }
}

testTenantResponse();