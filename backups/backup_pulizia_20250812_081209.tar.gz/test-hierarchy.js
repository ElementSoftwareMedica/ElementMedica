import axios from 'axios';

const BASE_URL = 'http://localhost:4001';

async function testHierarchy() {
  try {
    console.log('🔍 Testing Role Hierarchy Endpoints...\n');

    // Step 1: Login to get token
    console.log('1. Attempting login...');
    const loginResponse = await axios.post(`${BASE_URL}/api/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    if (loginResponse.status !== 200) {
      throw new Error(`Login failed with status: ${loginResponse.status}`);
    }

    // Corretto: il token è in tokens.access_token
    const token = loginResponse.data.tokens?.access_token;
    console.log('✅ Login successful');
    console.log('🎫 Token preview:', token ? token.substring(0, 30) + '...' : 'NO TOKEN');
    console.log('📋 User info:', {
      id: loginResponse.data.user?.id,
      email: loginResponse.data.user?.email,
      role: loginResponse.data.user?.globalRole
    });

    if (!token) {
      throw new Error('No access token received from login');
    }

    // Step 1.5: Verify token
    console.log('\n1.5. Verifying token...');
    try {
      const verifyResponse = await axios.get(`${BASE_URL}/api/auth/verify`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Token verification successful');
      console.log('📋 Verify response:', JSON.stringify(verifyResponse.data, null, 2));
    } catch (verifyError) {
      console.error('❌ Token verification failed:', verifyError.response?.data || verifyError.message);
    }

    // Step 2: Test role hierarchy endpoint
    console.log('\n2. Testing /api/roles/hierarchy...');
    try {
      const hierarchyResponse = await axios.get(`${BASE_URL}/api/roles/hierarchy`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      console.log('✅ Hierarchy endpoint response:');
      console.log(JSON.stringify(hierarchyResponse.data, null, 2));
    } catch (hierarchyError) {
      console.error('❌ Hierarchy endpoint failed:', {
        status: hierarchyError.response?.status,
        statusText: hierarchyError.response?.statusText,
        data: hierarchyError.response?.data,
        message: hierarchyError.message
      });
    }

    // Step 3: Test current user hierarchy endpoint
    console.log('\n3. Testing /api/roles/hierarchy/current-user...');
    try {
      const userHierarchyResponse = await axios.get(`${BASE_URL}/api/roles/hierarchy/current-user`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      console.log('✅ Current user hierarchy response:');
      console.log(JSON.stringify(userHierarchyResponse.data, null, 2));
    } catch (userHierarchyError) {
      console.error('❌ Current user hierarchy endpoint failed:', {
        status: userHierarchyError.response?.status,
        statusText: userHierarchyError.response?.statusText,
        data: userHierarchyError.response?.data,
        message: userHierarchyError.message
      });
    }

    console.log('\n🎉 All hierarchy tests completed!');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data);
    }
  }
}

testHierarchy();