import PersonUtils from './backend/services/person/utils/PersonUtils.js';
import PersonImport from './backend/services/person/import/PersonImport.js';

async function testDateHandling() {
  console.log('🧪 Testing date handling in import process...');
  
  // Test vari formati di data
  const testDates = [
    "08/11/1971", // DD/MM/YYYY
    "1971-11-08", // YYYY-MM-DD
    "08-11-1971", // DD-MM-YYYY
    "8/11/1971",  // D/M/YYYY
    "8-11-1971",  // D-M-YYYY
    "",           // Data vuota
    null,         // Data null
    "invalid"     // Data non valida
  ];
  
  console.log('📅 Testing PersonUtils.parseDate...');
  testDates.forEach((dateStr, index) => {
    try {
      const parsed = PersonUtils.parseDate(dateStr);
      console.log(`${index + 1}. "${dateStr}" -> ${parsed ? parsed.toISOString() : 'null'}`);
    } catch (error) {
      console.log(`${index + 1}. "${dateStr}" -> ERROR: ${error.message}`);
    }
  });
  
  console.log('\n📋 Testing data normalization...');
  
  // Test data con vari formati di data
  const testPersonData = {
    firstName: "Mario",
    lastName: "Rossi",
    birthDate: "08/11/1971", // DD/MM/YYYY
    hiredDate: "15/01/2020", // DD/MM/YYYY
    taxCode: "RSSMRA71S08H501X"
  };
  
  try {
    const normalized = await PersonImport.normalizePersonData(testPersonData);
    
    console.log('✅ Normalized data:');
    console.log('- birthDate:', normalized.birthDate);
    console.log('- hiredDate:', normalized.hiredDate);
    console.log('- birthDate type:', typeof normalized.birthDate);
    console.log('- hiredDate type:', typeof normalized.hiredDate);
    
    // Verifica che le date siano in formato ISO-8601 completo
    if (normalized.birthDate && normalized.birthDate.includes('T') && normalized.birthDate.includes('Z')) {
      console.log('✅ birthDate is in ISO-8601 format');
    } else {
      console.log('❌ birthDate is NOT in ISO-8601 format');
    }
    
    if (normalized.hiredDate && normalized.hiredDate.includes('T') && normalized.hiredDate.includes('Z')) {
      console.log('✅ hiredDate is in ISO-8601 format');
    } else {
      console.log('❌ hiredDate is NOT in ISO-8601 format');
    }
    
  } catch (error) {
    console.error('❌ Normalization failed:', error.message);
  }
  
  console.log('\n🧪 Testing with empty dates...');
  
  const testEmptyDates = {
    firstName: "Luigi",
    lastName: "Verdi",
    birthDate: "",
    hiredDate: null,
    taxCode: "VRDLGU80A01H501Y"
  };
  
  try {
    const normalized = await PersonImport.normalizePersonData(testEmptyDates);
    
    console.log('✅ Normalized data with empty dates:');
    console.log('- birthDate present:', 'birthDate' in normalized);
    console.log('- hiredDate present:', 'hiredDate' in normalized);
    
    if (!('birthDate' in normalized) && !('hiredDate' in normalized)) {
      console.log('✅ Empty dates correctly removed');
    } else {
      console.log('❌ Empty dates not properly handled');
    }
    
  } catch (error) {
    console.error('❌ Empty dates test failed:', error.message);
  }
}

testDateHandling();