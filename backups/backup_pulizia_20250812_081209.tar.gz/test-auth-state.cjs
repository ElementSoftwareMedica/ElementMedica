const puppeteer = require('puppeteer');

async function testAuthState() {
  const browser = await puppeteer.launch({ 
    headless: false,
    devtools: true,
    slowMo: 200
  });
  
  const page = await browser.newPage();
  
  // Intercetta i log della console
  page.on('console', msg => {
    const type = msg.type();
    const text = msg.text();
    
    // Filtra solo i log rilevanti per Auth e Tenant
    if (text.includes('AuthContext') || 
        text.includes('TenantContext') || 
        text.includes('isAuthenticated') ||
        text.includes('user') ||
        text.includes('tenant')) {
      console.log(`[BROWSER ${type.toUpperCase()}] ${text}`);
    }
  });
  
  try {
    console.log('🚀 Navigating to login page...');
    await page.goto('http://localhost:5173/login', { waitUntil: 'networkidle0' });
    
    console.log('📝 Filling login form...');
    await page.waitForSelector('#identifier', { timeout: 10000 });
    await page.type('#identifier', 'admin@example.com');
    await page.type('#password', 'Admin123!');
    
    console.log('🔐 Submitting login...');
    await page.click('button[type="submit"]');
    
    // Aspetta il redirect
    console.log('⏳ Waiting for navigation...');
    await page.waitForNavigation({ waitUntil: 'networkidle0', timeout: 15000 });
    
    // Aspetta un momento per i context
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Verifica lo stato dell'autenticazione
    console.log('🔍 Checking authentication state...');
    const authState = await page.evaluate(() => {
      // Verifica localStorage
      const authToken = localStorage.getItem('authToken');
      const tenantId = localStorage.getItem('tenantId');
      
      // Prova ad accedere ai context React (se possibile)
      const reactFiber = document.querySelector('#root')?._reactInternalFiber || 
                        document.querySelector('#root')?._reactInternals;
      
      return {
        localStorage: {
          authToken: authToken ? 'present' : 'missing',
          tenantId: tenantId ? 'present' : 'missing',
          authTokenLength: authToken ? authToken.length : 0,
          tenantIdValue: tenantId
        },
        url: window.location.href,
        pathname: window.location.pathname,
        hasReactFiber: !!reactFiber
      };
    });
    
    console.log('📊 Authentication state:', JSON.stringify(authState, null, 2));
    
    // Verifica se siamo sulla dashboard
    if (authState.pathname === '/dashboard' || authState.pathname === '/') {
      console.log('✅ Successfully navigated to dashboard');
      
      // Aspetta ancora un po' per vedere se i context si inizializzano
      console.log('⏳ Waiting for contexts to initialize...');
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      // Verifica i contatori
      const counters = await page.evaluate(() => {
        const elements = document.querySelectorAll('h2, h3, .text-2xl, [class*="font-bold"]');
        const counters = [];
        
        elements.forEach((el, index) => {
          const text = el.textContent?.trim();
          if (text && /^\d+$/.test(text)) {
            counters.push({
              index,
              value: text,
              className: el.className,
              parentText: el.parentElement?.textContent?.substring(0, 50)
            });
          }
        });
        
        return counters;
      });
      
      console.log('📊 Found counters:', counters);
      
    } else {
      console.log('❌ Not on dashboard, current path:', authState.pathname);
    }
    
    // Salva screenshot
    await page.screenshot({ path: 'auth-state-debug.png', fullPage: true });
    console.log('📸 Screenshot saved as auth-state-debug.png');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    
    // Salva screenshot dell'errore
    try {
      await page.screenshot({ path: 'auth-state-error.png', fullPage: true });
      console.log('📸 Error screenshot saved as auth-state-error.png');
    } catch (screenshotError) {
      console.error('Failed to save error screenshot:', screenshotError.message);
    }
  } finally {
    await browser.close();
  }
}

testAuthState().catch(console.error);