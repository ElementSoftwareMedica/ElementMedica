const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function fixAdminRole() {
  try {
    console.log('🔧 Correzione ruolo admin...');

    // 1. Trova l'utente admin
    const admin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' }
    });

    if (!admin) {
      console.log('❌ Admin non trovato');
      return;
    }

    console.log(`✅ Admin trovato: ${admin.email} (ID: ${admin.id})`);

    // 2. Verifica se ha già il ruolo ADMIN
    const existingAdminRole = await prisma.personRole.findFirst({
      where: {
        personId: admin.id,
        roleType: 'ADMIN',
        isActive: true
      }
    });

    if (existingAdminRole) {
      console.log('✅ Ruolo ADMIN già presente');
    } else {
      console.log('⚠️ Ruolo ADMIN mancante, lo aggiungo...');
      
      // Aggiungi il ruolo ADMIN
      await prisma.personRole.create({
        data: {
          personId: admin.id,
          roleType: 'ADMIN',
          tenantId: admin.tenantId,
          isActive: true,
          assignedAt: new Date(),
          assignedBy: admin.id // Auto-assegnato
        }
      });
      
      console.log('✅ Ruolo ADMIN aggiunto');
    }

    // 3. Verifica finale
    const finalRoles = await prisma.personRole.findMany({
      where: {
        personId: admin.id,
        isActive: true
      }
    });

    console.log(`📋 Ruoli finali: ${finalRoles.map(r => r.roleType).join(', ')}`);
    console.log('🎉 Correzione completata!');

  } catch (error) {
    console.error('❌ Errore:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

fixAdminRole();