const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function fixFormPermissions() {
  try {
    console.log('🔍 Verifica e correzione permessi per form_templates, form_submissions e public_cms...');

    // Trova l'utente admin
    const admin = await prisma.person.findUnique({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: {
          where: { 
            roleType: 'ADMIN',
            isActive: true 
          },
          include: {
            permissions: true
          }
        }
      }
    });

    if (!admin || admin.personRoles.length === 0) {
      console.error('❌ Admin non trovato o senza ruoli ADMIN');
      return;
    }

    const adminRole = admin.personRoles[0];
    console.log(`👤 Admin trovato: ${admin.firstName} ${admin.lastName} (${admin.email})`);
    console.log(`📋 Ruolo ID: ${adminRole.id}`);

    // Permessi richiesti per le entità problematiche
    const requiredPermissions = [
      // Form Templates
      'VIEW_FORM_TEMPLATES',
      'CREATE_FORM_TEMPLATES',
      'EDIT_FORM_TEMPLATES',
      'DELETE_FORM_TEMPLATES',
      'MANAGE_FORM_TEMPLATES',
      
      // Form Submissions
      'VIEW_FORM_SUBMISSIONS',
      'CREATE_FORM_SUBMISSIONS',
      'EDIT_FORM_SUBMISSIONS',
      'DELETE_FORM_SUBMISSIONS',
      'MANAGE_FORM_SUBMISSIONS',
      'EXPORT_FORM_SUBMISSIONS',
      
      // Public CMS
      'VIEW_PUBLIC_CMS',
      'CREATE_PUBLIC_CMS',
      'EDIT_PUBLIC_CMS',
      'DELETE_PUBLIC_CMS',
      'MANAGE_PUBLIC_CMS',
      
      // Permessi alternativi per compatibilità
      'VIEW_CMS',
      'CREATE_CMS',
      'EDIT_CMS',
      'DELETE_CMS',
      'MANAGE_PUBLIC_CONTENT',
      'READ_PUBLIC_CONTENT',
      
      'VIEW_SUBMISSIONS',
      'CREATE_SUBMISSIONS',
      'EDIT_SUBMISSIONS',
      'DELETE_SUBMISSIONS',
      'MANAGE_SUBMISSIONS',
      'EXPORT_SUBMISSIONS',
      
      'VIEW_TEMPLATES',
      'CREATE_TEMPLATES',
      'EDIT_TEMPLATES',
      'DELETE_TEMPLATES',
      'MANAGE_TEMPLATES'
    ];

    // Verifica permessi esistenti
    const existingPermissions = adminRole.permissions.map(p => p.permission);
    console.log(`📝 Permessi attuali: ${existingPermissions.length}`);

    // Trova permessi mancanti
    const missingPermissions = requiredPermissions.filter(perm => !existingPermissions.includes(perm));
    console.log(`📝 Permessi mancanti: ${missingPermissions.length}`);

    if (missingPermissions.length > 0) {
      console.log('\n🔧 Aggiungendo permessi mancanti...');
      
      for (const permission of missingPermissions) {
        try {
          await prisma.rolePermission.create({
            data: {
              personRoleId: adminRole.id,
              permission: permission,
              isGranted: true
            }
          });
          console.log(`   ✅ Aggiunto: ${permission}`);
        } catch (error) {
          console.log(`   ❌ Errore aggiungendo ${permission}: ${error.message}`);
        }
      }
    } else {
      console.log('✅ Tutti i permessi sono già presenti');
    }

    // Verifica finale
    console.log('\n🔍 Verifica finale...');
    const updatedRole = await prisma.personRole.findUnique({
      where: { id: adminRole.id },
      include: { permissions: true }
    });

    const formTemplatePermissions = updatedRole.permissions.filter(p => 
      p.permission.includes('FORM_TEMPLATES') || p.permission.includes('TEMPLATES')
    );
    const formSubmissionPermissions = updatedRole.permissions.filter(p => 
      p.permission.includes('FORM_SUBMISSIONS') || p.permission.includes('SUBMISSIONS')
    );
    const publicCmsPermissions = updatedRole.permissions.filter(p => 
      p.permission.includes('PUBLIC_CMS') || p.permission.includes('CMS')
    );

    console.log(`📊 Permessi form_templates: ${formTemplatePermissions.length}`);
    console.log(`📊 Permessi form_submissions: ${formSubmissionPermissions.length}`);
    console.log(`📊 Permessi public_cms: ${publicCmsPermissions.length}`);

    if (formTemplatePermissions.length > 0) {
      console.log('   Form Templates:');
      formTemplatePermissions.forEach(p => console.log(`     - ${p.permission}`));
    }

    if (formSubmissionPermissions.length > 0) {
      console.log('   Form Submissions:');
      formSubmissionPermissions.forEach(p => console.log(`     - ${p.permission}`));
    }

    if (publicCmsPermissions.length > 0) {
      console.log('   Public CMS:');
      publicCmsPermissions.forEach(p => console.log(`     - ${p.permission}`));
    }

    console.log('\n🎉 Correzione permessi completata!');

  } catch (error) {
    console.error('❌ Errore durante la correzione dei permessi:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixFormPermissions();