// Script per testare i permessi direttamente nel browser
// Apri la console del browser e incolla questo script

console.log('🔍 Debug Permessi - Inizio Test');

// Verifica se l'AuthContext è disponibile
if (window.authContextForTesting) {
  const auth = window.authContextForTesting;
  
  console.log('📋 Stato Autenticazione:', {
    isAuthenticated: auth.isAuthenticated,
    user: auth.user,
    permissionsCount: Object.keys(auth.permissions).length
  });
  
  console.log('🔑 Tutti i permessi disponibili:');
  Object.keys(auth.permissions).forEach(permission => {
    if (auth.permissions[permission] === true) {
      console.log(`  ✅ ${permission}`);
    }
  });
  
  console.log('\n🧪 Test permessi problematici:');
  
  // Test permessi CMS
  const cmsTests = [
    ['PUBLIC_CMS', 'READ'],
    ['PUBLIC_CMS', 'UPDATE'],
    ['PUBLIC_CMS', 'read'],
    ['PUBLIC_CMS', 'update'],
    ['public_cms', 'read'],
    ['public_cms', 'update']
  ];
  
  console.log('\n📄 Test permessi CMS:');
  cmsTests.forEach(([resource, action]) => {
    const result = auth.hasPermission(resource, action);
    console.log(`  ${result ? '✅' : '❌'} ${resource}:${action} = ${result}`);
  });
  
  // Test permessi Form Templates
  const formTemplateTests = [
    ['form_templates', 'read'],
    ['form_templates', 'update'],
    ['form_templates', 'create'],
    ['form_templates', 'delete'],
    ['FORM_TEMPLATES', 'READ'],
    ['FORM_TEMPLATES', 'UPDATE']
  ];
  
  console.log('\n📝 Test permessi Form Templates:');
  formTemplateTests.forEach(([resource, action]) => {
    const result = auth.hasPermission(resource, action);
    console.log(`  ${result ? '✅' : '❌'} ${resource}:${action} = ${result}`);
  });
  
  // Test permessi Form Submissions
  const formSubmissionTests = [
    ['form_submissions', 'read'],
    ['form_submissions', 'update'],
    ['form_submissions', 'create'],
    ['form_submissions', 'delete'],
    ['FORM_SUBMISSIONS', 'READ'],
    ['FORM_SUBMISSIONS', 'UPDATE']
  ];
  
  console.log('\n📊 Test permessi Form Submissions:');
  formSubmissionTests.forEach(([resource, action]) => {
    const result = auth.hasPermission(resource, action);
    console.log(`  ${result ? '✅' : '❌'} ${resource}:${action} = ${result}`);
  });
  
  // Test permessi backend diretti
  const backendTests = [
    'EDIT_FORM_TEMPLATES',
    'EDIT_FORM_SUBMISSIONS',
    'MANAGE_FORM_TEMPLATES',
    'MANAGE_FORM_SUBMISSIONS',
    'VIEW_FORM_TEMPLATES',
    'VIEW_FORM_SUBMISSIONS',
    'CREATE_FORM_TEMPLATES',
    'CREATE_FORM_SUBMISSIONS',
    'DELETE_FORM_TEMPLATES',
    'DELETE_FORM_SUBMISSIONS'
  ];
  
  console.log('\n🔧 Test permessi backend diretti:');
  backendTests.forEach(permission => {
    const result = auth.hasPermission(permission);
    console.log(`  ${result ? '✅' : '❌'} ${permission} = ${result}`);
  });
  
} else {
  console.error('❌ AuthContext non disponibile. Assicurati di essere in modalità development e di aver effettuato il login.');
}

console.log('\n🔍 Debug Permessi - Fine Test');