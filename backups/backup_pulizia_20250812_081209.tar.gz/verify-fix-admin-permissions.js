import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function verifyAndFixAdminPermissions() {
  try {
    console.log('🔍 VERIFICA E CORREZIONE PERMESSI ADMIN');
    console.log('=====================================');
    
    // 1. Trova l'utente admin
    console.log('\n1. 🔍 Ricerca utente admin...');
    const adminUser = await prisma.person.findFirst({
      where: {
        email: 'admin@example.com'
      },
      include: {
        personRoles: {
          include: {
            permissions: true
          }
        }
      }
    });
    
    if (!adminUser) {
      console.log('❌ Utente admin@example.com non trovato nel database');
      return;
    }
    
    console.log('✅ Utente admin trovato:', {
      id: adminUser.id,
      email: adminUser.email,
      firstName: adminUser.firstName,
      lastName: adminUser.lastName,
      ruoli: adminUser.personRoles.length
    });
    
    // 2. Verifica ruoli esistenti
    console.log('\n2. 🔍 Verifica ruoli esistenti...');
    if (adminUser.personRoles.length === 0) {
      console.log('⚠️ Nessun ruolo assegnato all\'admin');
      
      // Crea ruolo ADMIN
      console.log('📝 Creazione ruolo ADMIN...');
      const adminRole = await prisma.personRole.create({
        data: {
          personId: adminUser.id,
          roleType: 'ADMIN',
          assignedAt: new Date(),
          isActive: true
        }
      });
      console.log('✅ Ruolo ADMIN creato:', adminRole.id);
      
      // Ricarica l'utente con i nuovi ruoli
      const updatedUser = await prisma.person.findUnique({
        where: { id: adminUser.id },
        include: {
          personRoles: {
            include: {
              permissions: true
            }
          }
        }
      });
      adminUser.personRoles = updatedUser.personRoles;
    } else {
      console.log('✅ Ruoli esistenti:');
      adminUser.personRoles.forEach(role => {
        console.log(`  - ${role.roleType} (ID: ${role.id}, Attivo: ${role.isActive})`);
      });
    }
    
    // 3. Verifica permessi critici
    console.log('\n3. 🔍 Verifica permessi critici...');
    const permessiCritici = [
      'ROLE_MANAGEMENT',
      'VIEW_ROLES',
      'CREATE_ROLES',
      'EDIT_ROLES',
      'DELETE_ROLES',
      'ADMIN_PANEL',
      'USER_MANAGEMENT',
      'SYSTEM_SETTINGS',
      'VIEW_COMPANIES',
      'VIEW_PERSONS'
    ];
    
    // Ottieni tutti i permessi attuali
    const permessiAttuali = new Set();
    adminUser.personRoles.forEach(role => {
      role.permissions.forEach(perm => {
        if (perm.isGranted) {
          permessiAttuali.add(perm.permission);
        }
      });
    });
    
    console.log('📋 Permessi attuali:', Array.from(permessiAttuali));
    
    // 4. Aggiungi permessi mancanti
    console.log('\n4. 📝 Aggiunta permessi mancanti...');
    const ruoloAdmin = adminUser.personRoles.find(r => r.roleType === 'ADMIN' || r.roleType === 'SUPER_ADMIN');
    
    if (!ruoloAdmin) {
      console.log('❌ Nessun ruolo ADMIN/SUPER_ADMIN trovato');
      return;
    }
    
    let permessiAggiunti = 0;
    for (const permesso of permessiCritici) {
      if (!permessiAttuali.has(permesso)) {
        try {
          await prisma.rolePermission.create({
            data: {
              roleId: ruoloAdmin.id,
              permission: permesso,
              isGranted: true,
              grantedAt: new Date()
            }
          });
          console.log(`✅ Aggiunto permesso: ${permesso}`);
          permessiAggiunti++;
        } catch (error) {
          if (error.code === 'P2002') {
            console.log(`⚠️ Permesso ${permesso} già esistente (aggiornamento isGranted)`);
            await prisma.rolePermission.updateMany({
              where: {
                roleId: ruoloAdmin.id,
                permission: permesso
              },
              data: {
                isGranted: true,
                grantedAt: new Date()
              }
            });
          } else {
            console.log(`❌ Errore aggiungendo ${permesso}:`, error.message);
          }
        }
      } else {
        console.log(`✅ Permesso già presente: ${permesso}`);
      }
    }
    
    console.log(`\n📊 Permessi aggiunti: ${permessiAggiunti}`);
    
    // 5. Verifica finale
    console.log('\n5. 🔍 Verifica finale...');
    const adminFinal = await prisma.person.findUnique({
      where: { id: adminUser.id },
      include: {
        personRoles: {
          include: {
            permissions: {
              where: {
                isGranted: true
              }
            }
          }
        }
      }
    });
    
    const permessiFinal = new Set();
    adminFinal.personRoles.forEach(role => {
      role.permissions.forEach(perm => {
        permessiFinal.add(perm.permission);
      });
    });
    
    console.log('📋 Permessi finali:', Array.from(permessiFinal).sort());
    console.log('📊 Totale permessi:', permessiFinal.size);
    
    // Verifica permessi critici per i ruoli
    const permessiRuoli = Array.from(permessiFinal).filter(p => 
      p.includes('ROLE') || p.includes('roles')
    );
    console.log('🔑 Permessi relativi ai ruoli:', permessiRuoli);
    
    if (permessiFinal.has('ROLE_MANAGEMENT')) {
      console.log('✅ ROLE_MANAGEMENT presente - accesso ai ruoli dovrebbe funzionare');
    } else {
      console.log('❌ ROLE_MANAGEMENT mancante - accesso ai ruoli non funzionerà');
    }
    
    console.log('\n🎯 CORREZIONE COMPLETATA');
    console.log('========================');
    console.log('Ora testa il login con admin@example.com / Admin123!');
    
  } catch (error) {
    console.error('❌ Errore durante la verifica/correzione:', error);
  } finally {
    await prisma.$disconnect();
  }
}

// Esegui lo script
verifyAndFixAdminPermissions();