#!/usr/bin/env node

/**
 * Script per debuggare il comportamento del frontend Dashboard
 */

const puppeteer = require('puppeteer');

async function debugFrontendDashboard() {
  console.log('🔍 Debugging Frontend Dashboard...\n');

  let browser;
  try {
    // Avvia browser
    browser = await puppeteer.launch({ 
      headless: false, 
      devtools: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    
    // Intercetta console logs
    page.on('console', msg => {
      const type = msg.type();
      const text = msg.text();
      if (type === 'error') {
        console.log('🔴 [BROWSER ERROR]:', text);
      } else if (type === 'warn') {
        console.log('🟡 [BROWSER WARN]:', text);
      } else if (text.includes('Counters') || text.includes('Dashboard') || text.includes('API')) {
        console.log('🔵 [BROWSER LOG]:', text);
      }
    });

    // Intercetta richieste di rete
    page.on('request', request => {
      const url = request.url();
      if (url.includes('/api/')) {
        console.log('📤 [REQUEST]:', request.method(), url);
      }
    });

    page.on('response', response => {
      const url = response.url();
      if (url.includes('/api/')) {
        console.log('📥 [RESPONSE]:', response.status(), url);
      }
    });

    // Vai alla homepage
    console.log('🌐 Navigating to frontend...');
    await page.goto('http://localhost:5173', { waitUntil: 'networkidle2' });

    // Aspetta che la pagina si carichi
    await page.waitForTimeout(2000);

    // Verifica se c'è una pagina di login
    const loginForm = await page.$('form[data-testid="login-form"], input[type="email"], input[name="email"], input[placeholder*="email"]');
    
    if (loginForm) {
      console.log('🔐 Login form detected, performing login...');
      
      // Trova i campi di login
      const emailField = await page.$('input[type="email"], input[name="email"], input[name="identifier"], input[placeholder*="email"]');
      const passwordField = await page.$('input[type="password"], input[name="password"]');
      const submitButton = await page.$('button[type="submit"], button:contains("Login"), button:contains("Accedi")');

      if (emailField && passwordField) {
        await emailField.type('admin@example.com');
        await passwordField.type('Admin123!');
        
        if (submitButton) {
          await submitButton.click();
        } else {
          await page.keyboard.press('Enter');
        }
        
        // Aspetta il redirect dopo login
        await page.waitForTimeout(3000);
      }
    }

    // Verifica localStorage
    const localStorage = await page.evaluate(() => {
      return {
        token: localStorage.getItem('token'),
        tenantId: localStorage.getItem('tenantId'),
        user: localStorage.getItem('user'),
        allKeys: Object.keys(localStorage)
      };
    });
    
    console.log('💾 [LOCALSTORAGE]:', localStorage);

    // Verifica se siamo nella dashboard
    await page.waitForTimeout(2000);
    
    // Cerca i contatori nella pagina
    const counters = await page.evaluate(() => {
      const elements = [];
      
      // Cerca elementi con "Totale Aziende" e "Totale Dipendenti"
      const textNodes = document.evaluate(
        "//text()[contains(., 'Totale Aziende') or contains(., 'Totale Dipendenti')]",
        document,
        null,
        XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
        null
      );
      
      for (let i = 0; i < textNodes.snapshotLength; i++) {
        const node = textNodes.snapshotItem(i);
        const parent = node.parentElement;
        if (parent) {
          const container = parent.closest('div');
          if (container) {
            const valueElement = container.querySelector('h3, .text-2xl, [class*="text-2xl"]');
            elements.push({
              label: node.textContent.trim(),
              value: valueElement ? valueElement.textContent.trim() : 'NOT_FOUND',
              html: container.outerHTML.substring(0, 200) + '...'
            });
          }
        }
      }
      
      return elements;
    });
    
    console.log('📊 [COUNTERS FOUND]:', counters);

    // Verifica chiamate API in corso
    await page.waitForTimeout(5000);
    
    // Controlla di nuovo i contatori dopo un po'
    const countersAfter = await page.evaluate(() => {
      const elements = [];
      
      const textNodes = document.evaluate(
        "//text()[contains(., 'Totale Aziende') or contains(., 'Totale Dipendenti')]",
        document,
        null,
        XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
        null
      );
      
      for (let i = 0; i < textNodes.snapshotLength; i++) {
        const node = textNodes.snapshotItem(i);
        const parent = node.parentElement;
        if (parent) {
          const container = parent.closest('div');
          if (container) {
            const valueElement = container.querySelector('h3, .text-2xl, [class*="text-2xl"]');
            elements.push({
              label: node.textContent.trim(),
              value: valueElement ? valueElement.textContent.trim() : 'NOT_FOUND'
            });
          }
        }
      }
      
      return elements;
    });
    
    console.log('📊 [COUNTERS AFTER 5s]:', countersAfter);

    // Mantieni il browser aperto per debug manuale
    console.log('🔍 Browser left open for manual inspection. Press Ctrl+C to close.');
    await new Promise(() => {}); // Keep alive

  } catch (error) {
    console.error('❌ Debug failed:', error.message);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

// Verifica se puppeteer è disponibile
try {
  require('puppeteer');
  debugFrontendDashboard();
} catch (error) {
  console.log('⚠️  Puppeteer not available, installing...');
  console.log('Run: npm install puppeteer');
  console.log('Then run this script again.');
}