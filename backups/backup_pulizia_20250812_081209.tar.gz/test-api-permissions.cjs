// Script per testare l'API dei permessi
// Eseguire con: node test-api-permissions.js

const fetch = require('node-fetch');

const API_BASE = 'http://localhost:4003';
const CREDENTIALS = {
  identifier: 'admin@example.com',
  password: 'Admin123!'
};

async function testPermissionsAPI() {
  console.log('🔍 Test API Permessi');
  console.log('===================');
  
  try {
    // 1. Login
    console.log('\n1️⃣ Login...');
    const loginResponse = await fetch(`${API_BASE}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(CREDENTIALS)
    });
    
    if (!loginResponse.ok) {
      throw new Error(`Login failed: ${loginResponse.status} ${loginResponse.statusText}`);
    }
    
    const loginData = await loginResponse.json();
    console.log('✅ Login successful');
    console.log('👤 User:', loginData.user?.email);
    console.log('🔑 Token length:', loginData.token?.length || 0);
    
    const token = loginData.token;
    
    // 2. Verify Token
    console.log('\n2️⃣ Verify Token...');
    const verifyResponse = await fetch(`${API_BASE}/api/auth/verify`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
    });
    
    if (!verifyResponse.ok) {
      throw new Error(`Verify failed: ${verifyResponse.status} ${verifyResponse.statusText}`);
    }
    
    const verifyData = await verifyResponse.json();
    console.log('✅ Token verification successful');
    console.log('👤 User:', verifyData.user?.email);
    console.log('🔐 Valid:', verifyData.valid);
    console.log('📊 Permissions count:', Object.keys(verifyData.permissions || {}).length);
    
    // 3. Analizza i permessi
    console.log('\n3️⃣ Analisi Permessi Backend...');
    const permissions = verifyData.permissions || {};
    
    // Filtra per categorie
    const allPermissions = Object.keys(permissions).filter(key => permissions[key] === true);
    const cmsPermissions = allPermissions.filter(key => 
      key.includes('CMS') || key.includes('PUBLIC') || key.includes('CONTENT')
    );
    const formPermissions = allPermissions.filter(key => 
      key.includes('FORM') || key.includes('TEMPLATE') || key.includes('SUBMISSION')
    );
    
    console.log(`📋 Totale permessi: ${allPermissions.length}`);
    
    console.log('\n🏛️ Permessi CMS trovati:');
    if (cmsPermissions.length > 0) {
      cmsPermissions.forEach(perm => console.log(`  ✓ ${perm}`));
    } else {
      console.log('  ❌ Nessun permesso CMS trovato!');
    }
    
    console.log('\n📝 Permessi Form trovati:');
    if (formPermissions.length > 0) {
      formPermissions.forEach(perm => console.log(`  ✓ ${perm}`));
    } else {
      console.log('  ❌ Nessun permesso Form trovato!');
    }
    
    // 4. Test permessi specifici
    console.log('\n4️⃣ Test Permessi Specifici...');
    const permissionsToCheck = [
      'VIEW_CMS',
      'MANAGE_PUBLIC_CONTENT',
      'VIEW_FORM_TEMPLATES',
      'MANAGE_FORM_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS',
      'MANAGE_FORM_SUBMISSIONS',
      'VIEW_SUBMISSIONS',
      'MANAGE_SUBMISSIONS'
    ];
    
    permissionsToCheck.forEach(perm => {
      const hasIt = permissions[perm] === true;
      console.log(`${hasIt ? '✅' : '❌'} ${perm}: ${hasIt}`);
    });
    
    // 5. Mostra tutti i permessi per debug
    console.log('\n5️⃣ Tutti i Permessi (per debug):');
    allPermissions.forEach(perm => {
      console.log(`  ✓ ${perm}`);
    });
    
    return {
      success: true,
      permissions: permissions,
      user: verifyData.user
    };
    
  } catch (error) {
    console.error('❌ Errore:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
}

// Esegui il test
testPermissionsAPI().then(result => {
  if (result.success) {
    console.log('\n✅ Test completato con successo');
  } else {
    console.log('\n❌ Test fallito:', result.error);
  }
});