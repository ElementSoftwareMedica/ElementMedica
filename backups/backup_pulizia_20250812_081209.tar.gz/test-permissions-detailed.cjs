const axios = require('axios');

const API_BASE_URL = 'http://localhost:4001';

// Credenziali admin
const adminCredentials = {
  identifier: 'admin@example.com',
  password: 'Admin123!'
};

async function testPermissionsDetailed() {
  try {
    console.log('🔐 === TEST DETTAGLIATO PERMESSI ADMIN ===\n');

    // 1. Login
    console.log('1. Effettuo login...');
    const loginResponse = await axios.post(`${API_BASE_URL}/api/v1/auth/login`, adminCredentials);
    
    console.log('   Risposta login:', JSON.stringify(loginResponse.data, null, 2));
    
    if (!loginResponse.data.success) {
      throw new Error('Login fallito: ' + loginResponse.data.error);
    }

    const loginData = loginResponse.data;
    const token = loginData.tokens?.access_token || loginData.token || loginData.accessToken;
    const user = loginData.user;
    const userId = user.id;
    
    console.log('✅ Login riuscito');
    console.log('   User ID:', userId);
    console.log('   User Role:', user.role);
    console.log('   Token presente:', !!token);

    // 2. Recupera permessi (usando endpoint di test)
    console.log('\n2. Recupero permessi utente...');
    const permissionsResponse = await axios.get(
      `${API_BASE_URL}/api/v1/auth/test-permissions`,
      {
        timeout: 10000 // 10 secondi di timeout
      }
    );

    if (!permissionsResponse.data.success) {
      throw new Error('Recupero permessi fallito: ' + permissionsResponse.data.error);
    }

    const backendPermissions = permissionsResponse.data.data.permissions;
    console.log('✅ Permessi recuperati');
    console.log('   Risposta completa:', JSON.stringify(permissionsResponse.data, null, 2));
    console.log('   Numero permessi backend:', Object.keys(backendPermissions).length);
    
    // Mostra tutti i permessi backend
    const activeBackendPermissions = Object.keys(backendPermissions).filter(key => backendPermissions[key] === true);
    console.log('   Permessi backend attivi:', activeBackendPermissions);

    // 3. Simula la conversione frontend
    console.log('\n3. Simulo conversione permessi frontend...');
    
    // Simula la funzione convertBackendToFrontendPermissions
    const frontendPermissions = {};
    
    // Mantieni i permessi backend originali
    Object.keys(backendPermissions).forEach(key => {
      if (backendPermissions[key] === true) {
        frontendPermissions[key] = true;
      }
    });
    
    // Aggiungi le mappature frontend specifiche per PUBLIC_CMS
    Object.keys(backendPermissions).forEach(backendKey => {
      if (backendPermissions[backendKey] === true) {
        // Caso speciale per MANAGE_PUBLIC_CONTENT -> PUBLIC_CMS
        if (backendKey === 'MANAGE_PUBLIC_CONTENT') {
          frontendPermissions['PUBLIC_CMS:READ'] = true;
          frontendPermissions['PUBLIC_CMS:CREATE'] = true;
          frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
          frontendPermissions['PUBLIC_CMS:DELETE'] = true;
          frontendPermissions['PUBLIC_CMS:read'] = true;
          frontendPermissions['PUBLIC_CMS:create'] = true;
          frontendPermissions['PUBLIC_CMS:update'] = true;
          frontendPermissions['PUBLIC_CMS:delete'] = true;
        }
        // Casi specifici per permessi CMS
        else if (backendKey === 'VIEW_CMS') {
          frontendPermissions['PUBLIC_CMS:READ'] = true;
          frontendPermissions['PUBLIC_CMS:read'] = true;
        }
        else if (backendKey === 'CREATE_CMS') {
          frontendPermissions['PUBLIC_CMS:CREATE'] = true;
          frontendPermissions['PUBLIC_CMS:create'] = true;
        }
        else if (backendKey === 'EDIT_CMS') {
          frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
          frontendPermissions['PUBLIC_CMS:update'] = true;
        }
        else if (backendKey === 'DELETE_CMS') {
          frontendPermissions['PUBLIC_CMS:DELETE'] = true;
          frontendPermissions['PUBLIC_CMS:delete'] = true;
        }
        else if (backendKey === 'READ_PUBLIC_CONTENT') {
          frontendPermissions['PUBLIC_CMS:READ'] = true;
          frontendPermissions['PUBLIC_CMS:read'] = true;
        }
        // Permessi FORM_TEMPLATES
        else if (backendKey === 'VIEW_FORM_TEMPLATES') {
          frontendPermissions['form_templates:read'] = true;
          frontendPermissions['form_templates:view'] = true;
        }
        else if (backendKey === 'MANAGE_FORM_TEMPLATES') {
          frontendPermissions['form_templates:read'] = true;
          frontendPermissions['form_templates:view'] = true;
          frontendPermissions['form_templates:create'] = true;
          frontendPermissions['form_templates:edit'] = true;
          frontendPermissions['form_templates:update'] = true;
          frontendPermissions['form_templates:delete'] = true;
        }
        // Permessi FORM_SUBMISSIONS
        else if (backendKey === 'VIEW_FORM_SUBMISSIONS') {
          frontendPermissions['form_submissions:read'] = true;
          frontendPermissions['form_submissions:view'] = true;
          frontendPermissions['submissions:read'] = true;
          frontendPermissions['submissions:view'] = true;
        }
        else if (backendKey === 'MANAGE_FORM_SUBMISSIONS') {
          frontendPermissions['form_submissions:read'] = true;
          frontendPermissions['form_submissions:view'] = true;
          frontendPermissions['form_submissions:create'] = true;
          frontendPermissions['form_submissions:edit'] = true;
          frontendPermissions['form_submissions:update'] = true;
          frontendPermissions['form_submissions:delete'] = true;
          frontendPermissions['submissions:read'] = true;
          frontendPermissions['submissions:view'] = true;
          frontendPermissions['submissions:create'] = true;
          frontendPermissions['submissions:edit'] = true;
          frontendPermissions['submissions:update'] = true;
          frontendPermissions['submissions:delete'] = true;
        }
      }
    });

    const activeFrontendPermissions = Object.keys(frontendPermissions).filter(key => frontendPermissions[key] === true);
    console.log('   Numero permessi frontend:', activeFrontendPermissions.length);
    console.log('   Permessi frontend attivi:', activeFrontendPermissions);

    // 4. Test controlli di accesso specifici
    console.log('\n4. Test controlli di accesso pagine...');
    
    // Simula la funzione hasPermission
    function hasPermission(resourceOrPermission, action) {
      let permissionToCheck;
      
      if (action) {
        permissionToCheck = `${resourceOrPermission}:${action}`;
      } else {
        permissionToCheck = resourceOrPermission;
      }
      
      console.log(`   🔍 Controllo: ${permissionToCheck}`);
      
      // Verifica permesso diretto
      if (frontendPermissions[permissionToCheck] === true) {
        console.log(`   ✅ Permesso trovato (diretto): ${permissionToCheck}`);
        return true;
      }
      
      // Se abbiamo due parametri, prova altri formati
      if (action) {
        // Verifica permesso all:*
        if (frontendPermissions['all:' + action] === true) {
          console.log(`   ✅ Permesso trovato (all:${action})`);
          return true;
        }
        
        // Verifica permesso resource:all
        if (frontendPermissions[resourceOrPermission + ':all'] === true) {
          console.log(`   ✅ Permesso trovato (${resourceOrPermission}:all)`);
          return true;
        }
        
        // Per azioni 'read', verifica se c'è almeno un permesso per la risorsa
        if (action === 'read') {
          const resourcePermissions = Object.keys(frontendPermissions)
            .filter(key => key.startsWith(resourceOrPermission + ':') && frontendPermissions[key] === true);
          
          if (resourcePermissions.length > 0) {
            console.log(`   ✅ Permesso trovato (almeno uno per ${resourceOrPermission}):`, resourcePermissions);
            return true;
          }
        }
      }
      
      console.log(`   ❌ Permesso NON trovato: ${permissionToCheck}`);
      return false;
    }

    // Test specifici per le pagine problematiche
    console.log('\n   === TEST PAGINA PUBLIC CMS ===');
    const canViewCMS = hasPermission('PUBLIC_CMS', 'READ');
    const canEditCMS = hasPermission('PUBLIC_CMS', 'UPDATE');
    console.log(`   canView (PUBLIC_CMS:READ): ${canViewCMS}`);
    console.log(`   canEdit (PUBLIC_CMS:UPDATE): ${canEditCMS}`);
    
    console.log('\n   === TEST PAGINA FORM TEMPLATES ===');
    const canViewTemplates = hasPermission('form_templates', 'read');
    console.log(`   canView (form_templates:read): ${canViewTemplates}`);
    
    console.log('\n   === TEST PAGINA FORM SUBMISSIONS ===');
    const canViewSubmissions = hasPermission('form_submissions', 'read');
    console.log(`   canView (form_submissions:read): ${canViewSubmissions}`);

    // 5. Verifica permessi specifici che potrebbero mancare
    console.log('\n5. Verifica permessi specifici...');
    
    const permissionsToCheck = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE', 
      'form_templates:read',
      'form_submissions:read',
      'MANAGE_PUBLIC_CONTENT',
      'VIEW_CMS',
      'EDIT_CMS',
      'VIEW_FORM_TEMPLATES',
      'MANAGE_FORM_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS',
      'MANAGE_FORM_SUBMISSIONS'
    ];
    
    permissionsToCheck.forEach(permission => {
      const hasIt = frontendPermissions[permission] === true;
      console.log(`   ${hasIt ? '✅' : '❌'} ${permission}: ${hasIt}`);
    });

    console.log('\n🎯 === RISULTATO ANALISI ===');
    console.log('Se le pagine negano ancora l\'accesso nonostante i permessi siano presenti,');
    console.log('il problema potrebbe essere:');
    console.log('1. Formato dei permessi non corretto nelle pagine');
    console.log('2. Logica di controllo diversa nelle pagine');
    console.log('3. Cache dei permessi non aggiornata');
    console.log('4. Errore nella conversione backend->frontend');

  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
    if (error.response) {
      console.error('   Status:', error.response.status);
      console.error('   Data:', error.response.data);
    }
  }
}

testPermissionsDetailed();