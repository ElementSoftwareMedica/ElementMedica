const axios = require('axios');

async function testLoginAndVerify() {
    try {
        console.log('=== TEST LOGIN E VERIFICA PERMESSI PERSONS ===');
        
        // 1. Login
        console.log('\n1. Tentativo di login...');
        const loginResponse = await axios.post('http://localhost:4003/api/auth/login', {
            identifier: 'admin@example.com',
            password: 'Admin123!'
        }, {
            headers: {
                'Content-Type': 'application/json',
                'x-tenant-id': 'default-company'
            }
        });
        
        console.log('Login response status:', loginResponse.status);
        console.log('Login success:', loginResponse.data.success);
        
        const token = loginResponse.data.accessToken || loginResponse.data.token;
        if (!token) {
            console.error('No token received from login');
            return;
        }
        
        console.log('Token received:', token.substring(0, 20) + '...');
        
        // 2. Verifica permessi
        console.log('\n=== VERIFICA PERMESSI PERSONS ===');
        console.log('Login successful, verifying permissions...');
        
        const verifyResponse = await axios.get('http://localhost:4003/api/v1/auth/verify', {
            headers: {
                'Authorization': `Bearer ${token}`,
                'x-tenant-id': 'default-company'
            }
        });
        
        console.log('Verify response status:', verifyResponse.status);
        const permissions = verifyResponse.data.permissions || [];
        
        console.log('\n=== DEBUG: RUOLO UTENTE ===');
        console.log('User role:', verifyResponse.data.userRole);
        console.log('User roles:', verifyResponse.data.userRoles);
        console.log('User data:', JSON.stringify({
            id: verifyResponse.data.id,
            email: verifyResponse.data.email,
            userRole: verifyResponse.data.userRole,
            userRoles: verifyResponse.data.userRoles
        }, null, 2));
        
        console.log('\n=== DEBUG: TUTTI I PERMESSI ===');
        console.log('Total permissions count:', permissions.length);
        console.log('All permissions:', JSON.stringify(permissions, null, 2));
        
        // 3. Test permessi specifici persons
        const personsPermissions = [
            'persons:read',
            'persons:view', 
            'persons:create',
            'persons:edit',
            'persons:delete',
            'persons:manage',
            'persons:view_employees',
            'persons:view_trainers',
            'VIEW_PERSONS',
            'CREATE_PERSONS',
            'EDIT_PERSONS',
            'DELETE_PERSONS'
        ];
        
        console.log('\n=== TEST PERMESSI PERSONS ===');
        let grantedCount = 0;
        let missingPermissions = [];
        
        personsPermissions.forEach(permission => {
            const hasPermission = permissions.includes(permission);
            console.log(`${permission}: ${hasPermission ? '✅ CONCESSO' : '❌ MANCANTE'}`);
            if (hasPermission) {
                grantedCount++;
            } else {
                missingPermissions.push(permission);
            }
        });
        
        console.log(`\n=== RIEPILOGO ===`);
        console.log(`Permessi concessi: ${grantedCount}/${personsPermissions.length}`);
        if (missingPermissions.length > 0) {
            console.log(`Permessi mancanti: ${missingPermissions.join(', ')}`);
        } else {
            console.log('✅ Tutti i permessi persons sono stati concessi!');
        }
        
    } catch (error) {
        console.error('Errore durante il test:', error.message);
        if (error.response) {
            console.error('Response status:', error.response.status);
            console.error('Response data:', error.response.data);
        }
    }
}

testLoginAndVerify();