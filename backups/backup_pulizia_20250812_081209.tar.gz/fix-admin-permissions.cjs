const { PrismaClient } = require('./backend/node_modules/@prisma/client');
const axios = require('axios');

const prisma = new PrismaClient();

async function fixAdminPermissions() {
  try {
    console.log('🔧 Verifica e correzione permessi admin...');

    // 1. Trova l'utente admin
    const admin = await prisma.person.findUnique({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: {
          where: { isActive: true },
          include: {
            permissions: true
          }
        }
      }
    });

    if (!admin) {
      console.log('❌ Utente admin non trovato');
      return;
    }

    console.log(`✅ Admin trovato: ${admin.email}`);
    console.log(`   Ruoli attivi: ${admin.personRoles.length}`);

    // 2. Trova il ruolo ADMIN
    let adminRole = admin.personRoles.find(role => role.roleType === 'ADMIN');
    
    if (!adminRole) {
      console.log('⚠️  Ruolo ADMIN non trovato, creazione...');
      adminRole = await prisma.personRole.create({
        data: {
          personId: admin.id,
          roleType: 'ADMIN',
          isActive: true,
          assignedBy: admin.id
        },
        include: {
          permissions: true
        }
      });
      console.log('✅ Ruolo ADMIN creato');
    }

    console.log(`   Permessi attuali: ${adminRole.permissions?.length || 0}`);

    // 3. Lista di tutti i permessi che l'admin dovrebbe avere (solo permessi validi)
    const requiredPermissions = [
      // Permessi base
      'VIEW_DASHBOARD', 'MANAGE_DASHBOARD',
      
      // Permessi entità esistenti
      'VIEW_PERSONS', 'CREATE_PERSONS', 'EDIT_PERSONS', 'DELETE_PERSONS',
      'VIEW_COMPANIES', 'CREATE_COMPANIES', 'EDIT_COMPANIES', 'DELETE_COMPANIES',
      'VIEW_COURSES', 'CREATE_COURSES', 'EDIT_COURSES', 'DELETE_COURSES',
      'VIEW_TRAININGS', 'CREATE_TRAININGS', 'EDIT_TRAININGS', 'DELETE_TRAININGS',
      'VIEW_ROLES', 'CREATE_ROLES', 'EDIT_ROLES', 'DELETE_ROLES',
      'VIEW_HIERARCHY', 'CREATE_HIERARCHY', 'EDIT_HIERARCHY', 'DELETE_HIERARCHY',
      'VIEW_EMPLOYEES', 'CREATE_EMPLOYEES', 'EDIT_EMPLOYEES', 'DELETE_EMPLOYEES',
      'VIEW_TRAINERS', 'CREATE_TRAINERS', 'EDIT_TRAINERS', 'DELETE_TRAINERS',
      'VIEW_DOCUMENTS', 'CREATE_DOCUMENTS', 'EDIT_DOCUMENTS', 'DELETE_DOCUMENTS',
      'VIEW_CERTIFICATES', 'CREATE_CERTIFICATES', 'EDIT_CERTIFICATES', 'DELETE_CERTIFICATES',
      'VIEW_SETTINGS', 'CREATE_SETTINGS', 'EDIT_SETTINGS', 'DELETE_SETTINGS',
      
      // Permessi CMS e Form
      'VIEW_PUBLIC_CMS', 'CREATE_PUBLIC_CMS', 'EDIT_PUBLIC_CMS', 'DELETE_PUBLIC_CMS', 'MANAGE_PUBLIC_CMS',
      'VIEW_TEMPLATES', 'CREATE_TEMPLATES', 'EDIT_TEMPLATES', 'DELETE_TEMPLATES', 'MANAGE_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS', 'CREATE_FORM_SUBMISSIONS', 'EDIT_FORM_SUBMISSIONS', 'DELETE_FORM_SUBMISSIONS',
      
      // Permessi avanzati
      'MANAGE_PERMISSIONS', 'MANAGE_USERS',
      'VIEW_AUDIT_LOGS'
    ];

    // 4. Verifica permessi esistenti
    const existingPermissions = adminRole.permissions?.map(rp => rp.permission) || [];
    const missingPermissions = requiredPermissions.filter(p => !existingPermissions.includes(p));

    console.log(`   Permessi mancanti: ${missingPermissions.length}`);

    if (missingPermissions.length > 0) {
      console.log('🔧 Aggiunta permessi mancanti...');
      
      // 5. Aggiungi permessi mancanti
      for (const permission of missingPermissions) {
        try {
          await prisma.rolePermission.create({
            data: {
              personRoleId: adminRole.id,
              permission: permission,
              isGranted: true,
              grantedBy: admin.id
            }
          });
          console.log(`   ✅ Aggiunto: ${permission}`);
        } catch (error) {
          console.log(`   ❌ Errore aggiungendo ${permission}:`, error.message);
        }
      }
    }

    // 6. Verifica finale
    const updatedRole = await prisma.personRole.findUnique({
      where: { id: adminRole.id },
      include: { permissions: true }
    });

    console.log(`✅ Permessi finali: ${updatedRole.permissions.length}`);

    // 7. Test API per verificare
    console.log('\n🧪 Test API permessi...');
    
    try {
      // Login
      const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
        identifier: 'admin@example.com',
        password: 'Admin123!'
      });

      const token = loginResponse.data.tokens?.access_token || loginResponse.data.token;
      
      // Test permessi
      const permissionsResponse = await axios.get(`http://localhost:4001/api/v1/auth/permissions/${admin.id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      const activePermissions = Object.keys(permissionsResponse.data.permissions || {}).filter(
        key => permissionsResponse.data.permissions[key] === true
      );

      console.log(`   Permessi attivi API: ${activePermissions.length}`);
      
      // Test permessi specifici
      const testPermissions = ['PUBLIC_CMS:READ', 'form_templates:read', 'form_submissions:read'];
      testPermissions.forEach(perm => {
        const hasPermission = permissionsResponse.data.permissions[perm];
        console.log(`   ${perm}: ${hasPermission ? '✅' : '❌'}`);
      });

    } catch (error) {
      console.log('❌ Errore test API:', error.message);
    }

  } catch (error) {
    console.error('❌ Errore:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixAdminPermissions();