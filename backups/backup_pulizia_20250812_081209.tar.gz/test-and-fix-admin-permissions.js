#!/usr/bin/env node

import { PrismaClient } from './backend/node_modules/@prisma/client/index.js';

const prisma = new PrismaClient();

async function testAndFixAdminPermissions() {
  try {
    console.log('🔍 Verifica e correzione permessi ADMIN...\n');

    // 1. Trova l'utente admin
    const adminPerson = await prisma.person.findFirst({
      where: {
        email: 'admin@example.com'
      },
      include: {
        personRoles: {
          include: {
            permissions: true
          }
        }
      }
    });

    if (!adminPerson) {
      console.log('❌ Utente admin non trovato');
      return;
    }

    console.log(`✅ Utente admin trovato: ${adminPerson.email}`);
    console.log(`📋 Ruoli attuali: ${adminPerson.personRoles.map(r => r.roleType).join(', ')}\n`);

    // 2. Trova o crea un PersonRole ADMIN per l'utente
    let adminPersonRole = adminPerson.personRoles.find(r => r.roleType === 'ADMIN');
    
    if (!adminPersonRole) {
      console.log('⚠️ PersonRole ADMIN non trovato, lo creo...');
      adminPersonRole = await prisma.personRole.create({
        data: {
          personId: adminPerson.id,
          roleType: 'ADMIN',
          tenantId: adminPerson.tenantId,
          companyId: adminPerson.companyId,
          isActive: true,
          isPrimary: true
        },
        include: {
          permissions: true
        }
      });
      console.log('✅ PersonRole ADMIN creato');
    } else {
      // Carica i permessi esistenti
      adminPersonRole = await prisma.personRole.findUnique({
        where: { id: adminPersonRole.id },
        include: { permissions: true }
      });
    }

    // 3. Definisci tutti i permessi necessari per l'admin
    const requiredPermissions = [
      // Permessi base
      'VIEW_COMPANIES', 'CREATE_COMPANIES', 'EDIT_COMPANIES', 'DELETE_COMPANIES',
      'VIEW_EMPLOYEES', 'CREATE_EMPLOYEES', 'EDIT_EMPLOYEES', 'DELETE_EMPLOYEES',
      'VIEW_TRAINERS', 'CREATE_TRAINERS', 'EDIT_TRAINERS', 'DELETE_TRAINERS',
      'VIEW_USERS', 'CREATE_USERS', 'EDIT_USERS', 'DELETE_USERS',
      'VIEW_COURSES', 'CREATE_COURSES', 'EDIT_COURSES', 'DELETE_COURSES',
      'VIEW_PERSONS', 'CREATE_PERSONS', 'EDIT_PERSONS', 'DELETE_PERSONS',
      
      // Permessi amministrativi
      'ADMIN_PANEL', 'SYSTEM_SETTINGS', 'USER_MANAGEMENT', 'ROLE_MANAGEMENT',
      'VIEW_ROLES', 'CREATE_ROLES', 'EDIT_ROLES', 'DELETE_ROLES',
      'ROLE_CREATE', 'ROLE_EDIT', 'ROLE_DELETE',
      'MANAGE_USERS', 'ASSIGN_ROLES', 'REVOKE_ROLES',
      
      // Permessi CMS
      'VIEW_CMS', 'CREATE_CMS', 'EDIT_CMS', 'DELETE_CMS',
      'MANAGE_PUBLIC_CONTENT', 'READ_PUBLIC_CONTENT',
      'VIEW_PUBLIC_CMS', 'CREATE_PUBLIC_CMS', 'EDIT_PUBLIC_CMS', 'DELETE_PUBLIC_CMS', 'MANAGE_PUBLIC_CMS',
      
      // Permessi Form Templates
      'VIEW_FORM_TEMPLATES', 'CREATE_FORM_TEMPLATES', 'EDIT_FORM_TEMPLATES', 'DELETE_FORM_TEMPLATES', 'MANAGE_FORM_TEMPLATES',
      
      // Permessi Form Submissions
      'VIEW_SUBMISSIONS', 'CREATE_SUBMISSIONS', 'EDIT_SUBMISSIONS', 'DELETE_SUBMISSIONS', 'MANAGE_SUBMISSIONS', 'EXPORT_SUBMISSIONS',
      'VIEW_FORM_SUBMISSIONS', 'CREATE_FORM_SUBMISSIONS', 'EDIT_FORM_SUBMISSIONS', 'DELETE_FORM_SUBMISSIONS', 'MANAGE_FORM_SUBMISSIONS', 'EXPORT_FORM_SUBMISSIONS',
      
      // Permessi GDPR
      'VIEW_GDPR', 'CREATE_GDPR', 'EDIT_GDPR', 'DELETE_GDPR',
      'VIEW_GDPR_DATA', 'EXPORT_GDPR_DATA', 'DELETE_GDPR_DATA', 'MANAGE_CONSENTS',
      
      // Altri permessi
      'VIEW_REPORTS', 'CREATE_REPORTS', 'EDIT_REPORTS', 'DELETE_REPORTS', 'EXPORT_REPORTS',
      'VIEW_HIERARCHY', 'CREATE_HIERARCHY', 'EDIT_HIERARCHY', 'DELETE_HIERARCHY', 'MANAGE_HIERARCHY',
      'VIEW_SCHEDULES', 'CREATE_SCHEDULES', 'EDIT_SCHEDULES', 'DELETE_SCHEDULES',
      'VIEW_QUOTES', 'CREATE_QUOTES', 'EDIT_QUOTES', 'DELETE_QUOTES',
      'VIEW_INVOICES', 'CREATE_INVOICES', 'EDIT_INVOICES', 'DELETE_INVOICES'
    ];

    console.log(`📝 Permessi richiesti per ADMIN: ${requiredPermissions.length}`);

    // 4. Rimuovi tutti i permessi esistenti del PersonRole ADMIN
    await prisma.rolePermission.deleteMany({
      where: {
        personRoleId: adminPersonRole.id
      }
    });
    console.log('🗑️ Permessi esistenti rimossi');

    // 5. Aggiungi tutti i permessi necessari
    let addedCount = 0;
    for (const permission of requiredPermissions) {
      try {
        await prisma.rolePermission.create({
          data: {
            personRoleId: adminPersonRole.id,
            permission: permission,
            isGranted: true
          }
        });
        addedCount++;
      } catch (error) {
        console.log(`⚠️ Errore aggiungendo permesso ${permission}:`, error.message);
      }
    }

    console.log(`✅ Aggiunti ${addedCount} permessi al PersonRole ADMIN\n`);

    // 6. Verifica finale dei permessi
    const finalAdminPerson = await prisma.person.findFirst({
      where: {
        email: 'admin@example.com'
      },
      include: {
        personRoles: {
          include: {
            permissions: true
          }
        }
      }
    });

    console.log('\n📊 VERIFICA FINALE:');
    console.log(`👤 Utente: ${finalAdminPerson.email}`);
    console.log(`🎭 PersonRoles: ${finalAdminPerson.personRoles.length}`);
    
    let totalPermissions = 0;
    let grantedPermissions = 0;
    
    finalAdminPerson.personRoles.forEach(personRole => {
      console.log(`\n🎭 PersonRole: ${personRole.roleType}`);
      console.log(`📋 Permessi totali: ${personRole.permissions.length}`);
      
      const granted = personRole.permissions.filter(p => p.isGranted === true);
      console.log(`✅ Permessi concessi: ${granted.length}`);
      
      totalPermissions += personRole.permissions.length;
      grantedPermissions += granted.length;
      
      // Mostra alcuni permessi specifici per CMS e Form
      const cmsPermissions = granted.filter(p => p.permission.includes('CMS') || p.permission.includes('PUBLIC_CONTENT'));
      const formPermissions = granted.filter(p => p.permission.includes('FORM') || p.permission.includes('SUBMISSION'));
      
      console.log(`🎨 Permessi CMS: ${cmsPermissions.map(p => p.permission).join(', ')}`);
      console.log(`📝 Permessi Form: ${formPermissions.map(p => p.permission).join(', ')}`);
    });

    console.log(`\n🎯 TOTALE PERMESSI: ${totalPermissions}`);
    console.log(`✅ PERMESSI CONCESSI: ${grantedPermissions}`);
    console.log(`❌ PERMESSI NEGATI: ${totalPermissions - grantedPermissions}`);

    if (grantedPermissions > 0) {
      console.log('\n🎉 SUCCESSO! I permessi sono stati configurati correttamente.');
    } else {
      console.log('\n❌ ERRORE! Nessun permesso è stato concesso.');
    }

  } catch (error) {
    console.error('❌ Errore durante il test dei permessi:', error);
  } finally {
    await prisma.$disconnect();
  }
}

// Esegui il test
testAndFixAdminPermissions();