const puppeteer = require('puppeteer');

async function testPermissionsComplete() {
  console.log('🚀 Starting complete permissions test...');
  
  const browser = await puppeteer.launch({ 
    headless: false,
    defaultViewport: null,
    args: ['--start-maximized']
  });
  
  try {
    const page = await browser.newPage();
    
    // Intercetta i log della console
    page.on('console', msg => {
      if (msg.text().includes('🔐') || msg.text().includes('✅') || msg.text().includes('❌')) {
        console.log('🖥️ Browser:', msg.text());
      }
    });
    
    // Vai alla pagina di login
    await page.goto('http://localhost:5173/login');
    await page.waitForSelector('input[name="identifier"]');
    
    console.log('📝 Step 1: Login...');
    await page.type('input[name="identifier"]', 'admin@example.com');
    await page.type('input[name="password"]', 'Admin123!');
    await page.click('button[type="submit"]');
    
    // Aspetta il redirect dopo il login
    await page.waitForNavigation();
    console.log('✅ Login successful');
    
    console.log('📝 Step 2: Testing complete hasPermission function...');
    
    // Testa la funzione hasPermission completa nel browser
    const testResults = await page.evaluate(async () => {
      // Aspetta che l'AuthContext sia caricato
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Ottieni il contesto di autenticazione
      const authContext = window.React?.useContext ? 
        window.authContextForTesting : 
        null;
      
      if (!authContext) {
        return { error: 'AuthContext not available' };
      }
      
      const results = {};
      
      // Test dei permessi problematici
      const permissionsToTest = [
        ['form_templates', 'read'],
        ['form_templates', 'update'],
        ['form_templates', 'edit'],
        ['form_submissions', 'read'], 
        ['form_submissions', 'update'],
        ['form_submissions', 'edit'],
        ['PUBLIC_CMS', 'READ'],
        ['PUBLIC_CMS', 'UPDATE']
      ];
      
      for (const [resource, action] of permissionsToTest) {
        try {
          const result = authContext.hasPermission(resource, action);
          results[`${resource}:${action}`] = result;
          console.log(`🧪 ${resource}:${action} = ${result}`);
        } catch (error) {
          results[`${resource}:${action}`] = `Error: ${error.message}`;
          console.error(`❌ Error testing ${resource}:${action}:`, error);
        }
      }
      
      // Mostra tutti i permessi disponibili
      const allPermissions = Object.keys(authContext.permissions || {})
        .filter(key => authContext.permissions[key] === true)
        .filter(key => key.includes('form_') || key.includes('PUBLIC_CMS') || key.includes('CMS'));
      
      results.availablePermissions = allPermissions;
      
      return results;
    });
    
    console.log('\n🎯 Complete hasPermission Test Results:');
    Object.entries(testResults).forEach(([key, value]) => {
      if (key === 'availablePermissions') {
        console.log(`📋 Available CMS/Form permissions (${value.length}):`, value);
      } else {
        const icon = value === true ? '✅' : value === false ? '❌' : '⚠️';
        console.log(`  ${icon} ${key}: ${value}`);
      }
    });
    
    // Test di accesso alle pagine problematiche
    console.log('\n📝 Step 3: Testing page access...');
    
    const pageTests = [
      { url: 'http://localhost:5173/settings', name: 'Settings Page' },
      { url: 'http://localhost:5173/forms', name: 'Forms Page' },
      { url: 'http://localhost:5173/forms/submissions', name: 'Form Submissions Page' }
    ];
    
    for (const pageTest of pageTests) {
      try {
        console.log(`🔍 Testing access to ${pageTest.name}...`);
        await page.goto(pageTest.url);
        await page.waitForTimeout(2000);
        
        // Verifica se c'è un messaggio di accesso negato
        const accessDenied = await page.evaluate(() => {
          const body = document.body.textContent || '';
          return body.includes('Non hai i permessi') || 
                 body.includes('Accesso negato') || 
                 body.includes('Access denied') ||
                 body.includes('non autorizzato');
        });
        
        const pageTitle = await page.title();
        console.log(`  ${accessDenied ? '❌' : '✅'} ${pageTest.name}: ${accessDenied ? 'Access Denied' : 'Access Granted'} (Title: ${pageTitle})`);
        
      } catch (error) {
        console.log(`  ⚠️ ${pageTest.name}: Error - ${error.message}`);
      }
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  } finally {
    await browser.close();
  }
}

// Esegui il test
testPermissionsComplete().catch(console.error);