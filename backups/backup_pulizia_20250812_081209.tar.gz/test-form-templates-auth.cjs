const axios = require('axios');

async function testDirectApiAuth() {
  try {
    console.log('🔐 Testing direct API server authentication (port 4001)...');
    
    // Step 1: Login to direct API server
    console.log('Step 1: Logging in to direct API server...');
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    }, {
      headers: {
        'Content-Type': 'application/json'
      },
      withCredentials: true
    });
    
    console.log('✅ Direct API login successful:', {
      status: loginResponse.status,
      message: loginResponse.data?.message || 'No message'
    });
    
    // Extract cookies from login response
    const cookies = loginResponse.headers['set-cookie'];
    console.log('🍪 Cookies received from direct API:', cookies ? cookies.length : 0);
    if (cookies) {
      cookies.forEach((cookie, index) => {
        console.log(`   Cookie ${index + 1}: ${cookie.split(';')[0]}`);
      });
    }
    
    // Step 2: Test form-templates endpoint with cookies on direct API
    console.log('\nStep 2: Testing form-templates endpoint on direct API...');
    const formTemplatesResponse = await axios.get('http://localhost:4001/api/v1/form-templates', {
      headers: {
        'Content-Type': 'application/json',
        'Cookie': cookies ? cookies.join('; ') : ''
      },
      withCredentials: true
    });
    
    console.log('✅ Direct API form templates request successful:', {
      status: formTemplatesResponse.status,
      dataLength: formTemplatesResponse.data?.length || 0
    });
    
  } catch (error) {
    console.error('❌ Direct API Error:', {
      message: error.message,
      status: error.response?.status,
      statusText: error.response?.statusText,
      data: error.response?.data
    });
  }
}

async function testProxyAuth() {
  try {
    console.log('\n🔐 Testing proxy server authentication (port 4003)...');
    
    // Step 1: Login via proxy
    console.log('Step 1: Logging in via proxy...');
    const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    }, {
      headers: {
        'Content-Type': 'application/json'
      },
      withCredentials: true
    });
    
    console.log('✅ Proxy login successful:', {
      status: loginResponse.status,
      message: loginResponse.data?.message || 'No message'
    });
    
    // Extract cookies from login response
    const cookies = loginResponse.headers['set-cookie'];
    console.log('🍪 Cookies received from proxy:', cookies ? cookies.length : 0);
    if (cookies) {
      cookies.forEach((cookie, index) => {
        console.log(`   Cookie ${index + 1}: ${cookie.split(';')[0]}`);
      });
    }
    
    // Step 2: Test form-templates endpoint with cookies via proxy
    console.log('\nStep 2: Testing form-templates endpoint via proxy...');
    const formTemplatesResponse = await axios.get('http://localhost:4003/api/v1/form-templates', {
      headers: {
        'Content-Type': 'application/json',
        'Cookie': cookies ? cookies.join('; ') : ''
      },
      withCredentials: true
    });
    
    console.log('✅ Proxy form templates request successful:', {
      status: formTemplatesResponse.status,
      dataLength: formTemplatesResponse.data?.length || 0
    });
    
  } catch (error) {
    console.error('❌ Proxy Error:', {
      message: error.message,
      status: error.response?.status,
      statusText: error.response?.statusText,
      data: error.response?.data
    });
  }
}

async function runTests() {
  await testDirectApiAuth();
  await testProxyAuth();
}

runTests();