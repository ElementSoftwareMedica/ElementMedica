const axios = require('axios');

async function testLoginAndPermissions() {
  try {
    console.log('🔐 Testing login and permissions...\n');
    
    // 1. Login
    console.log('1️⃣ Attempting login...');
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    console.log('Login response:', JSON.stringify(loginResponse.data, null, 2));
    
    if (!loginResponse.data.success) {
      console.log('❌ Login failed:', loginResponse.data.error);
      return;
    }
    
    console.log('✅ Login successful');
    const token = loginResponse.data.tokens?.access_token || loginResponse.data.token || loginResponse.data.data?.token;
    const user = loginResponse.data.user || loginResponse.data.data?.user;
    
    console.log('👤 User:', {
      id: user.id,
      email: user.email,
      role: user.role
    });
    
    // 2. Get user permissions
    console.log('\n2️⃣ Fetching user permissions...');
    const permissionsResponse = await axios.get(`http://localhost:4001/api/v1/auth/permissions/${user.id}`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!permissionsResponse.data.success) {
      console.log('❌ Failed to get permissions:', permissionsResponse.data.error);
      return;
    }
    
    console.log('✅ Permissions fetched successfully');
    const permissions = permissionsResponse.data.data;
    
    console.log('\n📊 Raw permissions from backend:');
    console.log('Total permissions:', Object.keys(permissions).length);
    
    // Filter CMS and Form permissions
    const cmsPermissions = Object.keys(permissions).filter(key => 
      key.includes('CMS') || key.includes('PUBLIC_CMS') || key.includes('MANAGE_PUBLIC_CONTENT')
    );
    
    const formPermissions = Object.keys(permissions).filter(key => 
      key.includes('FORM') || key.includes('TEMPLATE') || key.includes('SUBMISSION')
    );
    
    console.log('\n🎨 CMS Permissions:');
    cmsPermissions.forEach(perm => {
      console.log(`  ${permissions[perm] ? '✅' : '❌'} ${perm}`);
    });
    
    console.log('\n📝 Form Permissions:');
    formPermissions.forEach(perm => {
      console.log(`  ${permissions[perm] ? '✅' : '❌'} ${perm}`);
    });
    
    // 3. Test permission mapping
    console.log('\n3️⃣ Testing permission mapping...');
    
    // Import the mapping function
    const { convertBackendToFrontendPermissions } = require('./src/utils/permissionMapping.ts');
    
    const frontendPermissions = convertBackendToFrontendPermissions(permissions);
    
    console.log('\n🔄 Frontend permissions after conversion:');
    console.log('Total frontend permissions:', Object.keys(frontendPermissions).length);
    
    // Test specific permissions that the pages need
    const testPermissions = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE',
      'form_templates:read',
      'form_templates:update',
      'form_submissions:read',
      'form_submissions:update'
    ];
    
    console.log('\n🎯 Testing specific permissions needed by pages:');
    testPermissions.forEach(perm => {
      const hasPermission = frontendPermissions[perm] === true;
      console.log(`  ${hasPermission ? '✅' : '❌'} ${perm}`);
    });
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
    }
  }
}

testLoginAndPermissions();