require('dotenv').config({ path: './backend/.env' });
const { PrismaClient } = require('./backend/node_modules/@prisma/client');

console.log('Starting admin roles fix script...');
console.log('DATABASE_URL:', process.env.DATABASE_URL ? 'Set' : 'Not set');

let prisma;
try {
  prisma = new PrismaClient();
  console.log('Prisma client initialized successfully');
} catch (error) {
  console.error('Error initializing Prisma client:', error);
  process.exit(1);
}

async function fixAdminRoles() {
  try {
    console.log('Connecting to database...');
    await prisma.$connect();
    console.log('Database connected successfully');
    
    console.log('🔍 Checking admin user roles...');
    
    // Find admin user
    console.log('Searching for admin user...');
    const admin = await prisma.person.findUnique({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: true
      }
    });
    
    if (!admin) {
      console.log('❌ Admin user not found');
      return;
    }
    
    console.log('✅ Admin user found:', {
      id: admin.id,
      email: admin.email,
      globalRole: admin.globalRole,
      roles: admin.personRoles.map(r => r.roleType)
    });
    
    // Check if admin has SUPER_ADMIN role
    const hasSuperAdmin = admin.personRoles.some(r => r.roleType === 'SUPER_ADMIN' && r.isActive);
    
    if (!hasSuperAdmin) {
      console.log('⚠️ Admin does not have SUPER_ADMIN role, adding it...');
      
      await prisma.personRole.create({
        data: {
          personId: admin.id,
          roleType: 'SUPER_ADMIN',
          companyId: admin.companyId,
          tenantId: admin.tenantId,
          isActive: true,
          isPrimary: false
        }
      });
      
      console.log('✅ SUPER_ADMIN role added to admin user');
    } else {
      console.log('✅ Admin already has SUPER_ADMIN role');
    }
    
    // Update globalRole field if needed
    if (admin.globalRole !== 'SUPER_ADMIN') {
      console.log('⚠️ Updating globalRole field to SUPER_ADMIN...');
      
      await prisma.person.update({
        where: { id: admin.id },
        data: { globalRole: 'SUPER_ADMIN' }
      });
      
      console.log('✅ globalRole updated to SUPER_ADMIN');
    }
    
    // Verify final state
    const updatedAdmin = await prisma.person.findUnique({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: true
      }
    });
    
    console.log('🎉 Final admin state:', {
      id: updatedAdmin.id,
      email: updatedAdmin.email,
      globalRole: updatedAdmin.globalRole,
      roles: updatedAdmin.personRoles.map(r => ({ type: r.roleType, active: r.isActive }))
    });
    
    console.log('🎉 Admin roles fix completed successfully!');
    
  } catch (error) {
    console.error('❌ Error fixing admin roles:', error);
    console.error('Error details:', error.message);
    if (error.code) {
      console.error('Error code:', error.code);
    }
  } finally {
    console.log('Disconnecting from database...');
    await prisma.$disconnect();
    console.log('Database disconnected');
  }
}

fixAdminRoles().catch(error => {
  console.error('❌ Unhandled error:', error);
  process.exit(1);
});