const axios = require('axios');

async function testCounters() {
  try {
    console.log('🔐 Step 1: Login...');
    const loginResponse = await axios.post('http://localhost:4003/api/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    console.log('Login response data:', JSON.stringify(loginResponse.data, null, 2));
    const token = loginResponse.data.tokens.access_token;
    console.log('✅ Login successful, token exists:', !!token);
    
    console.log('\n🔄 Step 2: Test /api/counters with auth...');
    const countersResponse = await axios.get('http://localhost:4003/api/counters', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('✅ Counters response:', JSON.stringify(countersResponse.data, null, 2));
    
  } catch (error) {
    console.error('❌ Error:', error.response?.status, error.response?.data || error.message);
  }
}

testCounters();