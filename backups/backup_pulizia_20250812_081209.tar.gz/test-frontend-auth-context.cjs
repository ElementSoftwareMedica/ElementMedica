const puppeteer = require('puppeteer');

async function testFrontendAuthContext() {
    console.log('🚀 Starting frontend AuthContext test...');
    
    const browser = await puppeteer.launch({ 
        headless: false,
        devtools: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    try {
        const page = await browser.newPage();
        
        // Intercetta i log della console
        page.on('console', msg => {
            const type = msg.type();
            const text = msg.text();
            
            if (type === 'error') {
                console.log(`❌ CONSOLE ERROR: ${text}`);
            } else if (type === 'warn') {
                console.log(`⚠️  CONSOLE WARN: ${text}`);
            } else if (text.includes('AuthContext') || text.includes('permission') || text.includes('hasPermission')) {
                console.log(`📝 AUTH LOG: ${text}`);
            }
        });
        
        // Intercetta le richieste di rete
        page.on('response', response => {
            const url = response.url();
            if (url.includes('/auth/') || url.includes('/verify')) {
                console.log(`🌐 API RESPONSE: ${response.status()} ${url}`);
            }
        });
        
        console.log('📱 Navigating to frontend...');
        await page.goto('http://localhost:5173', { waitUntil: 'networkidle0' });
        
        console.log('🔐 Attempting login...');
        
        // Aspetta che la pagina di login sia caricata
        await page.waitForSelector('input[type="email"], input[name="identifier"]', { timeout: 10000 });
        
        // Compila il form di login
        await page.type('input[type="email"], input[name="identifier"]', 'admin@example.com');
        await page.type('input[type="password"], input[name="password"]', 'Admin123!');
        
        // Clicca il pulsante di login
        await page.click('button[type="submit"]');
        
        console.log('⏳ Waiting for login to complete...');
        
        // Aspetta che il login sia completato (redirect o cambio di contenuto)
        await page.waitForFunction(
            () => {
                return window.location.pathname !== '/login' || 
                       document.querySelector('[data-testid="dashboard"]') !== null ||
                       document.querySelector('.dashboard') !== null;
            },
            { timeout: 15000 }
        );
        
        console.log('✅ Login completed, checking permissions...');
        
        // Aspetta un po' per permettere al caricamento dei permessi di completarsi
        await page.waitForTimeout(3000);
        
        // Testa l'accesso alle pagine problematiche
        const pagesToTest = [
            { url: '/settings/cms', name: 'PublicCMS' },
            { url: '/forms', name: 'FormTemplates' },
            { url: '/forms/submissions', name: 'FormSubmissions' }
        ];
        
        for (const pageTest of pagesToTest) {
            console.log(`🧪 Testing access to ${pageTest.name} page...`);
            
            try {
                await page.goto(`http://localhost:5173${pageTest.url}`, { waitUntil: 'networkidle0' });
                
                // Controlla se c'è un messaggio di accesso negato
                const accessDenied = await page.$eval('body', body => {
                    return body.textContent.includes('Non hai i permessi') || 
                           body.textContent.includes('Accesso negato') ||
                           body.textContent.includes('Access denied');
                });
                
                if (accessDenied) {
                    console.log(`❌ ${pageTest.name}: Access DENIED`);
                } else {
                    console.log(`✅ ${pageTest.name}: Access GRANTED`);
                }
                
                // Aspetta un po' prima del prossimo test
                await page.waitForTimeout(1000);
                
            } catch (error) {
                console.log(`❌ ${pageTest.name}: Error accessing page - ${error.message}`);
            }
        }
        
        // Testa la funzione hasPermission direttamente nel browser
        console.log('🔍 Testing hasPermission function directly...');
        
        const permissionTests = await page.evaluate(() => {
            // Accedi al contesto di autenticazione se disponibile
            const authContext = window.authContext || window.useAuth;
            
            if (typeof authContext === 'undefined') {
                return { error: 'AuthContext not available in window' };
            }
            
            // Se hasPermission è disponibile, testala
            if (typeof window.hasPermission === 'function') {
                return {
                    'PUBLIC_CMS:READ': window.hasPermission('PUBLIC_CMS', 'READ'),
                    'PUBLIC_CMS:UPDATE': window.hasPermission('PUBLIC_CMS', 'UPDATE'),
                    'form_templates:read': window.hasPermission('form_templates', 'read'),
                    'form_submissions:read': window.hasPermission('form_submissions', 'read')
                };
            }
            
            return { error: 'hasPermission function not available in window' };
        });
        
        console.log('🧪 Permission test results:', permissionTests);
        
        console.log('✅ Frontend test completed. Check the browser for more details.');
        
        // Mantieni il browser aperto per ispezione manuale
        console.log('🔍 Browser left open for manual inspection. Press Ctrl+C to close.');
        await new Promise(() => {}); // Mantieni aperto indefinitamente
        
    } catch (error) {
        console.error('❌ Test failed:', error);
    } finally {
        // await browser.close(); // Commentato per mantenere aperto
    }
}

// Esegui il test
testFrontendAuthContext().catch(console.error);