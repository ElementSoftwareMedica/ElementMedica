const axios = require('axios');

const API_BASE = 'http://localhost:4001';

async function testDirectPageAccess() {
  console.log('🔐 Test accesso diretto alle pagine...\n');
  
  try {
    // 1. Login
    console.log('1. Effettuo login...');
    const loginResponse = await axios.post(`${API_BASE}/api/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    if (!loginResponse.data.success) {
      throw new Error('Login fallito');
    }
    
    const token = loginResponse.data.data.token;
    const headers = { 'Authorization': `Bearer ${token}` };
    
    console.log('✅ Login effettuato con successo');
    
    // 2. Verifica permessi attuali
    console.log('\n2. Verifico permessi attuali...');
    const permissionsResponse = await axios.get(`${API_BASE}/api/auth/me`, { headers });
    const permissions = permissionsResponse.data.data.permissions;
    
    console.log('Permessi trovati:', Object.keys(permissions).filter(p => permissions[p] === true).length);
    
    // 3. Test specifici permessi pagine
    console.log('\n3. Test permessi specifici per le pagine...');
    
    const testPermissions = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE', 
      'form_templates:read',
      'form_templates:update',
      'form_submissions:read',
      'form_submissions:update'
    ];
    
    testPermissions.forEach(permission => {
      const hasPermission = permissions[permission] === true;
      console.log(`${hasPermission ? '✅' : '❌'} ${permission}: ${hasPermission}`);
    });
    
    // 4. Test accesso API delle pagine
    console.log('\n4. Test accesso API delle pagine...');
    
    try {
      const cmsResponse = await axios.get(`${API_BASE}/api/v1/cms/public-content`, { headers });
      console.log('✅ API CMS accessibile:', cmsResponse.status === 200);
    } catch (error) {
      console.log('❌ API CMS non accessibile:', error.response?.status || error.message);
    }
    
    // 5. Suggerimenti per il debug
    console.log('\n🔍 === SUGGERIMENTI DEBUG ===');
    console.log('1. Apri il browser e vai su http://localhost:5173/login');
    console.log('2. Effettua login con admin@example.com / Admin123!');
    console.log('3. Apri Developer Tools (F12) e vai su Console');
    console.log('4. Prova ad accedere a:');
    console.log('   - http://localhost:5173/settings/public-cms');
    console.log('   - http://localhost:5173/forms');
    console.log('   - http://localhost:5173/forms/submissions');
    console.log('5. Controlla i log nella console per vedere i permessi caricati');
    console.log('6. Se vedi "Non hai i permessi", controlla se i permessi sono caricati correttamente');
    
  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
  }
}

testDirectPageAccess();
