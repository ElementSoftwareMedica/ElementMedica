#!/usr/bin/env node

/**
 * Script per testare i contatori dal frontend
 */

import fetch from 'node-fetch';

async function testFrontendCounters() {
  console.log('🧪 Testing Frontend Counters...\n');

  try {
    // 1. Login per ottenere token
    console.log('1️⃣ Effettuo login...');
    const loginResponse = await fetch('http://localhost:4003/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      throw new Error(`Login failed: ${loginResponse.status} ${loginResponse.statusText}`);
    }

    const loginData = await loginResponse.json();
    console.log('✅ Login successful');
    
    const token = loginData.tokens?.access_token || loginData.token;
    if (!token) {
      throw new Error('No token received from login');
    }
    
    console.log('🔑 Token received:', token.substring(0, 20) + '...');

    // 2. Test endpoint /api/counters
    console.log('\n2️⃣ Testing /api/counters...');
    const countersResponse = await fetch('http://localhost:4003/api/counters', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-tenant-id': '1'
      }
    });

    console.log('📊 Counters response status:', countersResponse.status);
    console.log('📊 Counters response headers:', Object.fromEntries(countersResponse.headers.entries()));

    if (countersResponse.ok) {
      const countersData = await countersResponse.json();
      console.log('✅ Counters data:', countersData);
    } else {
      const errorText = await countersResponse.text();
      console.log('❌ Counters error:', errorText);
    }

    // 3. Test endpoint /api/dashboard/companies
    console.log('\n3️⃣ Testing /api/dashboard/companies...');
    const companiesResponse = await fetch('http://localhost:4003/api/dashboard/companies', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-tenant-id': '1'
      }
    });

    console.log('🏢 Companies response status:', companiesResponse.status);
    
    if (companiesResponse.ok) {
      const companiesData = await companiesResponse.json();
      console.log('✅ Companies count:', companiesData.length);
      console.log('📋 Companies sample:', companiesData.slice(0, 2));
    } else {
      const errorText = await companiesResponse.text();
      console.log('❌ Companies error:', errorText);
    }

    // 4. Test endpoint /api/dashboard/employees
    console.log('\n4️⃣ Testing /api/dashboard/employees...');
    const employeesResponse = await fetch('http://localhost:4003/api/dashboard/employees', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-tenant-id': '1'
      }
    });

    console.log('👥 Employees response status:', employeesResponse.status);
    
    if (employeesResponse.ok) {
      const employeesData = await employeesResponse.json();
      console.log('✅ Employees count:', employeesData.length);
      console.log('📋 Employees sample:', employeesData.slice(0, 2));
    } else {
      const errorText = await employeesResponse.text();
      console.log('❌ Employees error:', errorText);
    }

    // 5. Test endpoint /api/companies (fallback)
    console.log('\n5️⃣ Testing /api/companies (fallback)...');
    const companiesFallbackResponse = await fetch('http://localhost:4003/api/companies', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'x-tenant-id': '1'
      }
    });

    console.log('🏢 Companies fallback response status:', companiesFallbackResponse.status);
    
    if (companiesFallbackResponse.ok) {
      const companiesFallbackData = await companiesFallbackResponse.json();
      console.log('✅ Companies fallback count:', companiesFallbackData.length);
    } else {
      const errorText = await companiesFallbackResponse.text();
      console.log('❌ Companies fallback error:', errorText);
    }

  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

testFrontendCounters();