#!/usr/bin/env node

const { execSync } = require('child_process');

async function testPermissionIssue() {
  try {
    console.log('🔍 Testing permission issue...');
    
    // 1. Login
    console.log('\n1️⃣ Logging in...');
    const loginCommand = `curl -s -X POST http://localhost:4001/api/v1/auth/login \\
      -H "Content-Type: application/json" \\
      -d '{"identifier": "admin@example.com", "password": "Admin123!"}'`;
    
    const loginResult = execSync(loginCommand, { encoding: 'utf8' });
    const loginData = JSON.parse(loginResult);
    
    if (!loginData.success) {
      throw new Error(`Login failed: ${loginData.error}`);
    }

    const token = loginData.data.token;
    const userId = loginData.data.user.id;
    console.log('✅ Login successful');

    // 2. Get permissions
    console.log('\n2️⃣ Getting permissions...');
    const permissionsCommand = `curl -s -X GET http://localhost:4001/api/v1/auth/permissions/${userId} \\
      -H "Authorization: Bearer ${token}" \\
      -H "Content-Type: application/json"`;
    
    const permissionsResult = execSync(permissionsCommand, { encoding: 'utf8' });
    const permissionsData = JSON.parse(permissionsResult);
    
    if (!permissionsData.success) {
      throw new Error(`Permissions failed: ${permissionsData.error}`);
    }

    const permissions = permissionsData.data.permissions;
    
    console.log('✅ Permissions retrieved');
    console.log('📊 Total permissions:', Object.keys(permissions).length);

    // 3. Test specific permissions that are failing
    console.log('\n3️⃣ Testing specific permissions...');
    
    const testCases = [
      // CMS permissions
      { resource: 'PUBLIC_CMS', action: 'READ' },
      { resource: 'PUBLIC_CMS', action: 'UPDATE' },
      { resource: 'PUBLIC_CMS', action: 'read' },
      { resource: 'PUBLIC_CMS', action: 'update' },
      
      // Form Templates permissions
      { resource: 'form_templates', action: 'read' },
      { resource: 'form_templates', action: 'update' },
      { resource: 'form_templates', action: 'create' },
      { resource: 'form_templates', action: 'delete' },
      
      // Form Submissions permissions
      { resource: 'form_submissions', action: 'read' },
      { resource: 'form_submissions', action: 'update' },
      { resource: 'form_submissions', action: 'delete' },
      { resource: 'form_submissions', action: 'export' }
    ];

    testCases.forEach(testCase => {
      const permissionKey = `${testCase.resource}:${testCase.action}`;
      const hasPermission = permissions[permissionKey] === true;
      
      console.log(`${hasPermission ? '✅' : '❌'} ${permissionKey}: ${hasPermission}`);
      
      // Also check if permission exists in any format
      const allFormats = Object.keys(permissions).filter(key => 
        key.includes(testCase.resource) && key.includes(testCase.action)
      );
      
      if (allFormats.length > 0) {
        console.log(`   📝 Found related permissions: ${allFormats.join(', ')}`);
      }
    });

    // 4. Show all permissions for debugging
    console.log('\n4️⃣ All permissions (for debugging):');
    Object.keys(permissions)
      .filter(key => permissions[key] === true)
      .sort()
      .forEach(key => {
        console.log(`   - ${key}: ${permissions[key]}`);
      });

    // 5. Test hasBackendPermission logic simulation
    console.log('\n5️⃣ Testing hasBackendPermission logic...');
    
    function simulateHasBackendPermission(frontendPermission, backendPermissions) {
      // Direct match
      if (backendPermissions[frontendPermission] === true) {
        return true;
      }
      
      // CMS permissions
      if (frontendPermission === 'PUBLIC_CMS:READ' || frontendPermission === 'PUBLIC_CMS:read') {
        return backendPermissions['PUBLIC_CMS:READ'] === true || 
               backendPermissions['PUBLIC_CMS:read'] === true ||
               backendPermissions['PUBLIC_CMS:view'] === true;
      }
      
      if (frontendPermission === 'PUBLIC_CMS:UPDATE' || frontendPermission === 'PUBLIC_CMS:update') {
        return backendPermissions['PUBLIC_CMS:UPDATE'] === true || 
               backendPermissions['PUBLIC_CMS:update'] === true ||
               backendPermissions['PUBLIC_CMS:edit'] === true;
      }
      
      // Form Templates permissions
      if (frontendPermission === 'form_templates:read') {
        return backendPermissions['form_templates:read'] === true ||
               backendPermissions['form_templates:view'] === true;
      }
      
      // Form Submissions permissions
      if (frontendPermission === 'form_submissions:read') {
        return backendPermissions['form_submissions:read'] === true ||
               backendPermissions['form_submissions:view'] === true;
      }
      
      return false;
    }

    const criticalPermissions = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE', 
      'form_templates:read',
      'form_submissions:read'
    ];

    criticalPermissions.forEach(perm => {
      const result = simulateHasBackendPermission(perm, permissions);
      console.log(`${result ? '✅' : '❌'} hasBackendPermission('${perm}'): ${result}`);
    });

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    process.exit(1);
  }
}

testPermissionIssue();