const { PrismaClient } = require('@prisma/client');

async function countTenants() {
  const prisma = new PrismaClient();
  
  try {
    const count = await prisma.tenant.count();
    console.log('Total tenants:', count);
    
    if (count > 0) {
      const tenants = await prisma.tenant.findMany({
        select: {
          id: true,
          name: true,
          slug: true,
          domain: true,
          isActive: true,
          deletedAt: true
        }
      });
      console.log('Tenants:', JSON.stringify(tenants, null, 2));
    }
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

countTenants();