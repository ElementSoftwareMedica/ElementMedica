// Debug script per testare la rilevazione dei conflitti
// Questo script simula la logica di detectConflicts per verificare se funziona correttamente

const testPersons = [
  {
    firstName: "Mario",
    lastName: "Rossi",
    taxCode: "RSSMRA80A01H501Z",
    companyName: "Azienda Test",
    companyId: undefined // Simula azienda non trovata
  },
  {
    firstName: "Luigi",
    lastName: "Verdi",
    taxCode: "VRDLGU85B02H501Y",
    companyName: "Azienda Esistente",
    companyId: "company-123" // Simula azienda trovata
  }
];

const existingPersons = [
  {
    id: "person-1",
    firstName: "Mario",
    lastName: "Rossi",
    taxCode: "RSSMRA80A01H501Z", // Stesso codice fiscale del primo
    email: "mario.rossi@example.com"
  }
];

const existingCompanies = [
  {
    id: "company-123",
    ragioneSociale: "Azienda Esistente",
    name: "Azienda Esistente"
  },
  {
    id: "company-456",
    ragioneSociale: "Altra Azienda",
    name: "Altra Azienda"
  }
];

function detectConflicts(persons) {
  console.log('🔍 DETECT CONFLICTS DEBUG:');
  console.log('📊 Input persons:', persons.length);
  console.log('📊 Existing persons:', existingPersons.length);
  console.log('📊 Existing companies:', existingCompanies.length);
  
  const detectedConflicts = [];
  
  persons.forEach((person, index) => {
    console.log(`\n👤 Processing person ${index + 1}:`, {
      firstName: person.firstName,
      lastName: person.lastName,
      taxCode: person.taxCode,
      companyName: person.companyName,
      companyId: person.companyId
    });
    
    // Controlla duplicati di codice fiscale
    if (person.taxCode) {
      const existingPerson = existingPersons.find(ep => 
        ep.taxCode && ep.taxCode.toLowerCase().trim() === person.taxCode.toLowerCase().trim()
      );
      
      if (existingPerson) {
        console.log(`🔄 DUPLICATE FOUND: ${person.taxCode} matches existing person ID ${existingPerson.id}`);
        detectedConflicts.push({
          person,
          index,
          type: 'duplicate',
          existingPerson
        });
      } else {
        console.log(`✅ No duplicate found for tax code: ${person.taxCode}`);
      }
    }
    
    // Controlla aziende non valide
    if (person.companyName && !person.companyId) {
      console.log(`🏢 COMPANY CHECK: "${person.companyName}" has no companyId`);
      console.log('🔍 Available companies:', existingCompanies.map(c => ({
        id: c.id,
        ragioneSociale: c.ragioneSociale,
        name: c.name
      })));
      
      // Trova aziende simili
      const suggestedCompanies = existingCompanies.filter(c => {
        const companyName = c.ragioneSociale || c.name || '';
        const isMatch = companyName.toLowerCase().includes(person.companyName.toLowerCase()) ||
               person.companyName.toLowerCase().includes(companyName.toLowerCase());
        
        if (isMatch) {
          console.log(`🎯 SUGGESTED MATCH: "${companyName}" for "${person.companyName}"`);
        }
        
        return isMatch;
      });
      
      console.log(`❌ INVALID COMPANY CONFLICT: "${person.companyName}" with ${suggestedCompanies.length} suggestions`);
      detectedConflicts.push({
        person,
        index,
        type: 'invalid_company',
        suggestedCompanies
      });
    } else if (person.companyName && person.companyId) {
      console.log(`✅ Company OK: "${person.companyName}" has ID ${person.companyId}`);
    } else {
      console.log(`ℹ️ No company specified for person`);
    }
  });
  
  console.log(`\n🎯 CONFLICTS SUMMARY:`);
  console.log(`📊 Total conflicts detected: ${detectedConflicts.length}`);
  detectedConflicts.forEach((conflict, idx) => {
    console.log(`  ${idx + 1}. Type: ${conflict.type}, Person: ${conflict.person.firstName} ${conflict.person.lastName}`);
  });
  
  return detectedConflicts;
}

// Esegui il test
console.log('🧪 TESTING CONFLICT DETECTION...\n');
const conflicts = detectConflicts(testPersons);

console.log('\n📋 FINAL RESULT:');
console.log('Conflicts detected:', conflicts.length);
console.log('Should modal open?', conflicts.length > 0 ? 'YES' : 'NO');

if (conflicts.length > 0) {
  console.log('\n🔍 CONFLICT DETAILS:');
  conflicts.forEach((conflict, idx) => {
    console.log(`${idx + 1}. ${conflict.type.toUpperCase()}:`);
    console.log(`   Person: ${conflict.person.firstName} ${conflict.person.lastName}`);
    if (conflict.type === 'duplicate') {
      console.log(`   Existing: ${conflict.existingPerson.firstName} ${conflict.existingPerson.lastName} (ID: ${conflict.existingPerson.id})`);
    } else if (conflict.type === 'invalid_company') {
      console.log(`   Company: "${conflict.person.companyName}"`);
      console.log(`   Suggestions: ${conflict.suggestedCompanies.length}`);
    }
  });
}