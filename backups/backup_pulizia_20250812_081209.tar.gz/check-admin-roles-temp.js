import prisma from './backend/config/prisma-optimization.js';

async function checkAdminRoles() {
  try {
    console.log('🔍 Verifica ruoli utente admin...');
    
    const admin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: {
          where: { isActive: true },
          include: {
            company: true,
            tenant: true
          }
        }
      }
    });
    
    if (!admin) {
      console.log('❌ Utente admin non trovato');
      return;
    }
    
    console.log('✅ Utente admin trovato:', admin.email);
    console.log('🔑 Ruoli attivi:', admin.personRoles.length);
    
    admin.personRoles.forEach((role, index) => {
      console.log(`--- Ruolo ${index + 1} ---`);
      console.log('Tipo:', role.roleType);
      console.log('Attivo:', role.isActive);
      console.log('Company ID:', role.companyId);
      console.log('Tenant ID:', role.tenantId);
    });
    
    const roleTypes = admin.personRoles.map(r => r.roleType);
    console.log('📋 Tipi di ruolo:', roleTypes);
    
  } catch (error) {
    console.error('❌ Errore:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

checkAdminRoles();