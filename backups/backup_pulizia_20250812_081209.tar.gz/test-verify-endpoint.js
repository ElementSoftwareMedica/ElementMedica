const axios = require('axios');

async function testVerifyEndpoint() {
  try {
    console.log('🔍 Testing /verify endpoint...\n');
    
    // 1. Login to get token
    console.log('1. Login...');
    const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    if (!loginResponse.data.tokens?.access_token) {
      console.error('❌ Login failed - no access token');
      return;
    }
    
    const token = loginResponse.data.tokens.access_token;
    console.log('✅ Login successful');
    console.log('👤 User:', {
      email: loginResponse.data.user?.email,
      role: loginResponse.data.user?.role,
      roles: loginResponse.data.user?.roles
    });
    
    // 2. Test verify endpoint
    console.log('\n2. Testing /verify endpoint...');
    const verifyResponse = await axios.get('http://localhost:4003/api/v1/auth/verify', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('✅ Verify successful');
    console.log('📋 Verify response:', {
      valid: verifyResponse.data.valid,
      userRole: verifyResponse.data.user?.role,
      userRoles: verifyResponse.data.user?.roles,
      permissionsCount: Object.keys(verifyResponse.data.permissions || {}).length
    });
    
    // 3. Check specific permissions
    const permissions = verifyResponse.data.permissions || {};
    
    console.log('\n3. Checking specific permissions...');
    
    // CMS permissions
    const cmsPermissions = Object.keys(permissions).filter(p => 
      p.includes('CMS') || p.includes('cms') || p.includes('public_cms')
    );
    console.log('🎯 CMS permissions (' + cmsPermissions.length + '):');
    cmsPermissions.forEach(p => console.log('  ✅ ' + p + ': ' + permissions[p]));
    
    // Form Templates permissions
    const formTemplatePermissions = Object.keys(permissions).filter(p => 
      p.includes('form_template') || p.includes('FORM_TEMPLATE')
    );
    console.log('\n📝 Form Templates permissions (' + formTemplatePermissions.length + '):');
    formTemplatePermissions.forEach(p => console.log('  ✅ ' + p + ': ' + permissions[p]));
    
    // Form Submissions permissions
    const formSubmissionPermissions = Object.keys(permissions).filter(p => 
      p.includes('form_submission') || p.includes('FORM_SUBMISSION') || p.includes('submission')
    );
    console.log('\n📊 Form Submissions permissions (' + formSubmissionPermissions.length + '):');
    formSubmissionPermissions.forEach(p => console.log('  ✅ ' + p + ': ' + permissions[p]));
    
    // Test specific permission checks
    console.log('\n4. Testing specific permission checks...');
    const permissionsToTest = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE',
      'form_templates:read',
      'form_templates:update',
      'form_submissions:read',
      'form_submissions:update'
    ];
    
    permissionsToTest.forEach(permission => {
      const hasPermission = permissions[permission] === true;
      console.log(`  ${hasPermission ? '✅' : '❌'} ${permission}: ${hasPermission}`);
    });
    
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

testVerifyEndpoint();