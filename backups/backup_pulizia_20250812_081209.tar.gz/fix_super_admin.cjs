const { execSync } = require('child_process');
const path = require('path');

console.log('🔧 Fixing SUPER_ADMIN role for admin user...');

try {
  // Change to backend directory
  process.chdir(path.join(__dirname, 'backend'));
  
  // Load environment variables
  require('dotenv').config();
  
  console.log('📡 Database URL configured:', !!process.env.DATABASE_URL);
  
  // SQL commands to fix admin role
  const sqlCommands = `
    -- Update admin user to have SUPER_ADMIN global role
    UPDATE persons 
    SET "globalRole" = 'SUPER_ADMIN'
    WHERE email = 'admin@example.com';
    
    -- Ensure admin has SUPER_ADMIN role in person_roles
    INSERT INTO person_roles (id, "personId", "roleType", "isActive", "isPrimary", "createdAt", "updatedAt")
    SELECT 
      gen_random_uuid(),
      p.id,
      'SUPER_ADMIN',
      true,
      true,
      NOW(),
      NOW()
    FROM persons p 
    WHERE p.email = 'admin@example.com'
    AND NOT EXISTS (
      SELECT 1 FROM person_roles pr 
      WHERE pr."personId" = p.id 
      AND pr."roleType" = 'SUPER_ADMIN'
    );
    
    -- Verify the changes
    SELECT 
      p.email,
      p."globalRole",
      pr."roleType",
      pr."isActive"
    FROM persons p
    LEFT JOIN person_roles pr ON p.id = pr."personId"
    WHERE p.email = 'admin@example.com';
  `;
  
  // Write SQL to temporary file
  const fs = require('fs');
  const sqlFile = 'fix_admin_temp.sql';
  fs.writeFileSync(sqlFile, sqlCommands);
  
  console.log('📝 Executing SQL commands...');
  
  // Execute SQL using psql
  const result = execSync(`psql "${process.env.DATABASE_URL}" -f ${sqlFile}`, {
    encoding: 'utf8',
    stdio: 'pipe'
  });
  
  console.log('✅ SQL execution result:');
  console.log(result);
  
  // Clean up
  fs.unlinkSync(sqlFile);
  
  console.log('🎉 Admin SUPER_ADMIN role fix completed!');
  
} catch (error) {
  console.error('❌ Error fixing admin role:', error.message);
  if (error.stdout) {
    console.log('STDOUT:', error.stdout);
  }
  if (error.stderr) {
    console.log('STDERR:', error.stderr);
  }
}