import axios from 'axios';

const API_BASE_URL = 'http://localhost:4001';

async function checkUserPermissions() {
  try {
    console.log('🔐 Autenticazione...');
    
    // Login
    const loginResponse = await axios.post(`${API_BASE_URL}/api/v1/auth/login`, {
      identifier: 'admin@example.com',
      password: 'password123'
    });

    console.log('✅ Login riuscito');
    
    // Estrai il token
    const token = loginResponse.data.data.accessToken;
    if (!token) {
      console.error('❌ Token non trovato nella risposta');
      return;
    }

    console.log('🔑 Token estratto correttamente');

    // Verifica i permessi dell'utente
    console.log('\n📋 Verifica permessi utente...');
    
    const permissionsResponse = await axios.get(`${API_BASE_URL}/api/v1/auth/permissions/${loginResponse.data.data.user.id}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('✅ Permessi ottenuti:', JSON.stringify(permissionsResponse.data, null, 2));

    // Test endpoint companies con permessi
    console.log('\n🏢 Test endpoint companies...');
    
    const companiesResponse = await axios.get(`${API_BASE_URL}/api/v1/companies`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log(`✅ Endpoint companies: ${companiesResponse.status} ${companiesResponse.statusText}`);

    // Test endpoint import
    console.log('\n📥 Test endpoint import...');
    
    try {
      const importResponse = await axios.post(`${API_BASE_URL}/api/v1/companies/import`, {
        companies: [
          {
            ragioneSociale: 'Test Company',
            piva: '12345678901',
            citta: 'Milano',
            indirizzo: 'Via Test 123'
          }
        ]
      }, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      console.log(`✅ Endpoint import: ${importResponse.status} ${importResponse.statusText}`);
      console.log('📊 Risultato import:', JSON.stringify(importResponse.data, null, 2));
      
    } catch (importError) {
      console.error(`❌ Endpoint import fallito: ${importError.response?.status} ${importError.response?.statusText}`);
      if (importError.response?.data) {
        console.error('📄 Dettagli errore:', JSON.stringify(importError.response.data, null, 2));
      }
    }

  } catch (error) {
    console.error('❌ Errore:', error.response?.status, error.response?.statusText);
    if (error.response?.data) {
      console.error('📄 Dettagli errore:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

checkUserPermissions();