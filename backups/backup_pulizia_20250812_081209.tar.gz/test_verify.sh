#!/bin/bash

echo "Testing verify endpoint..."

# Extract token from login response
TOKEN=$(curl -s -X POST "http://localhost:4003/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"identifier": "admin@example.com", "password": "Admin123!"}' | \
  jq -r '.tokens.access_token')

echo "Token extracted: ${TOKEN:0:50}..."

# Test verify endpoint
curl -X GET "http://localhost:4003/api/auth/verify" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -w "\n\nHTTP Status: %{http_code}\n"