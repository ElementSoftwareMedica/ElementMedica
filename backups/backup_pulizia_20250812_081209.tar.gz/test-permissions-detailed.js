// Script per testare i permessi nel browser
// Eseguire nella console del browser dopo aver fatto login

console.log('🔍 TEST PERMESSI NEL BROWSER');
console.log('============================');

// Funzione per testare i permessi
function testPermissions() {
  console.log('\n🧪 INIZIO TEST PERMESSI');
  console.log('========================');
  
  // Verifica se authContextForTesting è disponibile
  if (!window.authContextForTesting) {
    console.log('❌ authContextForTesting non trovato');
    console.log('💡 Assicurati di essere loggato e in modalità development');
    return;
  }
  
  const { hasPermission, user, permissions } = window.authContextForTesting;
  
  console.log('✅ AuthContext trovato');
  console.log('👤 Utente:', user?.email, '- Ruolo:', user?.role);
  console.log('📋 Permessi totali:', Object.keys(permissions).length);
  console.log('🔑 Permessi attivi:', Object.keys(permissions).filter(p => permissions[p] === true).length);
  
  // Test permessi specifici delle pagine problematiche
  const tests = [
    // PublicCMSPage
    { desc: 'PublicCMSPage - Lettura', call: () => hasPermission('PUBLIC_CMS', 'READ') },
    { desc: 'PublicCMSPage - Modifica', call: () => hasPermission('PUBLIC_CMS', 'UPDATE') },
    
    // FormTemplatesPage  
    { desc: 'FormTemplatesPage - Lettura', call: () => hasPermission('form_templates', 'read') },
    { desc: 'FormTemplatesPage - Modifica', call: () => hasPermission('form_templates', 'update') },
    { desc: 'FormTemplatesPage - Creazione', call: () => hasPermission('form_templates', 'create') },
    { desc: 'FormTemplatesPage - Eliminazione', call: () => hasPermission('form_templates', 'delete') },
    
    // FormSubmissionsPage
    { desc: 'FormSubmissionsPage - Lettura', call: () => hasPermission('form_submissions', 'read') },
    { desc: 'FormSubmissionsPage - Modifica', call: () => hasPermission('form_submissions', 'update') },
    { desc: 'FormSubmissionsPage - Eliminazione', call: () => hasPermission('form_submissions', 'delete') },
    { desc: 'FormSubmissionsPage - Esportazione', call: () => hasPermission('form_submissions', 'export') },
  ];
  
  console.log('\n🎯 TEST PERMESSI SPECIFICI');
  console.log('===========================');
  
  tests.forEach(test => {
    const result = test.call();
    const status = result ? '✅' : '❌';
    console.log(`${status} ${test.desc}: ${result}`);
  });
  
  // Test permessi backend diretti
  console.log('\n🔧 TEST PERMESSI BACKEND DIRETTI');
  console.log('=================================');
  
  const backendTests = [
    'VIEW_CMS',
    'CREATE_CMS', 
    'EDIT_CMS',
    'DELETE_CMS',
    'MANAGE_PUBLIC_CONTENT',
    'VIEW_FORM_TEMPLATES',
    'CREATE_FORM_TEMPLATES',
    'EDIT_FORM_TEMPLATES',
    'DELETE_FORM_TEMPLATES',
    'VIEW_FORM_SUBMISSIONS',
    'CREATE_FORM_SUBMISSIONS',
    'EDIT_FORM_SUBMISSIONS',
    'DELETE_FORM_SUBMISSIONS',
    'EXPORT_FORM_SUBMISSIONS'
  ];
  
  backendTests.forEach(permission => {
    const result = hasPermission(permission);
    const status = result ? '✅' : '❌';
    console.log(`${status} ${permission}: ${result}`);
  });
  
  // Mostra tutti i permessi attivi
  console.log('\n📋 TUTTI I PERMESSI ATTIVI');
  console.log('==========================');
  const activePermissions = Object.keys(permissions).filter(p => permissions[p] === true);
  activePermissions.forEach(permission => {
    console.log(`✅ ${permission}`);
  });
  
  // Cerca permessi correlati a CMS, FORM, TEMPLATES, SUBMISSIONS
  console.log('\n🔍 PERMESSI CORRELATI');
  console.log('======================');
  const keywords = ['CMS', 'FORM', 'TEMPLATE', 'SUBMISSION'];
  keywords.forEach(keyword => {
    const related = activePermissions.filter(p => p.toUpperCase().includes(keyword));
    console.log(`🏷️ ${keyword}:`, related);
  });
}

// Istruzioni
console.log('\n📋 ISTRUZIONI:');
console.log('==============');
console.log('1. Fai login nell\'app con admin@example.com / Admin123!');
console.log('2. Vai in una pagina dell\'app (es. /dashboard)');
console.log('3. Apri la console del browser (F12)');
console.log('4. Esegui: testPermissions()');

// Esporta la funzione per l'uso nel browser
if (typeof window !== 'undefined') {
  window.testPermissions = testPermissions;
}