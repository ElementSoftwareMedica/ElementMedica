const axios = require('axios');
const fs = require('fs');

const API_BASE = 'http://localhost:4003/api';

async function debugTenants() {
  try {
    // Leggi il token
    const token = fs.readFileSync('temp_token.txt', 'utf8').trim();
    console.log('🔍 Debug Tenants');
    console.log('================');
    console.log('🔑 Token:', token.substring(0, 50) + '...');

    // Test auth
    console.log('\n1. Testing authentication...');
    const authResponse = await axios.get(`${API_BASE}/auth/me`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    console.log('✅ Authentication successful');
    console.log('👤 User:', authResponse.data.email);
    console.log('🏢 User Tenant ID:', authResponse.data.tenantId);
    console.log('🔐 User Roles:', authResponse.data.roles);

    // Test tenants list
    console.log('\n2. Testing /api/tenant endpoint...');
    try {
      const tenantsResponse = await axios.get(`${API_BASE}/tenant`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Tenants endpoint successful');
      console.log('🏢 Tenants count:', tenantsResponse.data.length);
      console.log('🏢 Tenants:', tenantsResponse.data.map(t => ({ id: t.id, name: t.ragioneSociale || t.name, slug: t.slug })));
    } catch (error) {
      console.log('❌ Tenants endpoint failed:', error.response?.data || error.message);
    }

    // Test tenants/current
    console.log('\n3. Testing /api/tenants/current endpoint...');
    try {
      const currentTenantResponse = await axios.get(`${API_BASE}/tenants/current`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Current tenant endpoint successful');
      console.log('🏢 Current tenant:', currentTenantResponse.data);
    } catch (error) {
      console.log('❌ Current tenant endpoint failed:', error.response?.data || error.message);
    }

    // Test companies (che sono i tenant)
    console.log('\n4. Testing /api/companies endpoint...');
    try {
      const companiesResponse = await axios.get(`${API_BASE}/companies`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Companies endpoint successful');
      console.log('🏢 Companies count:', companiesResponse.data.length);
      console.log('🏢 Companies:', companiesResponse.data.map(c => ({ 
        id: c.id, 
        name: c.ragioneSociale || c.name, 
        tenantId: c.tenantId,
        isActive: c.isActive 
      })));
    } catch (error) {
      console.log('❌ Companies endpoint failed:', error.response?.data || error.message);
    }

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

debugTenants();