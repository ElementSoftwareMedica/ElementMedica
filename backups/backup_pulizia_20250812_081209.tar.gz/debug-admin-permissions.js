#!/usr/bin/env node

/**
 * Script di debug per analizzare i permessi dell'admin
 * Verifica lo stato attuale nel database e testa il flusso completo
 */

const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function checkAdminPermissions() {
  try {
    console.log('🔍 Checking admin permissions...');
    
    // Trova l'utente admin
    const admin = await prisma.person.findFirst({
      where: {
        email: 'admin@example.com'
      },
      include: {
        roles: {
          include: {
            role: {
              include: {
                permissions: {
                  include: {
                    permission: true
                  }
                }
              }
            }
          }
        }
      }
    });
    if (!admin) {
      console.log('❌ Admin user not found');
      return;
    }

    console.log('👤 Admin user found:', {
      id: admin.id,
      email: admin.email,
      rolesCount: admin.roles.length
    });

    // Estrai tutti i permessi
    const allPermissions = [];
    admin.roles.forEach(userRole => {
      const role = userRole.role;
      console.log(`📋 Role: ${role.name} (${role.type})`);
      
      role.permissions.forEach(rolePermission => {
        const permission = rolePermission.permission;
        allPermissions.push(permission.name);
        console.log(`  ✅ ${permission.name} - ${permission.description}`);
      });
    });

    console.log('\n🔐 All permissions summary:');
    console.log('Total permissions:', allPermissions.length);
    
    // Filtra permessi relativi a FORM e CMS
    const formPermissions = allPermissions.filter(p => 
      p.includes('FORM') || p.includes('TEMPLATE') || p.includes('SUBMISSION')
    );
    const cmsPermissions = allPermissions.filter(p => 
      p.includes('CMS') || p.includes('PUBLIC_CMS')
    );

    console.log('\n📝 Form-related permissions:');
    formPermissions.forEach(p => console.log(`  - ${p}`));
    
    console.log('\n🎨 CMS-related permissions:');
    cmsPermissions.forEach(p => console.log(`  - ${p}`));

    // Verifica permessi specifici richiesti
    const requiredPermissions = [
      'VIEW_FORM_TEMPLATES',
      'CREATE_FORM_TEMPLATES',
      'EDIT_FORM_TEMPLATES',
      'DELETE_FORM_TEMPLATES',
      'MANAGE_FORM_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS',
      'CREATE_FORM_SUBMISSIONS',
      'EDIT_FORM_SUBMISSIONS',
      'DELETE_FORM_SUBMISSIONS',
      'MANAGE_FORM_SUBMISSIONS',
      'VIEW_PUBLIC_CMS',
      'CREATE_PUBLIC_CMS',
      'EDIT_PUBLIC_CMS',
      'DELETE_PUBLIC_CMS',
      'MANAGE_PUBLIC_CMS'
    ];

    console.log('\n✅ Required permissions check:');
    requiredPermissions.forEach(required => {
      const hasPermission = allPermissions.includes(required);
      console.log(`  ${hasPermission ? '✅' : '❌'} ${required}`);
    });

  } catch (error) {
    console.error('❌ Error checking permissions:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkAdminPermissions();