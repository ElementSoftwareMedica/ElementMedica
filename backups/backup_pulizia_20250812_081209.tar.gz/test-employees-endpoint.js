/**
 * Script per testare l'endpoint /api/employees
 */

import fetch from 'node-fetch';

async function testEmployeesEndpoint() {
    try {
        console.log('🧪 Testing /api/employees endpoint...');
        
        // Test dell'endpoint employees
        const response = await fetch('http://localhost:4001/api/employees', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer test-token' // Se necessario
            }
        });
        
        console.log('📊 Response status:', response.status);
        console.log('📊 Response headers:', Object.fromEntries(response.headers.entries()));
        
        if (response.ok) {
            const data = await response.json();
            console.log('✅ Employees data received:');
            console.log('📈 Total employees:', Array.isArray(data) ? data.length : 'Not an array');
            
            if (Array.isArray(data) && data.length > 0) {
                console.log('👤 First employee sample:', {
                    id: data[0].id,
                    name: `${data[0].firstName} ${data[0].lastName}`,
                    email: data[0].email,
                    roles: data[0].personRoles?.map(r => r.roleType) || 'No roles'
                });
            } else {
                console.log('⚠️ No employees found or invalid data format');
                console.log('📄 Raw response:', data);
            }
        } else {
            const errorText = await response.text();
            console.error('❌ Error response:', errorText);
        }
        
        // Test dell'endpoint companies
        console.log('\n🧪 Testing /api/companies endpoint...');
        const companiesResponse = await fetch('http://localhost:4001/api/companies', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        console.log('📊 Companies response status:', companiesResponse.status);
        
        if (companiesResponse.ok) {
            const companiesData = await companiesResponse.json();
            console.log('✅ Companies data received:');
            console.log('📈 Total companies:', Array.isArray(companiesData) ? companiesData.length : 'Not an array');
            
            if (Array.isArray(companiesData) && companiesData.length > 0) {
                console.log('🏢 First company sample:', {
                    id: companiesData[0].id,
                    name: companiesData[0].name || companiesData[0].ragioneSociale,
                    status: companiesData[0].status
                });
            }
        } else {
            const errorText = await companiesResponse.text();
            console.error('❌ Companies error response:', errorText);
        }
        
    } catch (error) {
        console.error('❌ Network error:', error.message);
    }
}

testEmployeesEndpoint();