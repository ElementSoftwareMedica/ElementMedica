// Script per debuggare i contatori nel frontend
import axios from 'axios';

async function debugFrontendCounters() {
  console.log('🔍 Debug Frontend Counters...\n');
  
  try {
    // Leggi il token di autenticazione
    const fs = await import('fs');
    const token = fs.readFileSync('./temp_token.txt', 'utf8').trim();
    console.log('🔑 Using auth token:', token.substring(0, 50) + '...');
    
    // Test diretto dell'endpoint che usa il frontend
    console.log('1️⃣ Testing /api/counters endpoint directly...');
    const response = await axios.get('http://localhost:4003/api/counters', {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('✅ Status:', response.status);
    console.log('✅ Headers:', response.headers);
    console.log('✅ Data:', response.data);
    
    // Verifica che i dati siano nel formato corretto
    if (response.data && typeof response.data.companies === 'number' && typeof response.data.employees === 'number') {
      console.log('\n✅ Data format is correct!');
      console.log(`Companies: ${response.data.companies}`);
      console.log(`Employees: ${response.data.employees}`);
    } else {
      console.log('\n❌ Data format is incorrect!');
      console.log('Expected: { companies: number, employees: number }');
      console.log('Received:', response.data);
    }
    
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
  }
}

debugFrontendCounters();