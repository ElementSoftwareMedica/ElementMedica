const axios = require('axios');

async function testPermissionsSimple() {
  try {
    console.log('🔐 Testing permissions with simple approach...\n');
    
    // 1. Login
    console.log('1️⃣ Login...');
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    if (!loginResponse.data.success) {
      console.log('❌ Login failed');
      return;
    }
    
    const token = loginResponse.data.tokens.access_token;
    const user = loginResponse.data.user;
    console.log('✅ Login successful - User ID:', user.id);
    
    // 2. Test endpoint semplice
    console.log('\n2️⃣ Testing simple permissions endpoint...');
    try {
      const testResponse = await axios.get('http://localhost:4001/api/v1/auth/test-permissions', {
        timeout: 5000
      });
      console.log('✅ Test endpoint works:', testResponse.data.success);
    } catch (error) {
      console.log('❌ Test endpoint failed:', error.message);
    }
    
    // 3. Test con timeout breve
    console.log('\n3️⃣ Testing permissions with short timeout...');
    try {
      const permissionsResponse = await axios.get(`http://localhost:4001/api/v1/auth/permissions/${user.id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        timeout: 3000 // 3 secondi di timeout
      });
      
      console.log('✅ Permissions retrieved successfully');
      const permissions = permissionsResponse.data.data.permissions;
      
      // Test permessi critici
      const criticalPermissions = [
        'form_templates:read',
        'form_submissions:read', 
        'PUBLIC_CMS:READ',
        'PUBLIC_CMS:read'
      ];
      
      console.log('\n🎯 Critical permissions check:');
      criticalPermissions.forEach(perm => {
        const hasPermission = permissions[perm] === true;
        console.log(`  ${hasPermission ? '✅' : '❌'} ${perm}`);
      });
      
    } catch (error) {
      if (error.code === 'ECONNABORTED') {
        console.log('❌ Permissions request timed out - endpoint has performance issues');
      } else {
        console.log('❌ Permissions request failed:', error.message);
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

testPermissionsSimple();