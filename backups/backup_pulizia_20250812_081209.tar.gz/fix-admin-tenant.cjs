const { PrismaClient } = require('./backend/node_modules/@prisma/client');

const prisma = new PrismaClient();

async function fixAdminTenant() {
  try {
    console.log('🔧 Fixing admin tenant association...');
    console.log('=====================================');

    // 1. Trova l'utente admin
    const admin = await prisma.person.findFirst({
      where: {
        email: 'admin@example.com'
      }
    });

    if (!admin) {
      console.log('❌ Admin user not found');
      return;
    }

    console.log('✅ Admin user found:', {
      id: admin.id,
      email: admin.email,
      currentTenantId: admin.tenantId
    });

    // 2. Trova il tenant esistente (quello usato dalle aziende)
    const existingTenant = await prisma.company.findFirst({
      where: {
        tenantId: { 
          not: null 
        }
      },
      select: {
        tenantId: true
      }
    });

    if (!existingTenant) {
      console.log('❌ No tenant found in companies');
      return;
    }

    const tenantId = existingTenant.tenantId;
    console.log('✅ Found tenant ID:', tenantId);

    // 3. Verifica se il tenant esiste nella tabella tenants
    let tenant = await prisma.tenant.findUnique({
      where: { id: tenantId }
    });

    if (!tenant) {
      console.log('⚠️ Tenant not found in tenants table, creating it...');
      
      // Crea il tenant se non esiste
      tenant = await prisma.tenant.create({
        data: {
          id: tenantId,
          name: 'Default Tenant',
          slug: 'default',
          domain: 'localhost',
          settings: {},
          subscriptionPlan: 'enterprise',
          isActive: true,
          maxUsers: 1000,
          maxCompanies: 100
        }
      });
      console.log('✅ Tenant created:', tenant.name);
    } else {
      console.log('✅ Tenant exists:', tenant.name);
    }

    // 4. Aggiorna l'utente admin con il tenant
    if (admin.tenantId !== tenantId) {
      const updatedAdmin = await prisma.person.update({
        where: { id: admin.id },
        data: { tenantId: tenantId }
      });
      console.log('✅ Admin user updated with tenant ID:', updatedAdmin.tenantId);
    } else {
      console.log('✅ Admin user already has correct tenant ID');
    }

    // 5. Verifica il risultato
    const finalAdmin = await prisma.person.findUnique({
      where: { id: admin.id },
      select: {
        id: true,
        email: true,
        tenantId: true,
        roles: true
      }
    });

    console.log('✅ Final admin state:', finalAdmin);

    console.log('\n🎉 Admin tenant association fixed successfully!');

  } catch (error) {
    console.error('❌ Error fixing admin tenant:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixAdminTenant();