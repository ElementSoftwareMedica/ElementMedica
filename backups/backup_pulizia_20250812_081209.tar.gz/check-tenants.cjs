const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function checkTenants() {
  try {
    const tenants = await prisma.tenant.findMany({
      select: {
        id: true,
        name: true,
        slug: true,
        domain: true,
        isActive: true,
        deletedAt: true,
        createdAt: true
      }
    });
    
    console.log('Tenants found:', tenants.length);
    console.log('Tenants:', JSON.stringify(tenants, null, 2));
    
    const activeTenants = tenants.filter(t => t.isActive && !t.deletedAt);
    console.log('Active tenants:', activeTenants.length);
    
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

checkTenants();