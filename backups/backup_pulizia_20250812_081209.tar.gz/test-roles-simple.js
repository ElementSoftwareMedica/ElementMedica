const fetch = require('node-fetch');

const BASE_URL = 'http://localhost:3001';

async function testRolesEndpoint() {
  try {
    console.log('🧪 Test endpoint ruoli...');

    // 1. Login admin
    console.log('\n1️⃣ Login admin...');
    const loginResponse = await fetch(`${BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      console.log(`❌ Login fallito: ${loginResponse.status}`);
      const errorText = await loginResponse.text();
      console.log('Errore:', errorText);
      return;
    }

    const loginData = await loginResponse.json();
    console.log('✅ Login riuscito');
    console.log(`🔑 Token: ${loginData.token ? 'presente' : 'mancante'}`);
    
    if (loginData.user?.permissions) {
      console.log(`📋 Permessi: ${loginData.user.permissions.length}`);
      const hasRoleManagement = loginData.user.permissions.includes('ROLE_MANAGEMENT');
      console.log(`🎯 ROLE_MANAGEMENT: ${hasRoleManagement ? '✅' : '❌'}`);
    }

    // 2. Test endpoint ruoli
    console.log('\n2️⃣ Test endpoint /api/roles...');
    const rolesResponse = await fetch(`${BASE_URL}/api/roles`, {
      headers: {
        'Authorization': `Bearer ${loginData.token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log(`📊 Status: ${rolesResponse.status}`);
    
    if (rolesResponse.ok) {
      const rolesData = await rolesResponse.json();
      console.log('✅ Endpoint ruoli funziona!');
      console.log(`📋 Ruoli trovati: ${rolesData.data?.length || 0}`);
      if (rolesData.data?.length > 0) {
        console.log('🔍 Primi ruoli:', rolesData.data.slice(0, 3).map(r => r.name || r.type));
      }
    } else {
      const errorText = await rolesResponse.text();
      console.log('❌ Errore endpoint ruoli:', errorText);
    }

  } catch (error) {
    console.error('❌ Errore test:', error.message);
  }
}

testRolesEndpoint();