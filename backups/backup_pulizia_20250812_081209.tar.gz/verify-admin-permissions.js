const { PrismaClient } = require('@prisma/client');
const { getDefaultPermissions, ROLE_TYPES } = require('./backend/services/enhancedRole/utils/RoleTypes.js');

const prisma = new PrismaClient();

async function verifyAndFixAdminPermissions() {
  try {
    console.log('🔍 Verifica permessi admin...');
    
    // 1. Trova l'utente admin
    const adminUser = await prisma.person.findUnique({
      where: { email: 'admin@example.com' },
      include: {
        roles: {
          include: {
            role: {
              include: {
                permissions: true
              }
            }
          }
        },
        customRoles: {
          include: {
            permissions: true
          }
        }
      }
    });

    if (!adminUser) {
      console.error('❌ Utente admin non trovato!');
      return;
    }

    console.log(`✅ Utente admin trovato: ${adminUser.email}`);
    console.log(`📋 Ruoli attuali:`, adminUser.roles.map(r => r.role.name));

    // 2. Verifica se esiste il ruolo ADMIN
    let adminRole = await prisma.customRole.findFirst({
      where: { name: 'ADMIN' },
      include: { permissions: true }
    });

    if (!adminRole) {
      console.log('🔧 Creazione ruolo ADMIN...');
      adminRole = await prisma.customRole.create({
        data: {
          name: 'ADMIN',
          description: 'Amministratore di sistema',
          type: 'ADMIN',
          isActive: true
        },
        include: { permissions: true }
      });
      console.log('✅ Ruolo ADMIN creato');
    }

    // 3. Ottieni i permessi di default per ADMIN
    const defaultPermissions = getDefaultPermissions(ROLE_TYPES.ADMIN);
    console.log(`📋 Permessi di default per ADMIN (${defaultPermissions.length}):`, defaultPermissions);

    // 4. Verifica permessi esistenti del ruolo ADMIN
    const existingPermissions = adminRole.permissions.map(p => p.permission);
    console.log(`📋 Permessi esistenti del ruolo ADMIN (${existingPermissions.length}):`, existingPermissions);

    // 5. Trova permessi mancanti
    const missingPermissions = defaultPermissions.filter(p => !existingPermissions.includes(p));
    console.log(`🔍 Permessi mancanti (${missingPermissions.length}):`, missingPermissions);

    // 6. Aggiungi permessi mancanti
    if (missingPermissions.length > 0) {
      console.log('🔧 Aggiunta permessi mancanti...');
      
      for (const permission of missingPermissions) {
        await prisma.customRolePermission.create({
          data: {
            roleId: adminRole.id,
            permission: permission
          }
        });
        console.log(`  ✅ Aggiunto: ${permission}`);
      }
    }

    // 7. Verifica se l'admin ha il ruolo ADMIN assegnato
    const hasAdminRole = adminUser.customRoles.some(r => r.name === 'ADMIN');
    
    if (!hasAdminRole) {
      console.log('🔧 Assegnazione ruolo ADMIN all\'utente...');
      await prisma.enhancedUserRole.create({
        data: {
          userId: adminUser.id,
          roleId: adminRole.id,
          assignedBy: adminUser.id,
          isActive: true
        }
      });
      console.log('✅ Ruolo ADMIN assegnato');
    }

    // 8. Verifica finale
    console.log('\n🔍 Verifica finale...');
    
    const updatedAdminUser = await prisma.person.findUnique({
      where: { email: 'admin@example.com' },
      include: {
        customRoles: {
          include: {
            permissions: true
          }
        }
      }
    });

    const allUserPermissions = [];
    updatedAdminUser.customRoles.forEach(role => {
      role.permissions.forEach(perm => {
        if (!allUserPermissions.includes(perm.permission)) {
          allUserPermissions.push(perm.permission);
        }
      });
    });

    console.log(`✅ Permessi totali dell'admin (${allUserPermissions.length}):`, allUserPermissions.sort());

    // 9. Verifica permessi critici
    const criticalPermissions = [
      'ROLE_MANAGEMENT',
      'VIEW_ROLES',
      'CREATE_ROLES',
      'EDIT_ROLES',
      'DELETE_ROLES',
      'ADMIN_PANEL',
      'USER_MANAGEMENT',
      'MANAGE_USERS',
      'ASSIGN_ROLES',
      'REVOKE_ROLES',
      'HIERARCHY_MANAGEMENT',
      'MANAGE_HIERARCHY'
    ];

    console.log('\n🔍 Verifica permessi critici:');
    criticalPermissions.forEach(perm => {
      const hasPermission = allUserPermissions.includes(perm);
      console.log(`  ${hasPermission ? '✅' : '❌'} ${perm}`);
    });

    console.log('\n✅ Verifica completata!');

  } catch (error) {
    console.error('❌ Errore durante la verifica:', error);
  } finally {
    await prisma.$disconnect();
  }
}

verifyAndFixAdminPermissions();