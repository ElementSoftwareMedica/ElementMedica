const axios = require('axios');

const API_BASE_URL = 'http://localhost:4001';

async function testSubmissionsAdvanced() {
  try {
    console.log('🔍 Testing submissions/advanced endpoint...');
    
    // 1. Login per ottenere il token
    console.log('📝 Logging in...');
    const loginResponse = await axios.post(`${API_BASE_URL}/api/v1/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    console.log('📄 Login response:', JSON.stringify(loginResponse.data, null, 2));
    
    const { tokens, user } = loginResponse.data;
    const accessToken = tokens.access_token;
    const tenantId = user.tenantId;
    
    console.log('✅ Login successful');
    console.log('👤 User:', user.email);
    console.log('🏢 Tenant ID:', tenantId);
    console.log('🔑 Token:', accessToken.substring(0, 20) + '...');
    
    // 2. Test endpoint /api/v1/submissions/advanced
    console.log('\n🔍 Testing /api/v1/submissions/advanced...');
    
    try {
      const advancedResponse = await axios.get(`${API_BASE_URL}/api/v1/submissions/advanced`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-tenant-id': tenantId,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('✅ Advanced submissions endpoint successful');
      console.log('📊 Status:', advancedResponse.status);
      console.log('📄 Data:', JSON.stringify(advancedResponse.data, null, 2));
      
    } catch (advancedError) {
      console.log('❌ Advanced submissions endpoint failed');
      console.log('📊 Status:', advancedError.response?.status);
      console.log('📄 Error:', JSON.stringify(advancedError.response?.data, null, 2));
    }
    
    // 3. Test endpoint /api/v1/submissions (per confronto)
    console.log('\n🔍 Testing /api/v1/submissions...');
    
    try {
      const submissionsResponse = await axios.get(`${API_BASE_URL}/api/v1/submissions`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-tenant-id': tenantId,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('✅ Submissions endpoint successful');
      console.log('📊 Status:', submissionsResponse.status);
      console.log('📄 Data:', JSON.stringify(submissionsResponse.data, null, 2));
      
    } catch (submissionsError) {
      console.log('❌ Submissions endpoint failed');
      console.log('📊 Status:', submissionsError.response?.status);
      console.log('📄 Error:', JSON.stringify(submissionsError.response?.data, null, 2));
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('📊 Status:', error.response.status);
      console.error('📄 Data:', error.response.data);
    }
  }
}

testSubmissionsAdvanced();