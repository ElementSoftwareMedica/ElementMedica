const puppeteer = require('puppeteer');

async function testRoleModal() {
  console.log('🔍 Test modal ruoli nel frontend...');
  
  const browser = await puppeteer.launch({ 
    headless: false,
    defaultViewport: null,
    args: ['--start-maximized']
  });
  
  try {
    const page = await browser.newPage();
    
    // 1. Vai alla pagina di login
    console.log('📝 Navigazione alla pagina di login...');
    await page.goto('http://localhost:5173/login');
    await page.waitForSelector('input[type="email"]', { timeout: 10000 });
    
    // 2. Effettua login
    console.log('🔑 Effettuo login...');
    await page.type('input[type="email"]', 'admin@example.com');
    await page.type('input[type="password"]', 'Admin123!');
    await page.click('button[type="submit"]');
    
    // 3. Attendi il redirect alla dashboard
    console.log('⏳ Attendo redirect alla dashboard...');
    await page.waitForNavigation({ timeout: 10000 });
    
    // 4. Naviga a Settings > Roles
    console.log('🔧 Navigazione a Settings > Roles...');
    await page.goto('http://localhost:5173/settings/roles');
    await page.waitForSelector('[data-testid="create-role-button"], button:contains("Crea Ruolo"), button:contains("Nuovo Ruolo")', { timeout: 10000 });
    
    // 5. Clicca sul pulsante per creare un nuovo ruolo
    console.log('➕ Apertura modal creazione ruolo...');
    const createButton = await page.$('[data-testid="create-role-button"]') || 
                         await page.$('button:contains("Crea Ruolo")') ||
                         await page.$('button:contains("Nuovo Ruolo")') ||
                         await page.$('button[class*="primary"]');
    
    if (createButton) {
      await createButton.click();
    } else {
      // Fallback: cerca qualsiasi pulsante che potrebbe aprire il modal
      const buttons = await page.$$('button');
      for (const button of buttons) {
        const text = await page.evaluate(el => el.textContent, button);
        if (text && (text.includes('Crea') || text.includes('Nuovo') || text.includes('Aggiungi'))) {
          await button.click();
          break;
        }
      }
    }
    
    // 6. Attendi che il modal si apra
    console.log('⏳ Attendo apertura modal...');
    await page.waitForSelector('[role="dialog"], .modal, [data-testid="role-modal"]', { timeout: 5000 });
    
    // 7. Cerca le entità nel modal
    console.log('🔍 Ricerca entità nel modal...');
    
    // Attendi che i permessi si carichino
    await page.waitForTimeout(2000);
    
    // Cerca le entità specifiche
    const entities = ['form_templates', 'form_submissions', 'public_cms', 'Template Form', 'Risposte Form', 'CMS Pubblico'];
    const foundEntities = [];
    
    for (const entity of entities) {
      const elements = await page.$x(`//*[contains(text(), "${entity}")]`);
      if (elements.length > 0) {
        foundEntities.push(entity);
        console.log(`✅ Trovata entità: ${entity}`);
      } else {
        console.log(`❌ NON trovata entità: ${entity}`);
      }
    }
    
    // 8. Prendi screenshot del modal
    console.log('📸 Screenshot del modal...');
    await page.screenshot({ path: 'role-modal-screenshot.png', fullPage: true });
    
    // 9. Estrai il contenuto del modal per analisi
    const modalContent = await page.evaluate(() => {
      const modal = document.querySelector('[role="dialog"], .modal, [data-testid="role-modal"]');
      return modal ? modal.textContent : 'Modal non trovato';
    });
    
    console.log('\n📋 Risultati test:');
    console.log(`Entità trovate: ${foundEntities.length}/${entities.length}`);
    console.log('Entità trovate:', foundEntities);
    
    if (modalContent.length < 100) {
      console.log('⚠️ Contenuto modal molto breve, possibile problema di caricamento');
    }
    
    console.log('\n✅ Test completato! Screenshot salvato come role-modal-screenshot.png');
    
  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
  } finally {
    await browser.close();
  }
}

testRoleModal().catch(console.error);
