#!/usr/bin/env node

/**
 * Test per verificare il comportamento del frontend nella gestione dei permessi
 * Simula le chiamate che fa il frontend per caricare e salvare i permessi
 */

import fetch from 'node-fetch';
import fs from 'fs';

const PROXY_BASE = 'http://localhost:4003';

// Funzione per effettuare il login e ottenere il token
async function login() {
  console.log('🔐 Effettuando login...');
  
  const loginResponse = await fetch(`${PROXY_BASE}/api/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      identifier: 'admin@example.com',
      password: 'Admin123!'
    })
  });

  if (!loginResponse.ok) {
    throw new Error(`Login fallito: ${loginResponse.status}`);
  }

  const loginData = await loginResponse.json();
  console.log('✅ Login effettuato con successo');
  
  return loginData.tokens.access_token;
}

async function testFrontendPermissions() {
  console.log('\n🧪 Test comportamento frontend per i permessi\n');

  try {
    // 1. Effettua login
    const token = await login();

    // 2. Simula il caricamento dei permessi disponibili (come fa RoleModal)
    console.log('\n1️⃣ Caricamento permessi disponibili...');
    const permissionsResponse = await fetch(`${PROXY_BASE}/api/roles/permissions`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!permissionsResponse.ok) {
      throw new Error(`Errore nel caricamento permessi: ${permissionsResponse.status}`);
    }

    const permissionsData = await permissionsResponse.json();
    console.log('✅ Permessi disponibili caricati:', {
      success: permissionsData.success,
      categoriesCount: Object.keys(permissionsData.data?.permissions || {}).length
    });

    // 3. Simula il caricamento delle entità (come fa RoleModal)
    console.log('\n2️⃣ Caricamento entità disponibili...');
    const entitiesResponse = await fetch(`${PROXY_BASE}/api/advanced-permissions/entities`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    let entitiesData;
    if (entitiesResponse.ok) {
      entitiesData = await entitiesResponse.json();
      console.log('✅ Entità caricate dal backend:', {
        success: entitiesData.success,
        entitiesCount: entitiesData.entities?.length || 0
      });
    } else {
      console.log('⚠️ Endpoint entità non disponibile, il frontend userà definizioni statiche');
      entitiesData = { success: false, entities: [] };
    }

    // 4. Simula il caricamento dei permessi di un ruolo specifico (ADMIN)
    console.log('\n3️⃣ Caricamento permessi del ruolo ADMIN...');
    const rolePermissionsResponse = await fetch(`${PROXY_BASE}/api/roles/ADMIN/permissions`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!rolePermissionsResponse.ok) {
      throw new Error(`Errore nel caricamento permessi ruolo: ${rolePermissionsResponse.status}`);
    }

    const rolePermissionsData = await rolePermissionsResponse.json();
    console.log('✅ Permessi del ruolo ADMIN caricati:', {
      success: rolePermissionsData.success,
      permissionsCount: rolePermissionsData.data?.permissions?.length || 0
    });

    // Converte i permessi nel formato che usa il frontend (Record<string, boolean>)
    const permissionsMap = {};
    if (rolePermissionsData.data?.permissions) {
      rolePermissionsData.data.permissions.forEach(permission => {
        if (permission.granted) {
          permissionsMap[permission.permissionId] = true;
        }
      });
    }

    console.log('Permessi convertiti per il frontend:', Object.keys(permissionsMap));

    // 5. Simula l'aggiunta di nuovi permessi per le entità
    console.log('\n4️⃣ Simulazione aggiunta permessi per nuove entità...');
    
    // Aggiungi permessi per form_templates
    permissionsMap['CREATE_FORM_TEMPLATES'] = true;
    permissionsMap['VIEW_FORM_TEMPLATES'] = true;
    permissionsMap['EDIT_FORM_TEMPLATES'] = true;
    permissionsMap['DELETE_FORM_TEMPLATES'] = true;

    // Aggiungi permessi per form_submissions
    permissionsMap['CREATE_FORM_SUBMISSIONS'] = true;
    permissionsMap['VIEW_FORM_SUBMISSIONS'] = true;
    permissionsMap['EDIT_FORM_SUBMISSIONS'] = true;
    permissionsMap['DELETE_FORM_SUBMISSIONS'] = true;

    // Aggiungi permessi per public_cms
    permissionsMap['CREATE_PUBLIC_CMS'] = true;
    permissionsMap['VIEW_PUBLIC_CMS'] = true;
    permissionsMap['EDIT_PUBLIC_CMS'] = true;
    permissionsMap['DELETE_PUBLIC_CMS'] = true;

    console.log('Nuovi permessi aggiunti:', [
      'CREATE_FORM_TEMPLATES', 'VIEW_FORM_TEMPLATES', 'EDIT_FORM_TEMPLATES', 'DELETE_FORM_TEMPLATES',
      'CREATE_FORM_SUBMISSIONS', 'VIEW_FORM_SUBMISSIONS', 'EDIT_FORM_SUBMISSIONS', 'DELETE_FORM_SUBMISSIONS',
      'CREATE_PUBLIC_CMS', 'VIEW_PUBLIC_CMS', 'EDIT_PUBLIC_CMS', 'DELETE_PUBLIC_CMS'
    ]);

    // 6. Simula il salvataggio (come fa handleRoleSubmit)
    console.log('\n5️⃣ Simulazione salvataggio permessi...');
    
    // Converte dal formato frontend (Record<string, boolean>) al formato backend
    const grantedPermissions = Object.entries(permissionsMap)
      .filter(([_, granted]) => granted)
      .map(([permissionId]) => permissionId);

    const backendPermissions = grantedPermissions.map(permissionId => ({
      permissionId,
      granted: true,
      scope: 'all',
      tenantIds: [],
      fieldRestrictions: []
    }));

    console.log('Permessi da salvare:', {
      count: backendPermissions.length,
      permissions: grantedPermissions
    });

    const saveResponse = await fetch(`${PROXY_BASE}/api/roles/ADMIN/permissions`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(backendPermissions)
    });

    if (!saveResponse.ok) {
      const errorText = await saveResponse.text();
      throw new Error(`Errore nel salvataggio: ${saveResponse.status} - ${errorText}`);
    }

    const saveData = await saveResponse.json();
    console.log('✅ Permessi salvati:', {
      success: saveData.success,
      message: saveData.message
    });

    // 7. Verifica immediata del salvataggio
    console.log('\n6️⃣ Verifica immediata del salvataggio...');
    
    const verifyResponse = await fetch(`${PROXY_BASE}/api/roles/ADMIN/permissions`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!verifyResponse.ok) {
      throw new Error(`Errore nella verifica: ${verifyResponse.status}`);
    }

    const verifyData = await verifyResponse.json();
    const verifiedPermissions = verifyData.data?.permissions?.filter(p => p.granted).map(p => p.permissionId) || [];
    
    console.log('✅ Permessi verificati:', {
      success: verifyData.success,
      permissionsCount: verifiedPermissions.length
    });

    // Controlla se i nuovi permessi sono stati salvati
    const newPermissions = [
      'CREATE_FORM_TEMPLATES', 'VIEW_FORM_TEMPLATES', 'EDIT_FORM_TEMPLATES', 'DELETE_FORM_TEMPLATES',
      'CREATE_FORM_SUBMISSIONS', 'VIEW_FORM_SUBMISSIONS', 'EDIT_FORM_SUBMISSIONS', 'DELETE_FORM_SUBMISSIONS',
      'CREATE_PUBLIC_CMS', 'VIEW_PUBLIC_CMS', 'EDIT_PUBLIC_CMS', 'DELETE_PUBLIC_CMS'
    ];

    const savedNewPermissions = newPermissions.filter(perm => verifiedPermissions.includes(perm));
    const missingSavedPermissions = newPermissions.filter(perm => !verifiedPermissions.includes(perm));

    console.log('\n7️⃣ Risultati del test:');
    console.log('Nuovi permessi salvati correttamente:', savedNewPermissions);
    if (missingSavedPermissions.length > 0) {
      console.log('❌ Nuovi permessi NON salvati:', missingSavedPermissions);
    } else {
      console.log('✅ SUCCESSO: Tutti i nuovi permessi sono stati salvati correttamente!');
    }

  } catch (error) {
    console.error('❌ Errore nel test:', error.message);
    process.exit(1);
  }
}

// Esegui il test
testFrontendPermissions();