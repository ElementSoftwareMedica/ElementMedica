const puppeteer = require('puppeteer');

async function testCounters() {
  const browser = await puppeteer.launch({
    headless: false,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  try {
    const page = await browser.newPage();
    
    // Abilita console logging
    page.on('console', msg => {
      const type = msg.type();
      if (type === 'error') {
        console.log(`[BROWSER ERROR] ${msg.text()}`);
      } else if (type === 'log') {
        console.log(`[BROWSER LOG] ${msg.text()}`);
      }
    });

    console.log('🚀 Navigating to login page...');
    await page.goto('http://localhost:5173/login');
    
    // Login
    console.log('🔐 Performing login...');
    await page.waitForSelector('input[type="email"]');
    await page.type('input[type="email"]', 'admin@example.com');
    await page.type('input[type="password"]', 'password123');
    await page.click('button[type="submit"]');
    
    // Aspetta che il login sia completato
    console.log('⏳ Waiting for login completion...');
    await page.waitForSelector('[data-testid="dashboard"]', { timeout: 10000 });
    
    console.log('✅ Login completed, checking counters...');
    
    // Aspetta un po' per permettere alle API di caricare
    await page.waitForTimeout(3000);
    
    // Cerca i contatori
    const counters = await page.evaluate(() => {
      const counterElements = document.querySelectorAll('.text-2xl.font-bold.text-gray-800.mt-1');
      return Array.from(counterElements).map((el, index) => ({
        index,
        value: el.textContent.trim(),
        className: el.className,
        parentText: el.parentElement ? el.parentElement.textContent.trim() : 'No parent'
      }));
    });
    
    console.log('📊 Found counters:', counters);
    
    // Controlla se ci sono errori CORS nella console
    const logs = await page.evaluate(() => {
      return window.console._logs || [];
    });
    
    // Salva screenshot
    await page.screenshot({ path: 'counters-test.png', fullPage: true });
    console.log('📸 Screenshot saved as counters-test.png');
    
    if (counters.length > 0) {
      console.log('✅ SUCCESS: Counters are visible!');
      counters.forEach(counter => {
        console.log(`   - ${counter.parentText}: ${counter.value}`);
      });
    } else {
      console.log('❌ FAILURE: No counters found');
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    await page.screenshot({ path: 'counters-error.png', fullPage: true });
    console.log('📸 Error screenshot saved as counters-error.png');
  } finally {
    await browser.close();
  }
}

testCounters();