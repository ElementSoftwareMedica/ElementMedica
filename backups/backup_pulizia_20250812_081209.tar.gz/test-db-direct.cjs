const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function testDatabase() {
  try {
    console.log('🔍 Testing direct database connection...');
    
    // Test basic connection
    console.log('1️⃣ Testing basic connection...');
    const result = await prisma.$queryRaw`SELECT 1 as test`;
    console.log('✅ Database connection OK:', result);
    
    // Test person query
    console.log('2️⃣ Testing person query...');
    const person = await prisma.person.findFirst({
      where: {
        email: 'admin@example.com'
      },
      select: {
        id: true,
        email: true,
        globalRole: true
      }
    });
    
    if (person) {
      console.log('✅ Person found:', {
        id: person.id,
        email: person.email,
        globalRole: person.globalRole
      });
    } else {
      console.log('❌ Person not found');
    }
    
  } catch (error) {
    console.error('❌ Database test failed:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testDatabase();