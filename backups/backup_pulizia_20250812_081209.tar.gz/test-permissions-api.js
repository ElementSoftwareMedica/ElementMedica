const fetch = require('node-fetch');

async function testPermissionsAPI() {
  try {
    console.log('🔍 Testing permissions API...');
    
    // 1. Login per ottenere il token
    console.log('🔍 Step 1: Login...');
    const loginResponse = await fetch('http://localhost:4001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });
    
    const loginData = await loginResponse.json();
    console.log('🔍 Login response:', loginData);
    
    if (!loginData.success || !loginData.data?.token) {
      console.error('❌ Login failed');
      return;
    }
    
    const token = loginData.data.token;
    console.log('✅ Login successful, token obtained');
    
    // 2. Test GET permissions per ADMIN
    console.log('🔍 Step 2: Getting ADMIN permissions...');
    const permissionsResponse = await fetch('http://localhost:4001/api/roles/ADMIN/permissions', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    const permissionsData = await permissionsResponse.json();
    console.log('🔍 Permissions response:', JSON.stringify(permissionsData, null, 2));
    
    if (permissionsData.success && permissionsData.data?.permissions) {
      console.log('✅ Permissions retrieved successfully');
      console.log('📊 Number of permissions:', permissionsData.data.permissions.length);
      
      // Mostra i primi 5 permessi
      const firstFive = permissionsData.data.permissions.slice(0, 5);
      console.log('🔍 First 5 permissions:', firstFive);
      
      // Conta i permessi granted
      const grantedCount = permissionsData.data.permissions.filter(p => p.granted).length;
      console.log('📊 Granted permissions:', grantedCount);
    } else {
      console.error('❌ Failed to get permissions');
    }
    
    // 3. Test PUT permissions per ADMIN (aggiungiamo alcuni permessi)
    console.log('🔍 Step 3: Testing PUT permissions...');
    const testPermissions = [
      { permissionId: 'VIEW_COMPANIES', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'CREATE_FORM_TEMPLATES', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'VIEW_FORM_SUBMISSIONS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'EDIT_PUBLIC_CMS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] }
    ];
    
    const updateResponse = await fetch('http://localhost:4001/api/roles/ADMIN/permissions', {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(testPermissions)
    });
    
    const updateData = await updateResponse.json();
    console.log('🔍 Update response:', updateData);
    
    if (updateData.success) {
      console.log('✅ Permissions updated successfully');
      
      // 4. Verifica che i permessi siano stati salvati
      console.log('🔍 Step 4: Verifying saved permissions...');
      const verifyResponse = await fetch('http://localhost:4001/api/roles/ADMIN/permissions', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      const verifyData = await verifyResponse.json();
      console.log('🔍 Verification response:', JSON.stringify(verifyData, null, 2));
      
      if (verifyData.success && verifyData.data?.permissions) {
        const grantedPermissions = verifyData.data.permissions.filter(p => p.granted);
        console.log('✅ Verification successful');
        console.log('📊 Granted permissions after update:', grantedPermissions.length);
        console.log('🔍 Granted permission IDs:', grantedPermissions.map(p => p.permissionId));
      }
    } else {
      console.error('❌ Failed to update permissions');
    }
    
  } catch (error) {
    console.error('❌ Error testing API:', error);
  }
}

testPermissionsAPI();