// Test della conversione dei permessi
console.log('🔍 Testing permission conversion...');

// Simula la funzione convertBackendToFrontendPermissions
function convertBackendToFrontendPermissions(backendPermissions) {
  const frontendPermissions = {};
  
  backendPermissions.forEach(permission => {
    switch (permission) {
      // CMS Pubblico
      case 'MANAGE_PUBLIC_CMS':
        frontendPermissions['PUBLIC_CMS:READ'] = true;
        frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
        frontendPermissions['PUBLIC_CMS:read'] = true;
        frontendPermissions['PUBLIC_CMS:update'] = true;
        break;
      case 'VIEW_CMS':
        frontendPermissions['PUBLIC_CMS:READ'] = true;
        frontendPermissions['PUBLIC_CMS:read'] = true;
        break;
      case 'CREATE_CMS':
        frontendPermissions['PUBLIC_CMS:CREATE'] = true;
        frontendPermissions['PUBLIC_CMS:create'] = true;
        break;
      case 'EDIT_CMS':
        frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
        frontendPermissions['PUBLIC_CMS:update'] = true;
        break;
      case 'DELETE_CMS':
        frontendPermissions['PUBLIC_CMS:DELETE'] = true;
        frontendPermissions['PUBLIC_CMS:delete'] = true;
        break;
        
      // Form Templates
      case 'MANAGE_FORM_TEMPLATES':
        frontendPermissions['form_templates:read'] = true;
        frontendPermissions['form_templates:create'] = true;
        frontendPermissions['form_templates:update'] = true;
        frontendPermissions['form_templates:delete'] = true;
        break;
        
      // Form Submissions
      case 'MANAGE_FORM_SUBMISSIONS':
        frontendPermissions['form_submissions:read'] = true;
        frontendPermissions['form_submissions:create'] = true;
        frontendPermissions['form_submissions:update'] = true;
        frontendPermissions['form_submissions:delete'] = true;
        frontendPermissions['form_submissions:export'] = true;
        break;
    }
  });
  
  return frontendPermissions;
}

// Simula i permessi backend dell'admin
const backendPermissions = [
  'MANAGE_PUBLIC_CMS',
  'MANAGE_FORM_TEMPLATES', 
  'MANAGE_FORM_SUBMISSIONS',
  'VIEW_CMS',
  'CREATE_CMS',
  'EDIT_CMS',
  'DELETE_CMS'
];

console.log('Backend permissions:', backendPermissions);

const frontendPermissions = convertBackendToFrontendPermissions(backendPermissions);
console.log('Frontend permissions:', frontendPermissions);

// Test specifici
console.log('\n🧪 Specific tests:');
console.log('Has PUBLIC_CMS:READ?', frontendPermissions['PUBLIC_CMS:READ']);
console.log('Has PUBLIC_CMS:UPDATE?', frontendPermissions['PUBLIC_CMS:UPDATE']);
console.log('Has form_templates:read?', frontendPermissions['form_templates:read']);
console.log('Has form_submissions:read?', frontendPermissions['form_submissions:read']);

// Test dei controlli che fanno le pagine
console.log('\n🔍 Page permission checks:');
console.log('PublicCMSPage canView (PUBLIC_CMS:READ):', frontendPermissions['PUBLIC_CMS:READ']);
console.log('PublicCMSPage canEdit (PUBLIC_CMS:UPDATE):', frontendPermissions['PUBLIC_CMS:UPDATE']);
console.log('FormTemplatesPage access (form_templates:read):', frontendPermissions['form_templates:read']);
console.log('FormSubmissionsPage access (form_submissions:read):', frontendPermissions['form_submissions:read']);
