const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

async function debugPermissions() {
  try {
    console.log('🚀 Starting permissions debug...');
    
    // Login
    console.log('📝 Step 1: Login...');
    const loginResponse = await fetch('http://localhost:4001/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });
    
    console.log('Login response status:', loginResponse.status);
    console.log('Login response headers:', Object.fromEntries(loginResponse.headers));
    
    const loginData = await loginResponse.json();
    console.log('Login data:', loginData);
    
    if (!loginData.success) {
      throw new Error(`Login failed: ${loginData.message}`);
    }
    
    console.log('✅ Login successful');
    
    // Verify permissions
    console.log('📝 Step 2: Verify permissions...');
    const verifyResponse = await fetch('http://localhost:4001/auth/verify', {
      headers: {
        'Authorization': `Bearer ${loginData.data.token}`
      }
    });
    
    const verifyData = await verifyResponse.json();
    
    if (!verifyData.success) {
      throw new Error(`Verify failed: ${verifyData.message}`);
    }
    
    console.log('✅ Permissions loaded');
    
    const permissions = verifyData.data.permissions;
    
    // Analizza i permessi
    console.log('\n📊 Permission Analysis:');
    console.log(`Total permissions: ${Object.keys(permissions).length}`);
    
    // Filtra i permessi CMS e form
    const cmsFormPermissions = Object.keys(permissions)
      .filter(key => permissions[key] === true)
      .filter(key => 
        key.includes('form_') || 
        key.includes('FORM_') || 
        key.includes('PUBLIC_CMS') || 
        key.includes('CMS') ||
        key.includes('cms')
      )
      .sort();
    
    console.log(`\n📋 CMS/Form permissions (${cmsFormPermissions.length}):`);
    cmsFormPermissions.forEach(permission => {
      console.log(`  ✅ ${permission}`);
    });
    
    // Test dei permessi problematici
    console.log('\n🧪 Testing problematic permissions:');
    const permissionsToTest = [
      'form_templates:read',
      'form_templates:update', 
      'form_templates:edit',
      'form_submissions:read',
      'form_submissions:update',
      'form_submissions:edit',
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE',
      'EDIT_FORM_TEMPLATES',
      'EDIT_FORM_SUBMISSIONS',
      'MANAGE_FORM_TEMPLATES',
      'MANAGE_FORM_SUBMISSIONS'
    ];
    
    permissionsToTest.forEach(permission => {
      const hasPermission = permissions[permission] === true;
      const icon = hasPermission ? '✅' : '❌';
      console.log(`  ${icon} ${permission}: ${hasPermission}`);
    });
    
    // Test della conversione
    console.log('\n🔄 Testing permission conversion:');
    
    // Simula la funzione convertBackendToFrontendPermissions
    const convertedPermissions = {};
    
    // Mantieni i permessi backend originali
    Object.keys(permissions).forEach(key => {
      if (permissions[key] === true) {
        convertedPermissions[key] = true;
      }
    });
    
    // Aggiungi le mappature frontend
    Object.keys(permissions).forEach(backendKey => {
      if (permissions[backendKey] === true) {
        // Converti EDIT_FORM_TEMPLATES -> form_templates:edit e form_templates:update
        if (backendKey === 'EDIT_FORM_TEMPLATES') {
          convertedPermissions['form_templates:edit'] = true;
          convertedPermissions['form_templates:update'] = true;
          console.log(`  🔄 ${backendKey} -> form_templates:edit, form_templates:update`);
        }
        // Converti EDIT_FORM_SUBMISSIONS -> form_submissions:edit e form_submissions:update
        else if (backendKey === 'EDIT_FORM_SUBMISSIONS') {
          convertedPermissions['form_submissions:edit'] = true;
          convertedPermissions['form_submissions:update'] = true;
          console.log(`  🔄 ${backendKey} -> form_submissions:edit, form_submissions:update`);
        }
        // Converti MANAGE_FORM_TEMPLATES
        else if (backendKey === 'MANAGE_FORM_TEMPLATES') {
          convertedPermissions['form_templates:read'] = true;
          convertedPermissions['form_templates:view'] = true;
          convertedPermissions['form_templates:create'] = true;
          convertedPermissions['form_templates:edit'] = true;
          convertedPermissions['form_templates:update'] = true;
          convertedPermissions['form_templates:delete'] = true;
          console.log(`  🔄 ${backendKey} -> all form_templates actions`);
        }
        // Converti MANAGE_FORM_SUBMISSIONS
        else if (backendKey === 'MANAGE_FORM_SUBMISSIONS') {
          convertedPermissions['form_submissions:read'] = true;
          convertedPermissions['form_submissions:view'] = true;
          convertedPermissions['form_submissions:create'] = true;
          convertedPermissions['form_submissions:edit'] = true;
          convertedPermissions['form_submissions:update'] = true;
          convertedPermissions['form_submissions:delete'] = true;
          console.log(`  🔄 ${backendKey} -> all form_submissions actions`);
        }
      }
    });
    
    console.log('\n🎯 After conversion test:');
    const testAfterConversion = [
      'form_templates:update',
      'form_submissions:update'
    ];
    
    testAfterConversion.forEach(permission => {
      const hasPermission = convertedPermissions[permission] === true;
      const icon = hasPermission ? '✅' : '❌';
      console.log(`  ${icon} ${permission}: ${hasPermission}`);
    });
    
  } catch (error) {
    console.error('❌ Debug failed:', error.message);
  }
}

debugPermissions();