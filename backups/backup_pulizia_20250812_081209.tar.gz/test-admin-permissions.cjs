const axios = require('axios');

async function testAdminPermissions() {
  try {
    console.log('🔐 Testing admin permissions...');
    
    // 1. Login come admin
    console.log('\n1. 🔑 Logging in as admin...');
    const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    if (loginResponse.status !== 200) {
      console.error('❌ Login failed:', loginResponse.status);
      return;
    }
    
    console.log('✅ Login successful');
    console.log('📋 Login response structure:', JSON.stringify(loginResponse.data, null, 2));
    
    const token = loginResponse.data.tokens?.access_token || loginResponse.data.token;
    const person = loginResponse.data.user || loginResponse.data.person;
    const personId = person?.id;
    
    console.log('🔑 Token:', token ? 'Present' : 'Missing');
    console.log('👤 Person ID:', personId || 'Missing');
    
    // 2. Verifica permessi utente
    console.log('\n2. 🔍 Checking user permissions...');
    try {
      const permissionsResponse = await axios.get(`http://localhost:4003/api/v1/auth/permissions`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      console.log('📊 Permissions response:', JSON.stringify(permissionsResponse.data, null, 2));
      
      const permissions = permissionsResponse.data.permissions || permissionsResponse.data;
      
      // Cerca permessi FORM_SUBMISSIONS
      const formSubmissionPermissions = Object.keys(permissions).filter(p => 
        p.includes('FORM_SUBMISSIONS')
      );
      
      console.log('\n📋 FORM_SUBMISSIONS permissions:');
      formSubmissionPermissions.forEach(p => {
        console.log(`  - ${p}: ${permissions[p] ? '✅ GRANTED' : '❌ DENIED'}`);
      });
      
    } catch (error) {
      console.log('❌ Permissions check failed:', error.response?.status, error.response?.data?.error);
    }
    
    // 3. Test diretto RBACService
    console.log('\n3. 🧪 Testing RBACService directly...');
    try {
      const rbacResponse = await axios.get(`http://localhost:4003/api/v1/auth/permissions`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      console.log('✅ RBACService permissions loaded');
      
      // Cerca permessi VIEW_FORM_SUBMISSIONS
      const hasViewPermission = rbacResponse.data.permissions && rbacResponse.data.permissions['VIEW_FORM_SUBMISSIONS'];
      console.log('🔍 VIEW_FORM_SUBMISSIONS:', hasViewPermission ? '✅ GRANTED' : '❌ DENIED');
      
    } catch (error) {
      console.log('❌ RBACService test failed:', error.response?.status, error.response?.data?.error);
    }
    
    // 4. Test endpoint submissions
    console.log('\n4. 🧪 Testing submissions endpoint...');
    try {
      const submissionsResponse = await axios.get('http://localhost:4003/api/v1/submissions', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      console.log('✅ /api/v1/submissions - Status:', submissionsResponse.status);
    } catch (error) {
      console.log('❌ /api/v1/submissions - Error:', error.response?.status, error.response?.data?.error);
      if (error.response?.data?.message) {
        console.log('   Message:', error.response.data.message);
      }
    }
    
    // 5. Test endpoint submissions/advanced
    console.log('\n5. 🧪 Testing submissions/advanced endpoint...');
    try {
      const advancedResponse = await axios.get('http://localhost:4003/api/v1/submissions/advanced', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      console.log('✅ /api/v1/submissions/advanced - Status:', advancedResponse.status);
    } catch (error) {
      console.log('❌ /api/v1/submissions/advanced - Error:', error.response?.status, error.response?.data?.error);
      if (error.response?.data?.message) {
        console.log('   Message:', error.response.data.message);
      }
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data);
    }
  }
}

testAdminPermissions();