const { PrismaClient } = require('./backend/node_modules/@prisma/client');

async function checkAdminPermissions() {
  const prisma = new PrismaClient();
  
  try {
    console.log('🔍 Verifica permessi admin...\n');
    
    // Trova l'admin
    const admin = await prisma.person.findUnique({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: {
          where: {
            isActive: true,
            deletedAt: null
          },
          include: {
            permissions: true
          }
        }
      }
    });
    
    if (!admin) {
      console.log('❌ Admin non trovato!');
      return;
    }
    
    console.log(`✅ Admin trovato: ${admin.email}`);
    console.log(`📋 Ruoli attivi: ${admin.personRoles.length}\n`);
    
    // Analizza i permessi per ogni ruolo
    for (const role of admin.personRoles) {
      console.log(`🎭 Ruolo: ${role.roleType}`);
      console.log(`📊 Permessi: ${role.permissions.length}`);
      
      // Permessi specifici che ci interessano
      const cmsPermissions = role.permissions.filter(p => 
        p.permission.includes('CMS') || 
        p.permission.includes('PUBLIC_CMS') ||
        p.permission.includes('MANAGE_PUBLIC_CONTENT')
      );
      
      const formPermissions = role.permissions.filter(p => 
        p.permission.includes('FORM') || 
        p.permission.includes('TEMPLATE') ||
        p.permission.includes('SUBMISSION')
      );
      
      console.log(`🎨 Permessi CMS (${cmsPermissions.length}):`);
      cmsPermissions.forEach(p => {
        console.log(`  ${p.isGranted ? '✅' : '❌'} ${p.permission}`);
      });
      
      console.log(`📝 Permessi Form (${formPermissions.length}):`);
      formPermissions.forEach(p => {
        console.log(`  ${p.isGranted ? '✅' : '❌'} ${p.permission}`);
      });
      
      console.log('');
    }
    
    // Verifica permessi specifici richiesti dalle pagine
    const requiredPermissions = [
      'VIEW_PUBLIC_CMS',
      'EDIT_PUBLIC_CMS', 
      'MANAGE_PUBLIC_CMS',
      'MANAGE_PUBLIC_CONTENT',
      'VIEW_FORM_TEMPLATES',
      'CREATE_FORM_TEMPLATES',
      'EDIT_FORM_TEMPLATES',
      'DELETE_FORM_TEMPLATES',
      'MANAGE_FORM_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS',
      'CREATE_FORM_SUBMISSIONS',
      'EDIT_FORM_SUBMISSIONS',
      'DELETE_FORM_SUBMISSIONS',
      'MANAGE_FORM_SUBMISSIONS',
      'VIEW_TEMPLATES',
      'CREATE_TEMPLATES',
      'EDIT_TEMPLATES',
      'DELETE_TEMPLATES',
      'MANAGE_TEMPLATES',
      'VIEW_SUBMISSIONS',
      'CREATE_SUBMISSIONS',
      'EDIT_SUBMISSIONS',
      'DELETE_SUBMISSIONS',
      'MANAGE_SUBMISSIONS'
    ];
    
    console.log('🎯 Verifica permessi richiesti dalle pagine:\n');
    
    const allPermissions = admin.personRoles.flatMap(role => role.permissions);
    
    for (const permission of requiredPermissions) {
      const hasPermission = allPermissions.find(p => 
        p.permission === permission && p.isGranted
      );
      console.log(`${hasPermission ? '✅' : '❌'} ${permission}`);
    }
    
  } catch (error) {
    console.error('❌ Errore:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkAdminPermissions();