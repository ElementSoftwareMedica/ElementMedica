const axios = require('axios');

async function testRolesEndpoint() {
  try {
    console.log('🔍 Testing roles endpoint...');
    
    // Prima fai login per ottenere il token
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    console.log('✅ Login successful');
    
    const token = loginResponse.data.tokens.access_token;
    console.log('🔑 Token obtained');

    // Ora testa l'endpoint dei ruoli
    const rolesResponse = await axios.get('http://localhost:4001/api/v1/permissions/roles', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
    });

    console.log('📊 Roles endpoint response status:', rolesResponse.status);
    const rolesData = rolesResponse.data;
    console.log('✅ Roles data received');
    console.log('📋 Response structure:', {
      hasData: !!rolesData.data,
      dataKeys: rolesData.data ? Object.keys(rolesData.data) : null,
      rolesCount: Array.isArray(rolesData.data) ? rolesData.data.length : 0
    });

    if (rolesData.data && Array.isArray(rolesData.data)) {
      console.log('📋 Available roles:');
      rolesData.data.forEach(role => {
        console.log(`   - ${role.name || role.id}: ${role.permissions?.length || 0} permissions`);
        
        // Controlla se è il ruolo ADMIN
        if (role.id === 'ADMIN' || role.name === 'ADMIN') {
          console.log('🔍 ADMIN role permissions:');
          if (role.permissions && role.permissions.length > 0) {
            const formTemplatesPerms = role.permissions.filter(p => p.name?.includes('form_templates') || p.resource === 'form_templates');
            const formSubmissionsPerms = role.permissions.filter(p => p.name?.includes('form_submissions') || p.resource === 'form_submissions');
            const publicCmsPerms = role.permissions.filter(p => p.name?.includes('public_cms') || p.resource === 'public_cms' || p.name?.includes('cms'));
            
            console.log(`     form_templates: ${formTemplatesPerms.length} permessi`);
            console.log(`     form_submissions: ${formSubmissionsPerms.length} permessi`);
            console.log(`     public_cms: ${publicCmsPerms.length} permessi`);
            
            if (formTemplatesPerms.length > 0) {
              console.log('     form_templates permessi:', formTemplatesPerms.map(p => p.name));
            }
            if (formSubmissionsPerms.length > 0) {
              console.log('     form_submissions permessi:', formSubmissionsPerms.map(p => p.name));
            }
            if (publicCmsPerms.length > 0) {
              console.log('     public_cms permessi:', publicCmsPerms.map(p => p.name));
            }
          } else {
            console.log('     ❌ Nessun permesso trovato per ADMIN!');
          }
        }
      });
    }



  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testRolesEndpoint();