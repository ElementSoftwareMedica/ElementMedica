#!/usr/bin/env node

/**
 * Test completo del flusso dei permessi per form_templates, form_submissions e public_cms
 * Verifica:
 * 1. Permessi salvati nel database
 * 2. Caricamento permessi via API
 * 3. Conversione backend -> frontend
 * 4. Verifica hasPermission nel frontend
 */

import { PrismaClient } from '@prisma/client';
import fetch from 'node-fetch';

const prisma = new PrismaClient();

async function testCompletePermissionsFlow() {
  console.log('🔍 Test Completo Flusso Permessi - Form Templates, Form Submissions, Public CMS\n');

  try {
    // 1. Verifica permessi nel database
    console.log('1️⃣ Verifica permessi nel database...');
    
    const adminUser = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        roleAssignments: {
          include: {
            role: {
              include: {
                permissions: {
                  include: {
                    permission: true
                  }
                }
              }
            }
          }
        }
      }
    });

    if (!adminUser) {
      console.error('❌ Utente admin non trovato');
      return;
    }

    console.log(`✅ Utente trovato: ${adminUser.email}`);

    // Estrai tutti i permessi dell'utente
    const userPermissions = [];
    adminUser.roleAssignments.forEach(assignment => {
      assignment.role.permissions.forEach(rolePermission => {
        if (rolePermission.granted) {
          userPermissions.push(rolePermission.permission.name);
        }
      });
    });

    console.log(`📊 Permessi totali utente: ${userPermissions.length}`);

    // Filtra permessi per le entità che ci interessano
    const targetPermissions = userPermissions.filter(p => 
      p.includes('FORM_TEMPLATES') || 
      p.includes('FORM_SUBMISSIONS') || 
      p.includes('PUBLIC_CMS')
    );

    console.log('🎯 Permessi target trovati:');
    targetPermissions.forEach(p => console.log(`   - ${p}`));

    if (targetPermissions.length === 0) {
      console.error('❌ Nessun permesso target trovato nel database');
      return;
    }

    // 2. Test API caricamento permessi
    console.log('\n2️⃣ Test API caricamento permessi...');
    
    // Simula login per ottenere token
    const loginResponse = await fetch('http://localhost:4001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      console.error('❌ Login fallito');
      return;
    }

    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login effettuato con successo');

    // Carica permessi via API
    const permissionsResponse = await fetch('http://localhost:4001/api/auth/permissions', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!permissionsResponse.ok) {
      console.error('❌ Caricamento permessi fallito');
      return;
    }

    const permissionsData = await permissionsResponse.json();
    console.log('✅ Permessi caricati via API');
    console.log(`📊 Permessi API: ${permissionsData.permissions?.length || 0}`);

    // Filtra permessi API per le entità target
    const apiTargetPermissions = (permissionsData.permissions || []).filter(p => 
      p.includes('FORM_TEMPLATES') || 
      p.includes('FORM_SUBMISSIONS') || 
      p.includes('PUBLIC_CMS')
    );

    console.log('🎯 Permessi target da API:');
    apiTargetPermissions.forEach(p => console.log(`   - ${p}`));

    // 3. Test conversione backend -> frontend
    console.log('\n3️⃣ Test conversione backend -> frontend...');
    
    // Simula la conversione che avviene nel frontend
    const backendPermissions = {};
    apiTargetPermissions.forEach(p => {
      backendPermissions[p] = true;
    });

    console.log('Backend permissions object:', backendPermissions);

    // Simula convertBackendToFrontendPermissions
    const frontendPermissions = {};

    // Conversioni per FORM_TEMPLATES
    if (backendPermissions['VIEW_FORM_TEMPLATES']) {
      frontendPermissions['form_templates:read'] = true;
      frontendPermissions['form_templates:view'] = true;
    }
    if (backendPermissions['CREATE_FORM_TEMPLATES']) {
      frontendPermissions['form_templates:create'] = true;
    }
    if (backendPermissions['EDIT_FORM_TEMPLATES']) {
      frontendPermissions['form_templates:edit'] = true;
      frontendPermissions['form_templates:update'] = true;
    }
    if (backendPermissions['DELETE_FORM_TEMPLATES']) {
      frontendPermissions['form_templates:delete'] = true;
    }
    if (backendPermissions['MANAGE_FORM_TEMPLATES']) {
      frontendPermissions['form_templates:read'] = true;
      frontendPermissions['form_templates:view'] = true;
      frontendPermissions['form_templates:create'] = true;
      frontendPermissions['form_templates:edit'] = true;
      frontendPermissions['form_templates:update'] = true;
      frontendPermissions['form_templates:delete'] = true;
    }

    // Conversioni per FORM_SUBMISSIONS
    if (backendPermissions['VIEW_FORM_SUBMISSIONS']) {
      frontendPermissions['form_submissions:read'] = true;
      frontendPermissions['form_submissions:view'] = true;
    }
    if (backendPermissions['CREATE_FORM_SUBMISSIONS']) {
      frontendPermissions['form_submissions:create'] = true;
    }
    if (backendPermissions['EDIT_FORM_SUBMISSIONS']) {
      frontendPermissions['form_submissions:edit'] = true;
      frontendPermissions['form_submissions:update'] = true;
    }
    if (backendPermissions['DELETE_FORM_SUBMISSIONS']) {
      frontendPermissions['form_submissions:delete'] = true;
    }
    if (backendPermissions['MANAGE_FORM_SUBMISSIONS']) {
      frontendPermissions['form_submissions:read'] = true;
      frontendPermissions['form_submissions:view'] = true;
      frontendPermissions['form_submissions:create'] = true;
      frontendPermissions['form_submissions:edit'] = true;
      frontendPermissions['form_submissions:update'] = true;
      frontendPermissions['form_submissions:delete'] = true;
    }
    if (backendPermissions['EXPORT_FORM_SUBMISSIONS']) {
      frontendPermissions['form_submissions:export'] = true;
    }

    // Conversioni per PUBLIC_CMS
    if (backendPermissions['VIEW_PUBLIC_CMS']) {
      frontendPermissions['PUBLIC_CMS:READ'] = true;
      frontendPermissions['PUBLIC_CMS:read'] = true;
    }
    if (backendPermissions['CREATE_PUBLIC_CMS']) {
      frontendPermissions['PUBLIC_CMS:CREATE'] = true;
      frontendPermissions['PUBLIC_CMS:create'] = true;
    }
    if (backendPermissions['EDIT_PUBLIC_CMS']) {
      frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
      frontendPermissions['PUBLIC_CMS:update'] = true;
    }
    if (backendPermissions['DELETE_PUBLIC_CMS']) {
      frontendPermissions['PUBLIC_CMS:DELETE'] = true;
      frontendPermissions['PUBLIC_CMS:delete'] = true;
    }
    if (backendPermissions['MANAGE_PUBLIC_CMS']) {
      frontendPermissions['PUBLIC_CMS:READ'] = true;
      frontendPermissions['PUBLIC_CMS:read'] = true;
      frontendPermissions['PUBLIC_CMS:CREATE'] = true;
      frontendPermissions['PUBLIC_CMS:create'] = true;
      frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
      frontendPermissions['PUBLIC_CMS:update'] = true;
      frontendPermissions['PUBLIC_CMS:DELETE'] = true;
      frontendPermissions['PUBLIC_CMS:delete'] = true;
    }

    console.log('✅ Conversione completata');
    console.log('🎯 Permessi frontend generati:');
    Object.keys(frontendPermissions).forEach(p => {
      console.log(`   - ${p}: ${frontendPermissions[p]}`);
    });

    // 4. Test hasPermission simulato
    console.log('\n4️⃣ Test hasPermission simulato...');

    function simulateHasPermission(resource, action) {
      const permissionKey = `${resource}:${action}`;
      return frontendPermissions[permissionKey] === true;
    }

    // Test per FormTemplatesPage
    const formTemplatesTests = [
      { resource: 'form_templates', action: 'read' },
      { resource: 'form_templates', action: 'update' },
      { resource: 'form_templates', action: 'delete' },
      { resource: 'form_templates', action: 'create' }
    ];

    console.log('📋 Test FormTemplatesPage:');
    formTemplatesTests.forEach(test => {
      const result = simulateHasPermission(test.resource, test.action);
      console.log(`   - hasPermission('${test.resource}', '${test.action}'): ${result ? '✅' : '❌'}`);
    });

    // Test per FormSubmissionsPage
    const formSubmissionsTests = [
      { resource: 'form_submissions', action: 'read' },
      { resource: 'form_submissions', action: 'update' },
      { resource: 'form_submissions', action: 'delete' },
      { resource: 'form_submissions', action: 'export' }
    ];

    console.log('📋 Test FormSubmissionsPage:');
    formSubmissionsTests.forEach(test => {
      const result = simulateHasPermission(test.resource, test.action);
      console.log(`   - hasPermission('${test.resource}', '${test.action}'): ${result ? '✅' : '❌'}`);
    });

    // Test per PublicCMSPage
    const publicCMSTests = [
      { resource: 'PUBLIC_CMS', action: 'READ' },
      { resource: 'PUBLIC_CMS', action: 'UPDATE' },
      { resource: 'PUBLIC_CMS', action: 'read' },
      { resource: 'PUBLIC_CMS', action: 'update' }
    ];

    console.log('📋 Test PublicCMSPage:');
    publicCMSTests.forEach(test => {
      const result = simulateHasPermission(test.resource, test.action);
      console.log(`   - hasPermission('${test.resource}', '${test.action}'): ${result ? '✅' : '❌'}`);
    });

    // 5. Riepilogo finale
    console.log('\n📊 RIEPILOGO FINALE:');
    console.log(`✅ Permessi nel database: ${targetPermissions.length}`);
    console.log(`✅ Permessi da API: ${apiTargetPermissions.length}`);
    console.log(`✅ Permessi frontend: ${Object.keys(frontendPermissions).length}`);

    const allFormTemplatesWork = formTemplatesTests.every(test => 
      simulateHasPermission(test.resource, test.action)
    );
    const allFormSubmissionsWork = formSubmissionsTests.every(test => 
      simulateHasPermission(test.resource, test.action)
    );
    const allPublicCMSWork = publicCMSTests.every(test => 
      simulateHasPermission(test.resource, test.action)
    );

    console.log(`📋 FormTemplatesPage: ${allFormTemplatesWork ? '✅ FUNZIONA' : '❌ PROBLEMI'}`);
    console.log(`📋 FormSubmissionsPage: ${allFormSubmissionsWork ? '✅ FUNZIONA' : '❌ PROBLEMI'}`);
    console.log(`📋 PublicCMSPage: ${allPublicCMSWork ? '✅ FUNZIONA' : '❌ PROBLEMI'}`);

    if (allFormTemplatesWork && allFormSubmissionsWork && allPublicCMSWork) {
      console.log('\n🎉 TUTTI I TEST PASSATI - Il sistema dovrebbe funzionare correttamente!');
    } else {
      console.log('\n⚠️ ALCUNI TEST FALLITI - Verificare la configurazione dei permessi');
    }

  } catch (error) {
    console.error('❌ Errore durante il test:', error);
  } finally {
    await prisma.$disconnect();
  }
}

// Esegui il test
testCompletePermissionsFlow();