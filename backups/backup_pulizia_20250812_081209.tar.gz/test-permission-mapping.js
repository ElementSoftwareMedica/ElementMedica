#!/usr/bin/env node

// Test per verificare la mappatura dei permessi
import { convertBackendToFrontendPermissions, hasBackendPermission } from './src/utils/permissionMapping.ts';

// Simula i permessi che vengono dal backend per l'Admin
const backendPermissions = {
  'dashboard.view': true,
  'companies.view': true,
  'companies.create': true,
  'companies.edit': true,
  'companies.delete': true,
  'companies.manage': true,
  'persons.view': true,
  'persons.read': true,
  'persons.create': true,
  'persons.edit': true,
  'persons.delete': true,
  'persons.manage': true,
  'persons.view_employees': true,
  'persons.view_trainers': true
};

console.log('🔍 Testing permission mapping...');
console.log('Backend permissions:', Object.keys(backendPermissions).filter(k => backendPermissions[k]));

// Converti i permessi
const frontendPermissions = convertBackendToFrontendPermissions(backendPermissions);
console.log('Frontend permissions:', Object.keys(frontendPermissions).filter(k => frontendPermissions[k]));

// Test specifici
console.log('\n🧪 Testing specific permissions:');
console.log('dashboard:read:', hasBackendPermission('dashboard:read', backendPermissions));
console.log('dashboard:view:', hasBackendPermission('dashboard:view', backendPermissions));
console.log('companies:read:', hasBackendPermission('companies:read', backendPermissions));
console.log('companies:view:', hasBackendPermission('companies:view', backendPermissions));

// Test con i permessi convertiti
console.log('\n🧪 Testing with converted permissions:');
console.log('dashboard:read (converted):', frontendPermissions['dashboard:read']);
console.log('dashboard:view (converted):', frontendPermissions['dashboard:view']);
console.log('companies:read (converted):', frontendPermissions['companies:read']);
console.log('companies:view (converted):', frontendPermissions['companies:view']);