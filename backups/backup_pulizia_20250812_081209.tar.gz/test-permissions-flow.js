import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function testPermissionsFlow() {
  try {
    console.log('🧪 Testing permissions flow...');
    
    // 1. Trova l'admin
    const admin = await prisma.person.findFirst({
      where: {
        email: 'admin@example.com',
        deletedAt: null
      },
      include: {
        personRoles: {
          where: { deletedAt: null },
          include: {
            permissions: true,
            customRole: {
              include: {
                permissions: true
              }
            }
          }
        }
      }
    });
    
    if (!admin) {
      console.log('❌ Admin not found');
      return;
    }
    
    console.log('✅ Admin found:', admin.email);
    console.log('📋 Admin roles:', admin.personRoles.length);
    
    // 2. Verifica i ruoli dell'admin
    for (const personRole of admin.personRoles) {
      console.log(`\n🔍 Role: ${personRole.roleType}`);
      console.log(`📊 Role permissions count: ${personRole.permissions.length}`);
      
      // Mostra i permessi del ruolo
      if (personRole.permissions.length > 0) {
        console.log('📝 Role permissions:');
        personRole.permissions.forEach(perm => {
          console.log(`  - ${perm.permission} (granted: ${perm.isGranted})`);
        });
      }
      
      // Se è un ruolo personalizzato, mostra anche i permessi del CustomRole
      if (personRole.customRole) {
        console.log(`📊 Custom role permissions count: ${personRole.customRole.permissions.length}`);
        if (personRole.customRole.permissions.length > 0) {
          console.log('📝 Custom role permissions:');
          personRole.customRole.permissions.forEach(perm => {
            console.log(`  - ${perm.permission} (scope: ${perm.scope})`);
          });
        }
      }
    }
    
    // 3. Test aggiunta di nuovi permessi
    console.log('\n🔧 Testing permission addition...');
    
    const adminRole = admin.personRoles.find(pr => pr.roleType === 'ADMIN');
    if (adminRole) {
      // Aggiungi alcuni permessi di test per le nuove entità
      const testPermissions = [
        'VIEW_FORM_TEMPLATES',
        'CREATE_FORM_TEMPLATES',
        'EDIT_FORM_TEMPLATES',
        'DELETE_FORM_TEMPLATES',
        'VIEW_SUBMISSIONS',
        'CREATE_SUBMISSIONS',
        'EDIT_SUBMISSIONS',
        'DELETE_SUBMISSIONS',
        'VIEW_PUBLIC_CMS',
        'CREATE_PUBLIC_CMS',
        'EDIT_PUBLIC_CMS',
        'DELETE_PUBLIC_CMS'
      ];
      
      console.log('🔧 Adding test permissions...');
      
      // Rimuovi i permessi esistenti per questo test
      await prisma.rolePermission.deleteMany({
        where: { personRoleId: adminRole.id }
      });
      
      // Aggiungi i nuovi permessi
      const permissionsToCreate = testPermissions.map(permission => ({
        personRoleId: adminRole.id,
        permission: permission,
        isGranted: true,
        grantedBy: admin.id
      }));
      
      await prisma.rolePermission.createMany({
        data: permissionsToCreate
      });
      
      console.log(`✅ Added ${testPermissions.length} test permissions`);
      
      // 4. Verifica che i permessi siano stati salvati
      const savedPermissions = await prisma.rolePermission.findMany({
        where: { personRoleId: adminRole.id }
      });
      
      console.log(`✅ Verified: ${savedPermissions.length} permissions saved in database`);
      console.log('📝 Saved permissions:');
      savedPermissions.forEach(perm => {
        console.log(`  - ${perm.permission} (granted: ${perm.isGranted})`);
      });
      
      // 5. Test del caricamento tramite API (simula quello che fa il frontend)
      console.log('\n🔍 Testing API-style permission loading...');
      
      const rolePermissions = await prisma.rolePermission.findMany({
        where: { 
          personRoleId: adminRole.id,
          isGranted: true
        }
      });
      
      const permissionIds = rolePermissions.map(rp => rp.permission);
      console.log(`✅ API-style loading: ${permissionIds.length} granted permissions`);
      console.log('📝 Permission IDs:', permissionIds);
      
    } else {
      console.log('❌ Admin role not found');
    }
    
  } catch (error) {
    console.error('❌ Error in permissions flow test:', error);
  } finally {
    await prisma.$disconnect();
  }
}

testPermissionsFlow();