const puppeteer = require('puppeteer');

async function testBrowserStorage() {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();
  
  try {
    console.log('🌐 Opening dashboard...');
    await page.goto('http://localhost:5173', { waitUntil: 'networkidle0' });
    
    // Aspetta che la pagina sia caricata
    await page.waitForTimeout(2000);
    
    console.log('🔍 Checking localStorage...');
    const storageData = await page.evaluate(() => {
      return {
        authToken: localStorage.getItem('authToken'),
        tenantId: localStorage.getItem('tenantId'),
        allKeys: Object.keys(localStorage),
        allData: JSON.stringify(localStorage)
      };
    });
    
    console.log('📋 LocalStorage data:', storageData);
    
    // Se non c'è token, prova a fare login
    if (!storageData.authToken) {
      console.log('🔐 No token found, attempting login...');
      
      // Cerca il form di login
      const loginForm = await page.$('form');
      if (loginForm) {
        console.log('📝 Login form found, filling credentials...');
        
        // Compila i campi
        await page.type('input[type="email"], input[name="identifier"]', 'admin@example.com');
        await page.type('input[type="password"]', 'Admin123!');
        
        // Clicca submit
        await page.click('button[type="submit"]');
        
        // Aspetta il redirect
        await page.waitForTimeout(3000);
        
        // Controlla di nuovo il localStorage
        const storageAfterLogin = await page.evaluate(() => {
          return {
            authToken: localStorage.getItem('authToken'),
            tenantId: localStorage.getItem('tenantId'),
            allKeys: Object.keys(localStorage)
          };
        });
        
        console.log('📋 LocalStorage after login:', storageAfterLogin);
        
        // Testa la chiamata ai contatori
        if (storageAfterLogin.authToken) {
          console.log('🔄 Testing counters call from browser...');
          const countersResult = await page.evaluate(async () => {
            try {
              const response = await fetch('/api/counters', {
                headers: {
                  'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
                  'Content-Type': 'application/json',
                  'X-Tenant-ID': localStorage.getItem('tenantId') || 'default-company'
                }
              });
              
              if (response.ok) {
                const data = await response.json();
                return { success: true, data };
              } else {
                return { success: false, status: response.status, statusText: response.statusText };
              }
            } catch (error) {
              return { success: false, error: error.message };
            }
          });
          
          console.log('📊 Counters result:', countersResult);
        }
      }
    }
    
    // Controlla i contatori nella pagina
    console.log('🔍 Checking counter values in page...');
    const counterValues = await page.evaluate(() => {
      const companyCounter = document.querySelector('h3:contains("0")') || 
                           document.querySelector('[data-testid="company-counter"]') ||
                           Array.from(document.querySelectorAll('h3')).find(el => el.textContent === '0');
      
      const employeeCounter = document.querySelector('[data-testid="employee-counter"]') ||
                            Array.from(document.querySelectorAll('h3')).find((el, index) => 
                              el.textContent === '0' && index > 0);
      
      return {
        companyCounterText: companyCounter?.textContent,
        employeeCounterText: employeeCounter?.textContent,
        allH3Elements: Array.from(document.querySelectorAll('h3')).map(el => el.textContent)
      };
    });
    
    console.log('📊 Counter values in page:', counterValues);
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await browser.close();
  }
}

testBrowserStorage();