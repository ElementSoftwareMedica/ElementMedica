#!/usr/bin/env node

/**
 * Script per diagnosticare e risolvere il problema dei permessi CMS e Form
 * Verifica e aggiunge i permessi mancanti per l'admin
 */

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('🔍 Diagnostica e risoluzione problema permessi CMS e Form...\n');

  try {
    // 1. Trova l'admin
    console.log('1. Ricerca admin...');
    const admin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: {
          include: {
            roleType: {
              include: {
                rolePermissions: {
                  include: {
                    permission: true
                  }
                }
              }
            }
          }
        }
      }
    });

    if (!admin) {
      console.error('❌ Admin non trovato!');
      return;
    }

    console.log(`✅ Admin trovato: ${admin.firstName} ${admin.lastName} (${admin.email})`);

    // 2. Verifica ruoli admin
    console.log('\n2. Verifica ruoli admin...');
    const adminRoles = admin.personRoles;
    console.log(`Ruoli trovati: ${adminRoles.length}`);
    
    adminRoles.forEach(role => {
      console.log(`- ${role.roleType.name} (${role.roleType.permissions?.length || 0} permessi)`);
    });

    // 3. Verifica permessi CMS e Form esistenti
    console.log('\n3. Verifica permessi CMS e Form esistenti...');
    const cmsFormPermissions = await prisma.permission.findMany({
      where: {
        OR: [
          { name: { contains: 'CMS' } },
          { name: { contains: 'FORM' } },
          { name: { contains: 'TEMPLATE' } },
          { name: { contains: 'SUBMISSION' } }
        ]
      }
    });

    console.log(`Permessi CMS/Form trovati nel database: ${cmsFormPermissions.length}`);
    cmsFormPermissions.forEach(perm => {
      console.log(`- ${perm.name}: ${perm.description}`);
    });

    // 4. Definisci i permessi richiesti
    const requiredPermissions = [
      // Public CMS
      { name: 'VIEW_PUBLIC_CMS', description: 'View public CMS content', resource: 'public_cms', action: 'view' },
      { name: 'CREATE_PUBLIC_CMS', description: 'Create public CMS content', resource: 'public_cms', action: 'create' },
      { name: 'EDIT_PUBLIC_CMS', description: 'Edit public CMS content', resource: 'public_cms', action: 'edit' },
      { name: 'DELETE_PUBLIC_CMS', description: 'Delete public CMS content', resource: 'public_cms', action: 'delete' },
      { name: 'MANAGE_PUBLIC_CMS', description: 'Manage public CMS content', resource: 'public_cms', action: 'manage' },
      
      // Form Templates
      { name: 'VIEW_FORM_TEMPLATES', description: 'View form templates', resource: 'form_templates', action: 'view' },
      { name: 'CREATE_FORM_TEMPLATES', description: 'Create form templates', resource: 'form_templates', action: 'create' },
      { name: 'EDIT_FORM_TEMPLATES', description: 'Edit form templates', resource: 'form_templates', action: 'edit' },
      { name: 'DELETE_FORM_TEMPLATES', description: 'Delete form templates', resource: 'form_templates', action: 'delete' },
      { name: 'MANAGE_FORM_TEMPLATES', description: 'Manage form templates', resource: 'form_templates', action: 'manage' },
      
      // Form Submissions
      { name: 'VIEW_FORM_SUBMISSIONS', description: 'View form submissions', resource: 'form_submissions', action: 'view' },
      { name: 'CREATE_FORM_SUBMISSIONS', description: 'Create form submissions', resource: 'form_submissions', action: 'create' },
      { name: 'EDIT_FORM_SUBMISSIONS', description: 'Edit form submissions', resource: 'form_submissions', action: 'edit' },
      { name: 'DELETE_FORM_SUBMISSIONS', description: 'Delete form submissions', resource: 'form_submissions', action: 'delete' },
      { name: 'MANAGE_FORM_SUBMISSIONS', description: 'Manage form submissions', resource: 'form_submissions', action: 'manage' },
      { name: 'EXPORT_FORM_SUBMISSIONS', description: 'Export form submissions', resource: 'form_submissions', action: 'export' },
      
      // Permessi generici per compatibilità
      { name: 'VIEW_CMS', description: 'View CMS content', resource: 'cms', action: 'view' },
      { name: 'CREATE_CMS', description: 'Create CMS content', resource: 'cms', action: 'create' },
      { name: 'EDIT_CMS', description: 'Edit CMS content', resource: 'cms', action: 'edit' },
      { name: 'DELETE_CMS', description: 'Delete CMS content', resource: 'cms', action: 'delete' },
      { name: 'MANAGE_PUBLIC_CONTENT', description: 'Manage public content', resource: 'public_content', action: 'manage' },
      { name: 'READ_PUBLIC_CONTENT', description: 'Read public content', resource: 'public_content', action: 'read' },
      
      { name: 'VIEW_SUBMISSIONS', description: 'View submissions', resource: 'submissions', action: 'view' },
      { name: 'CREATE_SUBMISSIONS', description: 'Create submissions', resource: 'submissions', action: 'create' },
      { name: 'EDIT_SUBMISSIONS', description: 'Edit submissions', resource: 'submissions', action: 'edit' },
      { name: 'DELETE_SUBMISSIONS', description: 'Delete submissions', resource: 'submissions', action: 'delete' },
      { name: 'MANAGE_SUBMISSIONS', description: 'Manage submissions', resource: 'submissions', action: 'manage' },
      { name: 'EXPORT_SUBMISSIONS', description: 'Export submissions', resource: 'submissions', action: 'export' }
    ];

    // 5. Crea permessi mancanti
    console.log('\n4. Creazione permessi mancanti...');
    let createdCount = 0;
    
    for (const permData of requiredPermissions) {
      const existing = await prisma.permission.findFirst({
        where: { name: permData.name }
      });

      if (!existing) {
        await prisma.permission.create({
          data: permData
        });
        console.log(`✅ Creato permesso: ${permData.name}`);
        createdCount++;
      }
    }

    console.log(`Permessi creati: ${createdCount}`);

    // 6. Trova il ruolo ADMIN
    console.log('\n5. Ricerca ruolo ADMIN...');
    const adminRoleType = await prisma.roleType.findFirst({
      where: { name: 'ADMIN' },
      include: {
        rolePermissions: {
          include: {
            permission: true
          }
        }
      }
    });

    if (!adminRoleType) {
      console.error('❌ Ruolo ADMIN non trovato!');
      return;
    }

    console.log(`✅ Ruolo ADMIN trovato con ${adminRoleType.rolePermissions.length} permessi`);

    // 7. Assegna permessi mancanti al ruolo ADMIN
    console.log('\n6. Assegnazione permessi al ruolo ADMIN...');
    let assignedCount = 0;

    for (const permData of requiredPermissions) {
      const permission = await prisma.permission.findFirst({
        where: { name: permData.name }
      });

      if (permission) {
        const existingAssignment = await prisma.rolePermission.findFirst({
          where: {
            roleTypeId: adminRoleType.id,
            permissionId: permission.id
          }
        });

        if (!existingAssignment) {
          await prisma.rolePermission.create({
            data: {
              roleTypeId: adminRoleType.id,
              permissionId: permission.id,
              granted: true
            }
          });
          console.log(`✅ Assegnato permesso al ruolo ADMIN: ${permission.name}`);
          assignedCount++;
        }
      }
    }

    console.log(`Permessi assegnati al ruolo ADMIN: ${assignedCount}`);

    // 8. Verifica finale
    console.log('\n7. Verifica finale...');
    const finalAdminRoleType = await prisma.roleType.findFirst({
      where: { name: 'ADMIN' },
      include: {
        rolePermissions: {
          include: {
            permission: true
          }
        }
      }
    });

    const cmsFormPerms = finalAdminRoleType.rolePermissions.filter(rp => 
      rp.permission.name.includes('CMS') || 
      rp.permission.name.includes('FORM') || 
      rp.permission.name.includes('TEMPLATE') || 
      rp.permission.name.includes('SUBMISSION')
    );

    console.log(`✅ Ruolo ADMIN ora ha ${cmsFormPerms.length} permessi CMS/Form:`);
    cmsFormPerms.forEach(rp => {
      console.log(`- ${rp.permission.name} (granted: ${rp.granted})`);
    });

    console.log('\n🎉 Risoluzione completata!');
    console.log('\n📋 Prossimi passi:');
    console.log('1. Effettua logout e login per aggiornare i permessi');
    console.log('2. Verifica accesso alle pagine CMS e Form');
    console.log('3. Se il problema persiste, verifica la mappatura frontend');

  } catch (error) {
    console.error('❌ Errore durante la risoluzione:', error);
  } finally {
    await prisma.$disconnect();
  }
}

main().catch(console.error);