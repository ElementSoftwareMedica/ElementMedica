const fetch = require('node-fetch');

async function debugPermissions() {
  try {
    console.log('🔍 Debug Permessi Admin - Test Rapido');
    console.log('=====================================\n');

    // 1. Login come admin
    console.log('1️⃣ Login come admin...');
    const loginResponse = await fetch('http://localhost:4001/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      throw new Error(`Login failed: ${loginResponse.status}`);
    }

    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login successful');

    // 2. Ottieni permessi utente
    console.log('\n2️⃣ Recupero permessi utente...');
    const permissionsResponse = await fetch('http://localhost:4001/api/auth/permissions', {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!permissionsResponse.ok) {
      throw new Error(`Permissions failed: ${permissionsResponse.status}`);
    }

    const permissionsData = await permissionsResponse.json();
    console.log('✅ Permessi recuperati');

    // 3. Controlla permessi specifici problematici
    console.log('\n3️⃣ Controllo permessi problematici...');
    const problematicPermissions = [
      'VIEW_FORM_TEMPLATES',
      'CREATE_FORM_TEMPLATES', 
      'EDIT_FORM_TEMPLATES',
      'DELETE_FORM_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS',
      'CREATE_FORM_SUBMISSIONS',
      'EDIT_FORM_SUBMISSIONS', 
      'DELETE_FORM_SUBMISSIONS',
      'VIEW_CMS',
      'CREATE_CMS',
      'EDIT_CMS',
      'DELETE_CMS',
      'MANAGE_PUBLIC_CONTENT',
      'READ_PUBLIC_CONTENT'
    ];

    problematicPermissions.forEach(perm => {
      const hasPermission = permissionsData.permissions && permissionsData.permissions[perm] === true;
      console.log(`   ${perm}: ${hasPermission ? '✅' : '❌'}`);
    });

    // 4. Test chiamate API specifiche
    console.log('\n4️⃣ Test chiamate API...');
    
    // Test entità disponibili
    try {
      const entitiesResponse = await fetch('http://localhost:4001/api/v1/advanced-permissions/entities', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (entitiesResponse.ok) {
        const entitiesData = await entitiesResponse.json();
        console.log(`   Entità disponibili: ${entitiesData.entities ? entitiesData.entities.length : 0}`);
        
        // Controlla se le entità problematiche sono presenti
        const problematicEntities = ['form_templates', 'form_submissions', 'public_cms', 'courses'];
        problematicEntities.forEach(entityName => {
          const exists = entitiesData.entities && entitiesData.entities.find(e => e.name === entityName);
          console.log(`   ${entityName}: ${exists ? '✅ Trovata' : '❌ Mancante'}`);
        });
      } else {
        console.log(`   ❌ Errore entità: ${entitiesResponse.status}`);
      }
    } catch (error) {
      console.log(`   ❌ Errore entità: ${error.message}`);
    }

    // Test permessi ruolo admin
    try {
      const rolePermissionsResponse = await fetch('http://localhost:4001/api/v1/advanced-permissions/roles/Admin/permissions', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (rolePermissionsResponse.ok) {
        const rolePermissionsData = await rolePermissionsResponse.json();
        console.log(`   Permessi ruolo Admin: ${rolePermissionsData.permissions ? rolePermissionsData.permissions.length : 0}`);
        
        // Controlla permessi specifici per le entità problematiche
        const entityPermissions = {
          'form_templates': rolePermissionsData.permissions ? rolePermissionsData.permissions.filter(p => p.entity === 'form_templates') : [],
          'form_submissions': rolePermissionsData.permissions ? rolePermissionsData.permissions.filter(p => p.entity === 'form_submissions') : [],
          'public_cms': rolePermissionsData.permissions ? rolePermissionsData.permissions.filter(p => p.entity === 'public_cms') : []
        };

        Object.entries(entityPermissions).forEach(([entity, perms]) => {
          console.log(`   ${entity}: ${perms.length} permessi`);
          perms.forEach(p => console.log(`     - ${p.action} (${p.scope})`));
        });
      } else {
        console.log(`   ❌ Errore permessi ruolo: ${rolePermissionsResponse.status}`);
      }
    } catch (error) {
      console.log(`   ❌ Errore permessi ruolo: ${error.message}`);
    }

    console.log('\n✅ Debug completato');

  } catch (error) {
    console.error('❌ Errore durante il debug:', error);
  }
}

debugPermissions();