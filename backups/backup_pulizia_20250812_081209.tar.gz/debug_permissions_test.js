// Test per verificare il problema dei permessi che non vengono salvati
// Questo script simula il salvataggio e il caricamento dei permessi

const testPermissions = [
  {
    permissionId: "VIEW_FORM_TEMPLATES",
    granted: true,
    scope: "all",
    tenantIds: [],
    fieldRestrictions: []
  },
  {
    permissionId: "CREATE_FORM_TEMPLATES", 
    granted: true,
    scope: "all",
    tenantIds: [],
    fieldRestrictions: []
  },
  {
    permissionId: "VIEW_FORM_SUBMISSIONS",
    granted: true,
    scope: "all", 
    tenantIds: [],
    fieldRestrictions: []
  },
  {
    permissionId: "VIEW_PUBLIC_CMS",
    granted: true,
    scope: "all",
    tenantIds: [],
    fieldRestrictions: []
  }
];

console.log("🔧 Original permissions:", testPermissions);

// Simula la normalizzazione del backend
const normalizedPermissions = testPermissions.map(perm => ({
  ...perm,
  permissionId: perm.permissionId.trim().toUpperCase()
}));

console.log("🔧 Normalized permissions (backend):", normalizedPermissions);

// Simula quello che viene salvato nel database
const savedPermissions = normalizedPermissions.map(perm => ({
  permission: perm.permissionId, // Il campo nel database si chiama 'permission'
  isGranted: perm.granted,
  scope: perm.scope
}));

console.log("🔧 Saved in database:", savedPermissions);

// Simula quello che viene restituito dall'API
const returnedPermissions = savedPermissions
  .filter(perm => perm.isGranted)
  .map(perm => ({
    permissionId: perm.permission, // Riconverte da 'permission' a 'permissionId'
    granted: perm.isGranted,
    scope: perm.scope,
    tenantIds: [],
    fieldRestrictions: []
  }));

console.log("🔧 Returned by API:", returnedPermissions);

// Simula quello che il frontend cerca
const frontendExpectedPermissions = [
  "VIEW_FORM_TEMPLATES",
  "CREATE_FORM_TEMPLATES", 
  "VIEW_FORM_SUBMISSIONS",
  "VIEW_PUBLIC_CMS"
];

console.log("🔧 Frontend expects:", frontendExpectedPermissions);

// Verifica corrispondenza
const matches = frontendExpectedPermissions.map(expected => {
  const found = returnedPermissions.find(returned => returned.permissionId === expected);
  return {
    expected,
    found: !!found,
    returned: found?.permissionId
  };
});

console.log("🔧 Matches:", matches);

// Identifica problemi
const problems = matches.filter(match => !match.found);
if (problems.length > 0) {
  console.log("❌ Problems found:", problems);
} else {
  console.log("✅ All permissions match correctly");
}