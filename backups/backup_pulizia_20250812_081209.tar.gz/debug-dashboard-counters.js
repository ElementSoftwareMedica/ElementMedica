import axios from 'axios';
import fs from 'fs';

const API_BASE = 'http://localhost:4003/api';

async function debugDashboardCounters() {
  try {
    console.log('🔍 Debug Dashboard Counters');
    console.log('==========================');
    
    // Leggi il token
    const token = fs.readFileSync('temp_token.txt', 'utf8').trim();
    console.log('🔑 Token:', token.substring(0, 50) + '...');
    
    // Test login status
    console.log('\n1. Testing authentication...');
    let userInfo = null;
    try {
      const authResponse = await axios.get(`${API_BASE}/auth/me`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Authentication successful');
      userInfo = authResponse.data;
      console.log('👤 User:', userInfo.email || userInfo.user?.email);
      console.log('🏢 Tenant ID:', userInfo.tenantId || userInfo.user?.tenantId);
      console.log('🔐 Roles:', userInfo.roles?.map(r => r.name || r.roleType).join(', ') || userInfo.user?.roles?.map(r => r.name || r.roleType).join(', '));
      console.log('📋 Full user data:', JSON.stringify(userInfo, null, 2));
    } catch (error) {
      console.log('❌ Authentication failed:', error.response?.data || error.message);
      return;
    }
    
    // Test permissions
    console.log('\n1.5. Testing permissions...');
    try {
      const permissionsResponse = await axios.get(`${API_BASE}/auth/permissions`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Permissions endpoint successful');
      console.log('🔐 Permissions:', permissionsResponse.data);
    } catch (error) {
      console.log('❌ Permissions endpoint failed:', error.response?.data || error.message);
    }
    
    // Test counters endpoint
    console.log('\n2. Testing /api/counters endpoint...');
    try {
      const countersResponse = await axios.get(`${API_BASE}/counters`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Counters endpoint successful');
      console.log('📊 Response:', countersResponse.data);
    } catch (error) {
      console.log('❌ Counters endpoint failed:', error.response?.data || error.message);
    }
    
    // Test companies endpoint
    console.log('\n3. Testing /api/companies endpoint...');
    try {
      const companiesResponse = await axios.get(`${API_BASE}/companies`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Companies endpoint successful');
      console.log('🏢 Companies count:', companiesResponse.data?.length || 0);
      console.log('🏢 Companies:', companiesResponse.data?.map(c => c.ragioneSociale || c.name).slice(0, 3));
    } catch (error) {
      console.log('❌ Companies endpoint failed:', error.response?.data || error.message);
    }
    
    // Test persons endpoint
    console.log('\n4. Testing /api/persons endpoint...');
    try {
      const personsResponse = await axios.get(`${API_BASE}/persons`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Persons endpoint successful');
      console.log('📋 Full response:', JSON.stringify(personsResponse.data, null, 2));
      
      const persons = personsResponse.data?.persons || personsResponse.data || [];
      console.log('👥 Persons count:', persons.length);
      
      if (persons.length > 0) {
        // Filtra per dipendenti (ruoli "Responsabile Aziendale" o inferiori)
        const employees = persons.filter(person => {
          const roles = person.roles || [];
          return roles.some(role => 
            role.roleType === 'EMPLOYEE' || 
            role.roleType === 'COMPANY_ADMIN' ||
            role.name === 'Dipendente' || 
            role.name === 'Responsabile Aziendale' ||
            role.name === 'Employee' ||
            role.name === 'Company Manager'
          );
        });
        
        console.log('👥 Employees count (filtered):', employees.length);
        console.log('👥 All roles found:', [...new Set(persons.flatMap(p => p.roles?.map(r => r.roleType || r.name) || []))]);
        console.log('👥 Sample person:', persons[0]);
      }
    } catch (error) {
      console.log('❌ Persons endpoint failed:', error.response?.data || error.message);
    }
    
    // Test tenant info
    console.log('\n5. Testing tenant info...');
    try {
      const tenantResponse = await axios.get(`${API_BASE}/tenant/current`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      console.log('✅ Tenant endpoint successful');
      console.log('🏢 Current tenant:', tenantResponse.data);
    } catch (error) {
      console.log('❌ Tenant endpoint failed:', error.response?.data || error.message);
    }
    
  } catch (error) {
    console.error('❌ Debug failed:', error.message);
  }
}

debugDashboardCounters();