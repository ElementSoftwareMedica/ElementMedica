# PLANNING GESTIONE UTENTI E RUOLI

## OBIETTIVI

### 🎯 PAGINA USERS
- ✅ Visualizzare tutte le `Person` ordinate per login più recente
- ✅ Generazione automatica username (`nome.cognome` + contatore per omonimie)
- ✅ Password di default "Password123!"
- ✅ Utilizzo endpoint corretto `/api/persons`

### 🎯 PAGINA ROLES
- 🔄 Layout a due sezioni:
  - **Sinistra**: Gestione ruoli (rinomina, aggiungi, elimina)
  - **Destra**: Selezione granulare permessi e tenant per ogni ruolo
- 🔄 Permessi granulari per entità e azioni
- 🔄 Controllo accesso dati specifico per ruolo (es. formatore vede solo i suoi corsi)

## STATO ATTUALE

### ✅ PROBLEMI RISOLTI
1. **✅ Endpoint Corretto**: Aggiornato `users.ts` per utilizzare `/api/persons` invece di `/api/users`
2. **✅ Route Complete**: Aggiunte tutte le route necessarie in `person-routes.js`
3. **✅ Controller Completo**: Implementati tutti i metodi mancanti in `personController.js`
4. **✅ Service Completo**: Implementati tutti i metodi mancanti in `personService.js`
5. **✅ Eliminazione Multipla**: Implementato endpoint `/api/persons/bulk` per eliminazione multipla utenti
6. **🔄 Ordinamento lastLogin**: Implementato ordinamento separato per utenti con/senza lastLogin (in corso di test)

### ✅ FUNZIONALITÀ IMPLEMENTATE
- ✅ `personService.createPerson()` genera automaticamente username (`nome.cognome` + contatore) e password (`Password123!`)
- ✅ `personController.getPersons()` ordina per `lastLogin` di default (più recente prima)
- ✅ `UsersTab.tsx` utilizza gli endpoint corretti e mostra ordinamento per lastLogin
- ✅ Ordinamento per `lastLogin` implementato con paginazione
- ✅ Endpoint per statistiche, export/import CSV, verifica disponibilità username/email
- ✅ Reset password e toggle status utenti
- ✅ Eliminazione multipla utenti con endpoint bulk
- ✅ Sistema di ruoli già implementato con layout a due sezioni funzionante

## PIANO DI IMPLEMENTAZIONE

### FASE 1: ✅ CORREZIONE ENDPOINT UTENTI
- ✅ Modificare `src/services/users.ts` per utilizzare `/api/persons`
- ✅ Aggiungere endpoint mancanti in `backend/routes/person-routes.js`
- ✅ Implementare metodi mancanti in `backend/controllers/personController.js`
- ✅ Implementare metodi mancanti in `backend/services/personService.js`

### FASE 2: 🔄 IMPLEMENTAZIONE LAYOUT ROLES
- 🔄 Modificare `RolesTab.tsx` per layout a due sezioni
- 🔄 Sezione sinistra: lista ruoli con azioni CRUD
- 🔄 Sezione destra: configurazione permessi granulari
- 🔄 Implementare stato condiviso tra le due sezioni

### FASE 3: 🔄 SISTEMA PERMESSI GRANULARI
- 🔄 Definire struttura permessi per entità (Person, Company, Course, etc.)
- 🔄 Implementare azioni granulari (create, read, update, delete, manage)
- 🔄 Aggiungere controllo tenant-specific
- 🔄 Implementare filtri dati basati su ruolo

### FASE 4: 🔄 TEST E VALIDAZIONE
- 🔄 Test creazione utenti con username/password automatici
- 🔄 Test ordinamento per lastLogin
- 🔄 Test gestione ruoli e permessi
- 🔄 Validazione conformità GDPR
- 🔄 Test permessi granulari per diversi scenari

## PROSSIMI PASSI

1. **🔄 ATTUALE**: Implementare layout a due sezioni per RolesTab
2. **⏳ SUCCESSIVO**: Sviluppare sistema permessi granulari
3. **⏳ FUTURO**: Test completi e validazione

## NOTE TECNICHE

### Conformità GDPR
- Rispettare regole in `.trae/rules/project-rules`
- Limitare accesso dati sensibili (es. residenza dipendenti)
- Implementare audit log per modifiche permessi

### Esempi Permessi Granulari
- **Admin**: Accesso completo a tutti i dati
- **Formatore**: 
  - Vede solo corsi dove è docente
  - Accesso limitato info dipendenti dei suoi corsi
  - Info aziende limitate (no dati sensibili)
- **Manager Aziendale**: 
  - Vede solo dipendenti della sua azienda
  - Gestisce corsi della sua azienda
  - Accesso completo dati azienda

### Architettura Permessi
```
Permission {
  entity: 'person' | 'company' | 'course' | 'tenant'
  action: 'create' | 'read' | 'update' | 'delete' | 'manage'
  scope: 'all' | 'own' | 'company' | 'tenant'
  fields?: string[] // campi specifici accessibili
}
```

---
*Ultimo aggiornamento: $(date)*
*Stato: Fase 1 completata, iniziando Fase 2*