// Script per testare i permessi direttamente nel browser
// Eseguire nella console del browser dopo aver fatto login

console.log('🔍 Test Permessi - Analisi Dettagliata');
console.log('=====================================');

// Verifica se AuthContext è disponibile
if (typeof window.authContextForTesting !== 'undefined') {
  const auth = window.authContextForTesting;
  
  console.log('✅ AuthContext disponibile');
  console.log('👤 Utente:', auth.user?.email);
  console.log('🔐 Autenticato:', auth.isAuthenticated);
  console.log('📊 Numero permessi:', Object.keys(auth.permissions || {}).length);
  
  // Mostra tutti i permessi disponibili
  console.log('\n📋 TUTTI I PERMESSI DISPONIBILI:');
  console.log('================================');
  Object.keys(auth.permissions || {}).forEach(permission => {
    console.log(`  ✓ ${permission}`);
  });

  // Test permessi specifici per le pagine che non funzionano
  console.log('\n🧪 TEST PERMESSI SPECIFICI:');
  console.log('===========================');
  
  // Test PUBLIC_CMS
  console.log('\n🏛️ PUBLIC_CMS:');
  const cmsRead = auth.hasPermission('PUBLIC_CMS', 'READ');
  const cmsUpdate = auth.hasPermission('PUBLIC_CMS', 'UPDATE');
  console.log(`  PUBLIC_CMS:READ = ${cmsRead}`);
  console.log(`  PUBLIC_CMS:UPDATE = ${cmsUpdate}`);
  
  // Test form_templates
  console.log('\n📝 FORM_TEMPLATES:');
  const templatesRead = auth.hasPermission('form_templates', 'read');
  const templatesCreate = auth.hasPermission('form_templates', 'create');
  const templatesUpdate = auth.hasPermission('form_templates', 'update');
  const templatesDelete = auth.hasPermission('form_templates', 'delete');
  console.log(`  form_templates:read = ${templatesRead}`);
  console.log(`  form_templates:create = ${templatesCreate}`);
  console.log(`  form_templates:update = ${templatesUpdate}`);
  console.log(`  form_templates:delete = ${templatesDelete}`);
  
  // Test form_submissions
  console.log('\n📊 FORM_SUBMISSIONS:');
  const submissionsRead = auth.hasPermission('form_submissions', 'read');
  const submissionsUpdate = auth.hasPermission('form_submissions', 'update');
  const submissionsDelete = auth.hasPermission('form_submissions', 'delete');
  const submissionsExport = auth.hasPermission('form_submissions', 'export');
  console.log(`  form_submissions:read = ${submissionsRead}`);
  console.log(`  form_submissions:update = ${submissionsUpdate}`);
  console.log(`  form_submissions:delete = ${submissionsDelete}`);
  console.log(`  form_submissions:export = ${submissionsExport}`);
  
  // Test permessi backend diretti
  console.log('\n🔧 PERMESSI BACKEND DIRETTI:');
  console.log('============================');
  const backendPermissions = [
    'VIEW_CMS',
    'MANAGE_PUBLIC_CONTENT',
    'VIEW_FORM_TEMPLATES',
    'MANAGE_FORM_TEMPLATES',
    'VIEW_FORM_SUBMISSIONS',
    'MANAGE_FORM_SUBMISSIONS'
  ];
  
  backendPermissions.forEach(permission => {
    const hasIt = auth.permissions[permission] === true;
    console.log(`  ${permission} = ${hasIt}`);
  });
  
  // Verifica conversione permessi
  console.log('\n🔄 VERIFICA CONVERSIONE:');
  console.log('========================');
  
  // Cerca permessi che potrebbero essere mappati male
  const cmsPermissions = Object.keys(auth.permissions).filter(p => 
    p.includes('CMS') || p.includes('PUBLIC') || p.includes('CONTENT')
  );
  console.log('Permessi CMS trovati:', cmsPermissions);
  
  const formPermissions = Object.keys(auth.permissions).filter(p => 
    p.includes('FORM') || p.includes('TEMPLATE') || p.includes('SUBMISSION')
  );
  console.log('Permessi Form trovati:', formPermissions);
  
} else {
  console.error('❌ AuthContext non disponibile. Assicurati di:');
  console.error('1. Aver fatto login');
  console.error('2. Essere su una pagina del frontend privato');
  console.error('3. Che AuthContext sia esposto per il testing');
}

console.log('\n📝 ISTRUZIONI:');
console.log('==============');
console.log('1. Fai login con admin@example.com / Admin123!');
console.log('2. Vai su una pagina del frontend privato');
console.log('3. Apri la console del browser (F12)');
console.log('4. Incolla questo script e premi Invio');
console.log('5. Analizza i risultati per identificare il problema');