const fetch = require('node-fetch');

const API_BASE = 'http://localhost:4001';

async function testUserPermissions() {
  console.log('🔍 Test Permessi Utente Admin');
  console.log('============================');

  try {
    // Step 1: Login
    console.log('\n📝 Step 1: Login...');
    const loginResponse = await fetch(`${API_BASE}/api/v1/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      throw new Error(`Login failed: ${loginResponse.status} ${loginResponse.statusText}`);
    }

    const loginData = await loginResponse.json();
    console.log('✅ Login successful');
    console.log('   Full response:', JSON.stringify(loginData, null, 2));
    console.log('   User:', loginData.user?.email);
    console.log('   Role:', loginData.user?.role);
    
    const token = loginData.token || loginData.accessToken || loginData.access_token || loginData.tokens?.access_token;
    if (!token) {
      console.log('❌ No token found in response. Available keys:', Object.keys(loginData));
      throw new Error('No token received');
    }
    console.log('   Token found:', token.substring(0, 20) + '...');

    // Step 2: Get User Info with Permissions
    console.log('\n🔍 Step 2: Get User Info with Permissions');
    const userInfoResponse = await fetch('http://localhost:4001/api/v1/auth/me', {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    });

    if (!userInfoResponse.ok) {
        throw new Error(`User info failed: ${userInfoResponse.status} ${userInfoResponse.statusText}`);
    }

    const userInfoData = await userInfoResponse.json();
    console.log('✅ User info retrieved successfully');
    console.log('   User:', userInfoData.email, 'Role:', userInfoData.role);
    console.log('   Permissions:', JSON.stringify(userInfoData.permissions, null, 2));
    
    // Mostra i permessi backend
    const backendPermissions = userInfoData.permissions || {};
    const grantedBackendPermissions = Object.keys(backendPermissions).filter(key => backendPermissions[key] === true);
    console.log('   Granted backend permissions:', grantedBackendPermissions);

    // Step 3: Simulate Frontend Permission Conversion
    console.log('\n🔧 Step 3: Simulate Frontend Permission Conversion');
    
    // Simula la conversione dei permessi come fa il frontend
    const frontendPermissions = new Set();
    
    // Aggiungi i permessi backend direttamente
    Object.keys(userInfoData.permissions || {}).forEach(permission => {
        if (userInfoData.permissions[permission]) {
            frontendPermissions.add(permission);
        }
    });

    // Step 4: Simula la conversione frontend
    console.log('\n📝 Step 4: Simulate Frontend Conversion...');
    
    // Simula la funzione convertBackendToFrontendPermissions
    function convertBackendToFrontendPermissions(backendPermissions) {
      const frontendPermissions = {};
      
      // Mantieni i permessi backend originali
      Object.keys(backendPermissions).forEach(key => {
        if (backendPermissions[key] === true) {
          frontendPermissions[key] = true;
        }
      });
      
      // Aggiungi le mappature frontend
      Object.keys(backendPermissions).forEach(backendKey => {
        if (backendPermissions[backendKey] === true) {
          // Caso speciale per MANAGE_PUBLIC_CMS
          if (backendKey === 'MANAGE_PUBLIC_CMS') {
            frontendPermissions['PUBLIC_CMS:READ'] = true;
            frontendPermissions['PUBLIC_CMS:CREATE'] = true;
            frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
            frontendPermissions['PUBLIC_CMS:DELETE'] = true;
            frontendPermissions['PUBLIC_CMS:read'] = true;
            frontendPermissions['PUBLIC_CMS:create'] = true;
            frontendPermissions['PUBLIC_CMS:update'] = true;
            frontendPermissions['PUBLIC_CMS:delete'] = true;
          }
          // Altri permessi CMS
          else if (backendKey === 'VIEW_PUBLIC_CMS') {
            frontendPermissions['PUBLIC_CMS:READ'] = true;
            frontendPermissions['PUBLIC_CMS:read'] = true;
          }
          else if (backendKey === 'CREATE_PUBLIC_CMS') {
            frontendPermissions['PUBLIC_CMS:CREATE'] = true;
            frontendPermissions['PUBLIC_CMS:create'] = true;
          }
          else if (backendKey === 'EDIT_PUBLIC_CMS') {
            frontendPermissions['PUBLIC_CMS:UPDATE'] = true;
            frontendPermissions['PUBLIC_CMS:update'] = true;
          }
          else if (backendKey === 'DELETE_PUBLIC_CMS') {
            frontendPermissions['PUBLIC_CMS:DELETE'] = true;
            frontendPermissions['PUBLIC_CMS:delete'] = true;
          }
          // Permessi FORM_TEMPLATES
          else if (backendKey === 'MANAGE_FORM_TEMPLATES') {
            frontendPermissions['form_templates:read'] = true;
            frontendPermissions['form_templates:view'] = true;
            frontendPermissions['form_templates:create'] = true;
            frontendPermissions['form_templates:edit'] = true;
            frontendPermissions['form_templates:update'] = true;
            frontendPermissions['form_templates:delete'] = true;
          }
          // Permessi FORM_SUBMISSIONS
          else if (backendKey === 'MANAGE_FORM_SUBMISSIONS') {
            frontendPermissions['form_submissions:read'] = true;
            frontendPermissions['form_submissions:view'] = true;
            frontendPermissions['form_submissions:create'] = true;
            frontendPermissions['form_submissions:edit'] = true;
            frontendPermissions['form_submissions:update'] = true;
            frontendPermissions['form_submissions:delete'] = true;
          }
        }
      });
      
      return frontendPermissions;
    }

    const convertedPermissions = convertBackendToFrontendPermissions(backendPermissions);
    const grantedFrontendPermissions = Object.keys(convertedPermissions).filter(key => convertedPermissions[key] === true);
    console.log('✅ Frontend conversion completed');
    console.log('   Frontend permissions count:', grantedFrontendPermissions.length);
    console.log('   Granted frontend permissions:', grantedFrontendPermissions);

    // Step 4: Test specific permissions
    console.log('\n📝 Step 4: Test Specific Permissions...');
    
    const permissionsToTest = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE',
      'PUBLIC_CMS:read',
      'PUBLIC_CMS:update',
      'form_templates:read',
      'form_templates:create',
      'form_submissions:read',
      'form_submissions:view'
    ];

    permissionsToTest.forEach(permission => {
      const hasPermission = convertedPermissions[permission] === true;
      console.log(`   ${hasPermission ? '✅' : '❌'} ${permission}: ${hasPermission}`);
    });

    // Step 5: Simula hasPermission function
    console.log('\n📝 Step 5: Simulate hasPermission Function...');
    
    function simulateHasPermission(resourceOrPermission, action, permissions = convertedPermissions) {
      let permissionToCheck;
      
      if (action) {
        // Formato con due parametri: resource e action
        permissionToCheck = `${resourceOrPermission}:${action}`;
        console.log(`   🔐 Checking permission (two params): ${resourceOrPermission}:${action}`);
      } else {
        // Formato con un parametro: permesso diretto
        permissionToCheck = resourceOrPermission;
        console.log(`   🔐 Checking permission (single param): ${resourceOrPermission}`);
      }
      
      // Verifica permesso diretto
      if (permissions[permissionToCheck] === true) {
        console.log(`   ✅ Access granted: user has ${permissionToCheck} permission (direct match)`);
        return true;
      }
      
      // Se abbiamo due parametri, prova anche altri formati
      if (action) {
        // Verifica permesso all:* (permesso universale)
        if (permissions['all:' + action] === true) {
          console.log('   ✅ Access granted: user has all:' + action + ' permission');
          return true;
        }
        
        // Verifica permesso resource:all (permesso per tutte le azioni sulla risorsa)
        if (permissions[resourceOrPermission + ':all'] === true) {
          console.log('   ✅ Access granted: user has ' + resourceOrPermission + ':all permission');
          return true;
        }
        
        // Concedi accesso se c'è almeno un permesso con quel resource per azioni 'read'
        if (action === 'read') {
          const resourcePermissions = Object.keys(permissions)
            .filter(key => key.startsWith(resourceOrPermission + ':') && permissions[key] === true);
          
          console.log(`   🔍 Found ${resourcePermissions.length} permissions for resource '${resourceOrPermission}':`, resourcePermissions);
          
          if (resourcePermissions.length > 0) {
            console.log('   ✅ Access granted: user has some permission for ' + resourceOrPermission);
            return true;
          }
        }
      }
      
      console.log(`   ❌ Permission check result: false for ${permissionToCheck}`);
      return false;
    }

    // Test i permessi che usa PublicCMSPage
    console.log('\n   Testing PublicCMSPage permissions:');
    const canView = simulateHasPermission('PUBLIC_CMS', 'READ');
    const canEdit = simulateHasPermission('PUBLIC_CMS', 'UPDATE');
    
    console.log(`   📄 PublicCMSPage canView: ${canView}`);
    console.log(`   📄 PublicCMSPage canEdit: ${canEdit}`);

    // Test anche con lowercase
    console.log('\n   Testing with lowercase actions:');
    const canViewLower = simulateHasPermission('PUBLIC_CMS', 'read');
    const canEditLower = simulateHasPermission('PUBLIC_CMS', 'update');
    
    console.log(`   📄 PublicCMSPage canView (lowercase): ${canViewLower}`);
    console.log(`   📄 PublicCMSPage canEdit (lowercase): ${canEditLower}`);

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.stack) {
      console.error('Stack trace:', error.stack);
    }
  }
}

// Esegui il test
testUserPermissions();