const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function checkAdminPermissions() {
  try {
    // Trova l'admin
    const admin = await prisma.person.findFirst({
      where: { email: 'admin@example.com' },
      include: {
        personRoles: {
          include: {
            role: {
              include: {
                rolePermissions: {
                  include: {
                    permission: true
                  }
                }
              }
            }
          }
        }
      }
    });

    if (!admin) {
      console.log('❌ Admin non trovato');
      return;
    }

    console.log('✅ Admin trovato:', admin.email);
    console.log('Ruoli:', admin.personRoles.length);

    // Raccogli tutti i permessi
    const allPermissions = new Set();
    admin.personRoles.forEach(personRole => {
      personRole.role.rolePermissions.forEach(rolePermission => {
        if (rolePermission.granted) {
          allPermissions.add(rolePermission.permission.permissionId);
        }
      });
    });

    console.log('\n📊 Totale permessi:', allPermissions.size);
    
    // Filtra permessi CMS e Form
    const cmsPermissions = Array.from(allPermissions).filter(p => 
      p.includes('CMS') || p.includes('PUBLIC_CONTENT')
    );
    const formPermissions = Array.from(allPermissions).filter(p => 
      p.includes('FORM') || p.includes('SUBMISSION')
    );

    console.log('\n🎨 Permessi CMS:', cmsPermissions.length);
    cmsPermissions.forEach(p => console.log('  -', p));

    console.log('\n📝 Permessi Form:', formPermissions.length);
    formPermissions.forEach(p => console.log('  -', p));

    // Verifica permessi specifici
    const requiredPermissions = [
      'VIEW_PUBLIC_CMS', 'EDIT_PUBLIC_CMS', 'MANAGE_PUBLIC_CMS',
      'VIEW_FORM_TEMPLATES', 'EDIT_FORM_TEMPLATES', 'MANAGE_FORM_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS', 'EDIT_FORM_SUBMISSIONS', 'MANAGE_FORM_SUBMISSIONS'
    ];

    console.log('\n🔍 Verifica permessi richiesti:');
    requiredPermissions.forEach(perm => {
      const hasIt = allPermissions.has(perm);
      console.log('  ' + (hasIt ? '✅' : '❌') + ' ' + perm);
    });

  } catch (error) {
    console.error('❌ Errore:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

checkAdminPermissions();