import { PrismaClient } from '@prisma/client';
import axios from 'axios';

const prisma = new PrismaClient();

async function testDeleteFunctionality() {
  try {
    console.log('🧪 Test eliminazione dipendenti...\n');

    // 1. Login per ottenere il token
    console.log('1. Effettuo login...');
    const loginResponse = await axios.post('http://localhost:4001/api/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    if (!loginResponse.data?.data?.accessToken) {
      console.error('❌ Login fallito');
      return;
    }

    const token = loginResponse.data.data.accessToken;
    console.log('✅ Login riuscito');

    // 2. Ottieni la lista delle persone prima dell'eliminazione
    console.log('\n2. Ottengo lista persone prima dell\'eliminazione...');
    const beforeResponse = await axios.get('http://localhost:4001/api/v1/persons?page=1&limit=10', {
      headers: { Authorization: `Bearer ${token}` }
    });

    const personsBefore = beforeResponse.data.persons || [];
    console.log(`✅ Trovate ${personsBefore.length} persone`);

    if (personsBefore.length === 0) {
      console.log('❌ Nessuna persona trovata per il test');
      return;
    }

    // 3. Seleziona una persona da eliminare (non l'admin)
    const personToDelete = personsBefore.find(p => p.email !== 'admin@example.com');
    if (!personToDelete) {
      console.log('❌ Nessuna persona disponibile per l\'eliminazione (solo admin trovato)');
      return;
    }

    console.log(`\n3. Elimino la persona: ${personToDelete.firstName} ${personToDelete.lastName} (${personToDelete.email})`);

    // 4. Elimina la persona
    const deleteResponse = await axios.delete(`http://localhost:4001/api/v1/persons/${personToDelete.id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    console.log('✅ Richiesta di eliminazione inviata:', deleteResponse.data);

    // 5. Verifica nel database che deletedAt sia impostato
    console.log('\n4. Verifico nel database...');
    const deletedPerson = await prisma.person.findUnique({
      where: { id: personToDelete.id },
      select: { id: true, firstName: true, lastName: true, email: true, deletedAt: true, status: true }
    });

    if (deletedPerson?.deletedAt) {
      console.log('✅ Record marcato come eliminato nel database:', {
        id: deletedPerson.id,
        name: `${deletedPerson.firstName} ${deletedPerson.lastName}`,
        email: deletedPerson.email,
        deletedAt: deletedPerson.deletedAt,
        status: deletedPerson.status
      });
    } else {
      console.log('❌ Record NON marcato come eliminato nel database');
    }

    // 6. Ottieni la lista delle persone dopo l'eliminazione
    console.log('\n5. Ottengo lista persone dopo l\'eliminazione...');
    const afterResponse = await axios.get('http://localhost:4001/api/v1/persons?page=1&limit=10', {
      headers: { Authorization: `Bearer ${token}` }
    });

    const personsAfter = afterResponse.data.persons || [];
    console.log(`✅ Trovate ${personsAfter.length} persone`);

    // 7. Verifica che la persona eliminata non sia più nella lista
    const stillVisible = personsAfter.find(p => p.id === personToDelete.id);
    if (stillVisible) {
      console.log('❌ PROBLEMA: La persona eliminata è ancora visibile nella lista!');
    } else {
      console.log('✅ SUCCESSO: La persona eliminata non è più visibile nella lista');
    }

    console.log(`\n📊 Riepilogo:
- Persone prima: ${personsBefore.length}
- Persone dopo: ${personsAfter.length}
- Differenza: ${personsBefore.length - personsAfter.length}
- Eliminazione riuscita: ${!stillVisible ? '✅ SÌ' : '❌ NO'}`);

  } catch (error) {
    console.error('❌ Errore durante il test:', error.response?.data || error.message);
  } finally {
    await prisma.$disconnect();
  }
}

testDeleteFunctionality();