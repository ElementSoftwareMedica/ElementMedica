#!/usr/bin/env node

/**
 * Test per verificare il problema dei permessi che non rimangono salvati
 * nei modal di creazione ruoli in settings/roles e settings/hierarchy
 */

import fetch from 'node-fetch';

const API_BASE = 'http://localhost:4001';
const PROXY_BASE = 'http://localhost:4003';

async function testPermissionsIssue() {
  console.log('🔍 Test del problema permessi nei modal ruoli\n');

  try {
    // 1. Login per ottenere token
    console.log('1️⃣ Effettuo login...');
    const loginResponse = await fetch(`${PROXY_BASE}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    if (!loginResponse.ok) {
      throw new Error(`Login fallito: ${loginResponse.status}`);
    }

    const loginData = await loginResponse.json();
    const token = loginData.token;
    console.log('✅ Login effettuato con successo');

    // 2. Carico i permessi attuali del ruolo ADMIN
    console.log('\n2️⃣ Carico permessi attuali del ruolo ADMIN...');
    const currentPermissionsResponse = await fetch(`${PROXY_BASE}/api/roles/ADMIN/permissions`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!currentPermissionsResponse.ok) {
      throw new Error(`Errore caricamento permessi: ${currentPermissionsResponse.status}`);
    }

    const currentPermissionsData = await currentPermissionsResponse.json();
    const currentPermissions = currentPermissionsData.data?.permissions || [];
    console.log(`✅ Caricati ${currentPermissions.length} permessi attuali`);

    // 3. Aggiungo alcuni permessi di test per le nuove entità
    console.log('\n3️⃣ Aggiungo permessi di test per le nuove entità...');
    
    const testPermissions = [
      // Form Templates
      { permissionId: 'VIEW_FORM_TEMPLATES', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'CREATE_FORM_TEMPLATES', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'EDIT_FORM_TEMPLATES', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'DELETE_FORM_TEMPLATES', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      
      // Form Submissions
      { permissionId: 'VIEW_FORM_SUBMISSIONS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'CREATE_FORM_SUBMISSIONS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'EDIT_FORM_SUBMISSIONS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'DELETE_FORM_SUBMISSIONS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      
      // Public CMS
      { permissionId: 'VIEW_PUBLIC_CMS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'CREATE_PUBLIC_CMS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'EDIT_PUBLIC_CMS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'DELETE_PUBLIC_CMS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] },
      { permissionId: 'MANAGE_PUBLIC_CMS', granted: true, scope: 'all', tenantIds: [], fieldRestrictions: [] }
    ];

    // Combino i permessi esistenti con quelli di test
    const allPermissions = [...currentPermissions, ...testPermissions];
    
    console.log(`📝 Salvo ${allPermissions.length} permessi totali (${testPermissions.length} nuovi)`);

    // 4. Salvo i permessi
    const saveResponse = await fetch(`${PROXY_BASE}/api/roles/ADMIN/permissions`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ permissions: allPermissions })
    });

    if (!saveResponse.ok) {
      const errorText = await saveResponse.text();
      throw new Error(`Errore salvataggio: ${saveResponse.status} - ${errorText}`);
    }

    const saveData = await saveResponse.json();
    console.log('✅ Permessi salvati con successo');

    // 5. Attendo un momento e ricarico per verificare la persistenza
    console.log('\n4️⃣ Attendo 2 secondi e ricarico per verificare persistenza...');
    await new Promise(resolve => setTimeout(resolve, 2000));

    const verifyResponse = await fetch(`${PROXY_BASE}/api/roles/ADMIN/permissions`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!verifyResponse.ok) {
      throw new Error(`Errore verifica: ${verifyResponse.status}`);
    }

    const verifyData = await verifyResponse.json();
    const verifiedPermissions = verifyData.data?.permissions || [];
    console.log(`✅ Ricaricati ${verifiedPermissions.length} permessi`);

    // 6. Verifico che i permessi di test siano presenti
    console.log('\n5️⃣ Verifico presenza dei permessi di test...');
    
    const testPermissionIds = testPermissions.map(p => p.permissionId);
    const foundTestPermissions = verifiedPermissions.filter(p => 
      testPermissionIds.includes(p.permissionId) && p.granted
    );

    console.log(`📊 Risultati verifica:`);
    console.log(`   - Permessi di test aggiunti: ${testPermissions.length}`);
    console.log(`   - Permessi di test trovati: ${foundTestPermissions.length}`);
    console.log(`   - Persistenza: ${foundTestPermissions.length === testPermissions.length ? '✅ OK' : '❌ PROBLEMA'}`);

    if (foundTestPermissions.length !== testPermissions.length) {
      console.log('\n❌ PROBLEMA IDENTIFICATO: I permessi non vengono salvati correttamente!');
      console.log('\n📝 Permessi mancanti:');
      const missingPermissions = testPermissionIds.filter(id => 
        !foundTestPermissions.some(p => p.permissionId === id)
      );
      missingPermissions.forEach(id => console.log(`   - ${id}`));
    } else {
      console.log('\n✅ TUTTO OK: I permessi vengono salvati e caricati correttamente');
    }

    // 7. Test specifico per le entità del frontend
    console.log('\n6️⃣ Test specifico per entità del frontend...');
    
    const entityPermissions = {
      'form_templates': foundTestPermissions.filter(p => p.permissionId.includes('FORM_TEMPLATES')),
      'form_submissions': foundTestPermissions.filter(p => p.permissionId.includes('FORM_SUBMISSIONS')),
      'public_cms': foundTestPermissions.filter(p => p.permissionId.includes('PUBLIC_CMS'))
    };

    Object.entries(entityPermissions).forEach(([entity, perms]) => {
      console.log(`   ${entity}: ${perms.length} permessi`);
      perms.forEach(p => console.log(`     - ${p.permissionId}: ${p.granted ? '✅' : '❌'}`));
    });

  } catch (error) {
    console.error('❌ Errore nel test:', error.message);
    process.exit(1);
  }
}

testPermissionsIssue();