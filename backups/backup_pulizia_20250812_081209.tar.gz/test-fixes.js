#!/usr/bin/env node

/**
 * Script di test per verificare le correzioni apportate:
 * 1. Gestione soft delete e ripristino aziende con stessa P.IVA
 * 2. Risposta JSON corretta per DELETE aziende
 * 3. Creazione dipendenti con account e credenziali
 */

import axios from 'axios';

const API_BASE = 'http://localhost:4003/api/v1';
const EMPLOYEES_BASE = 'http://localhost:4001'; // Per endpoint employees senza prefisso
const LOGIN_CREDENTIALS = {
  identifier: 'admin@example.com',
  password: 'Admin123!'
};

let authToken = null;

// Utility per login
async function login() {
  try {
    console.log('🔐 Effettuando login...');
    const response = await axios.post(`${API_BASE}/auth/login`, LOGIN_CREDENTIALS);
    
    if (response.data.success && response.data.tokens.access_token) {
      authToken = response.data.tokens.access_token;
      console.log('✅ Login effettuato con successo');
      return true;
    } else {
      console.error('❌ Login fallito:', response.data);
      return false;
    }
  } catch (error) {
    console.error('❌ Errore durante il login:', error.response?.data || error.message);
    return false;
  }
}

// Utility per chiamate API autenticate
async function apiCall(method, endpoint, data = null, useEmployeesBase = false) {
  try {
    const baseUrl = useEmployeesBase ? EMPLOYEES_BASE : API_BASE;
    const config = {
      method,
      url: `${baseUrl}${endpoint}`,
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    };
    
    if (data) {
      config.data = data;
    }
    
    const response = await axios(config);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data || error.message,
      status: error.response?.status
    };
  }
}

// Test 1: Creazione azienda con P.IVA unica
async function testCreateCompany() {
  console.log('\n📋 Test 1: Creazione azienda con P.IVA unica');
  
  const uniquePiva = `TEST${Date.now()}`;
  const companyData = {
    ragioneSociale: 'Test Company Fixes',
    piva: uniquePiva,
    sedeAzienda: 'Milano',
    mail: 'test@testcompany.com'
  };
  
  const result = await apiCall('POST', '/companies', companyData);
  
  if (result.success) {
    console.log('✅ Azienda creata con successo:', result.data.id);
    return { companyId: result.data.id, piva: uniquePiva };
  } else {
    console.error('❌ Errore creazione azienda:', result.error);
    return null;
  }
}

// Test 2: Eliminazione azienda e verifica risposta JSON
async function testDeleteCompany(companyId) {
  console.log('\n🗑️ Test 2: Eliminazione azienda e verifica risposta JSON');
  
  const result = await apiCall('DELETE', `/companies/${companyId}`);
  
  if (result.success) {
    console.log('✅ Azienda eliminata con successo');
    console.log('✅ Risposta JSON valida ricevuta:', {
      success: result.data.success,
      message: result.data.message,
      deletedAt: result.data.data?.deletedAt
    });
    return true;
  } else {
    console.error('❌ Errore eliminazione azienda:', result.error);
    return false;
  }
}

// Test 3: Ripristino azienda con stessa P.IVA
async function testRestoreCompany(piva) {
  console.log('\n🔄 Test 3: Ripristino azienda con stessa P.IVA');
  
  const companyData = {
    ragioneSociale: 'Test Company Restored',
    piva: piva,
    sedeAzienda: 'Roma', // Dati diversi per verificare sovrascrittura
    mail: 'restored@testcompany.com'
  };
  
  const result = await apiCall('POST', '/companies', companyData);
  
  if (result.success) {
    console.log('✅ Azienda ripristinata e dati sovrascritti con successo');
    console.log('✅ Nuova sede:', result.data.sedeAzienda);
    console.log('✅ Nuova email:', result.data.mail);
    return result.data.id;
  } else {
    console.error('❌ Errore ripristino azienda:', result.error);
    return null;
  }
}

// Test 4: Creazione dipendente con account
async function testCreateEmployee(companyId) {
  console.log('\n👤 Test 4: Creazione dipendente con account');
  
  const employeeData = {
    firstName: 'Mario',
    lastName: 'Rossi',
    email: `mario.rossi.${Date.now()}@testcompany.com`,
    taxCode: `RSSMRA80A01H501${Math.floor(Math.random() * 10)}`,
    phone: '+39123456789',
    companyId: companyId,
    roleType: 'EMPLOYEE'
  };
  
  const result = await apiCall('POST', '/employees', employeeData, true);
  
  if (result.success) {
    console.log('✅ Dipendente creato con successo:', result.data.id);
    console.log('✅ Username generato:', result.data.username);
    console.log('✅ Ruolo assegnato:', result.data.personRoles?.[0]?.roleType);
    return result.data.id;
  } else {
    console.error('❌ Errore creazione dipendente:', result.error);
    return null;
  }
}

// Test 5: Verifica duplicato P.IVA attiva
async function testDuplicatePiva(piva) {
  console.log('\n⚠️ Test 5: Verifica errore duplicato P.IVA attiva');
  
  const companyData = {
    ragioneSociale: 'Test Company Duplicate',
    piva: piva,
    sedeAzienda: 'Napoli',
    mail: 'duplicate@testcompany.com'
  };
  
  const result = await apiCall('POST', '/companies', companyData);
  
  if (!result.success && result.status === 409) {
    console.log('✅ Errore 409 correttamente restituito per P.IVA duplicata');
    return true;
  } else {
    console.error('❌ Doveva restituire errore 409 per P.IVA duplicata');
    return false;
  }
}

// Esecuzione dei test
async function runTests() {
  console.log('🧪 Avvio test delle correzioni implementate\n');
  
  // Login
  if (!await login()) {
    console.error('❌ Impossibile procedere senza login');
    process.exit(1);
  }
  
  let testResults = {
    passed: 0,
    failed: 0
  };
  
  // Test 1: Creazione azienda
  const companyResult = await testCreateCompany();
  if (companyResult) {
    testResults.passed++;
    
    // Test 2: Eliminazione azienda
    if (await testDeleteCompany(companyResult.companyId)) {
      testResults.passed++;
      
      // Test 3: Ripristino azienda
      const restoredCompanyId = await testRestoreCompany(companyResult.piva);
      if (restoredCompanyId) {
        testResults.passed++;
        
        // Test 4: Creazione dipendente
        if (await testCreateEmployee(restoredCompanyId)) {
          testResults.passed++;
        } else {
          testResults.failed++;
        }
        
        // Test 5: Verifica duplicato P.IVA
        if (await testDuplicatePiva(companyResult.piva)) {
          testResults.passed++;
        } else {
          testResults.failed++;
        }
        
        // Cleanup finale
        console.log('\n🧹 Cleanup finale...');
        await apiCall('DELETE', `/companies/${restoredCompanyId}`);
        
      } else {
        testResults.failed++;
      }
    } else {
      testResults.failed++;
    }
  } else {
    testResults.failed++;
  }
  
  // Risultati finali
  console.log('\n📊 RISULTATI TEST:');
  console.log(`✅ Test passati: ${testResults.passed}`);
  console.log(`❌ Test falliti: ${testResults.failed}`);
  console.log(`📈 Percentuale successo: ${Math.round((testResults.passed / (testResults.passed + testResults.failed)) * 100)}%`);
  
  if (testResults.failed === 0) {
    console.log('\n🎉 Tutti i test sono passati! Le correzioni funzionano correttamente.');
  } else {
    console.log('\n⚠️ Alcuni test sono falliti. Verificare i problemi riportati sopra.');
  }
}

// Avvia i test
runTests().catch(error => {
  console.error('❌ Errore durante l\'esecuzione dei test:', error);
  process.exit(1);
});