import axios from 'axios';

async function testNewRoles() {
  try {
    console.log('🔍 Testando presenza dei nuovi ruoli nell\'API...\n');

    // 1. Login per ottenere il token
    console.log('🔐 Effettuando login...');
    const loginResponse = await axios.post('http://localhost:4003/api/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    console.log('Debug - Struttura risposta login:', JSON.stringify(loginResponse.data, null, 2));

    if (!loginResponse.data.success) {
      throw new Error('Login fallito: ' + loginResponse.data.message);
    }

    const token = loginResponse.data.tokens?.access_token;
    if (!token) {
      throw new Error('Token non trovato nella risposta del login');
    }
    
    console.log('✅ Login effettuato con successo');

    // 2. Test endpoint gerarchia
    console.log('\n📊 Recuperando gerarchia dei ruoli...');
    const hierarchyResponse = await axios.get('http://localhost:4001/api/roles/hierarchy', {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    console.log('Debug - Struttura risposta gerarchia (prime 500 caratteri):', 
      JSON.stringify(hierarchyResponse.data, null, 2).substring(0, 500) + '...');

    // La risposta ha la struttura: { success: true, data: { ROLE_TYPE: {...}, ... } }
    const rolesData = hierarchyResponse.data.data;
    if (!rolesData) {
      throw new Error('data non trovato nella risposta');
    }
    
    // Converto l'oggetto in array per l'analisi
    const systemRoles = Object.entries(rolesData).map(([type, roleInfo]) => ({
      type,
      ...roleInfo
    }));
    
    console.log(`📊 Ruoli di sistema trovati: ${systemRoles.length}`);
    
    // 3. Verifica presenza dei nuovi ruoli
    const newRoles = ['TRAINING_ADMIN', 'CLINIC_ADMIN', 'COMPANY_MANAGER'];
    
    console.log('\n🎯 Verifica nuovi ruoli:');
    newRoles.forEach(roleType => {
      const found = systemRoles.find(role => role.type === roleType);
      if (found) {
        console.log(`✅ ${roleType}: ${found.name} (Livello ${found.level})`);
      } else {
        console.log(`❌ ${roleType}: NON TROVATO`);
      }
    });

    // 4. Mostra tutti i ruoli per debug
    console.log('\n📋 Tutti i ruoli di sistema:');
    systemRoles
      .filter(role => !role.isCustom) // Solo ruoli di sistema
      .sort((a, b) => a.level - b.level) // Ordinati per livello
      .forEach(role => {
        console.log(`  - ${role.type}: ${role.name} (Livello ${role.level})`);
      });

  } catch (error) {
    console.error('❌ Errore nel test:', error.message);
    if (error.response) {
      console.error('Dettagli errore:', error.response.data);
    }
  }
}

testNewRoles();