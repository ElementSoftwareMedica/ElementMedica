#!/usr/bin/env node

/**
 * Script per testare le chiamate API del frontend
 */

async function testFrontendAPI() {
  console.log('🧪 Testing Frontend API Calls...\n');

  try {
    // 1. Test login per ottenere token
    console.log('1. Testing login via proxy...');
    const loginResponse = await fetch('http://localhost:4003/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        identifier: 'admin@example.com',
        password: 'Admin123!'
      })
    });

    console.log('📊 Login response status:', loginResponse.status);
    
    if (!loginResponse.ok) {
      const errorText = await loginResponse.text();
      console.error('❌ Login failed:', errorText);
      return;
    }

    const loginData = await loginResponse.json();
    console.log('✅ Login successful');
    console.log('🔑 Token received:', loginData.tokens?.access_token?.substring(0, 20) + '...');
    console.log('🏢 Tenant ID:', loginData.user?.tenantId);

    const token = loginData.tokens?.access_token;
    const tenantId = loginData.user?.tenantId;

    if (!token || !tenantId) {
      console.error('❌ Missing token or tenant ID');
      return;
    }

    // 2. Test endpoint counters
    console.log('\n2. Testing /api/counters endpoint...');
    const countersResponse = await fetch('http://localhost:4003/api/counters', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'X-Tenant-ID': tenantId
      }
    });

    console.log('📊 Counters response status:', countersResponse.status);
    
    if (countersResponse.ok) {
      const countersData = await countersResponse.json();
      console.log('✅ Counters data received:');
      console.log('📈 Companies:', countersData.companies);
      console.log('👥 Employees:', countersData.employees);
    } else {
      const errorText = await countersResponse.text();
      console.error('❌ Counters request failed:', errorText);
    }

    // 3. Test endpoint companies
    console.log('\n3. Testing /api/companies endpoint...');
    const companiesResponse = await fetch('http://localhost:4003/api/companies', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'X-Tenant-ID': tenantId
      }
    });

    console.log('📊 Companies response status:', companiesResponse.status);
    
    if (companiesResponse.ok) {
      const companiesData = await companiesResponse.json();
      console.log('✅ Companies data received:', Array.isArray(companiesData) ? companiesData.length : 'Not an array');
    } else {
      const errorText = await companiesResponse.text();
      console.error('❌ Companies request failed:', errorText);
    }

    // 4. Test endpoint employees
    console.log('\n4. Testing /api/employees endpoint...');
    const employeesResponse = await fetch('http://localhost:4003/api/employees', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'X-Tenant-ID': tenantId
      }
    });

    console.log('📊 Employees response status:', employeesResponse.status);
    
    if (employeesResponse.ok) {
      const employeesData = await employeesResponse.json();
      console.log('✅ Employees data received:', Array.isArray(employeesData) ? employeesData.length : 'Not an array');
    } else {
      const errorText = await employeesResponse.text();
      console.error('❌ Employees request failed:', errorText);
    }

  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testFrontendAPI();