#!/usr/bin/env node

import axios from 'axios';

const API_BASE = 'http://localhost:4003';

async function testHierarchyDiagnosis() {
  try {
    console.log('🔍 DIAGNOSI PROBLEMI GERARCHIA DEI RUOLI');
    console.log('=====================================\n');

    // 1. Login
    console.log('1. 🔐 Effettuando login...');
    const loginResponse = await axios.post(`${API_BASE}/api/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    const token = loginResponse.data.tokens?.access_token;
    if (!token) {
      throw new Error('Token non trovato nella risposta del login');
    }
    console.log('✅ Login effettuato con successo\n');

    // 2. Test endpoint gerarchia principale
    console.log('2. 🌳 Testando endpoint /api/roles/hierarchy...');
    const hierarchyResponse = await axios.get(`${API_BASE}/api/roles/hierarchy`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    console.log('✅ Endpoint gerarchia funziona');
    console.log('📊 Dati gerarchia:', {
      success: hierarchyResponse.data.success,
      totalRoles: Object.keys(hierarchyResponse.data.data || {}).length,
      roles: Object.keys(hierarchyResponse.data.data || {})
    });

    const hierarchy = hierarchyResponse.data.data || {};
    console.log('\n📋 RUOLI NELLA GERARCHIA:');
    Object.entries(hierarchy).forEach(([roleType, roleData], index) => {
      console.log(`${index + 1}. ${roleType} - Livello ${roleData.level} - ${roleData.name}`);
    });

    // 3. Test endpoint utente corrente
    console.log('\n3. 👤 Testando endpoint /api/roles/hierarchy/current-user...');
    const currentUserResponse = await axios.get(`${API_BASE}/api/roles/hierarchy/current-user`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    console.log('✅ Endpoint utente corrente funziona');
    const currentUserData = currentUserResponse.data.data?.data || currentUserResponse.data.data || {};
    console.log('📊 Dati utente corrente:', {
      success: currentUserResponse.data.success,
      userRoles: currentUserData.userRoles || [],
      highestRole: currentUserData.highestRole,
      userLevel: currentUserData.userLevel,
      assignableRoles: currentUserData.assignableRoles?.length || 0
    });

    // 4. Test endpoint lista ruoli base
    console.log('\n4. 📝 Testando endpoint /api/roles (lista base)...');
    const rolesResponse = await axios.get(`${API_BASE}/api/roles`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    console.log('✅ Endpoint lista ruoli funziona');
    const rolesData = rolesResponse.data.data?.data || rolesResponse.data.data || [];
    console.log('📊 Dati lista ruoli:', {
      success: rolesResponse.data.success,
      totalRoles: rolesData.length,
      roles: rolesData.map(role => ({
        type: role.roleType || role.type,
        name: role.name,
        userCount: role.userCount
      }))
    });

    // 5. Confronto tra gerarchia e lista
    console.log('\n5. 🔍 CONFRONTO TRA GERARCHIA E LISTA:');
    const hierarchyRoles = Object.keys(hierarchy);
    const listRoles = rolesData.map(role => role.roleType || role.type);
    
    console.log(`- Ruoli nella gerarchia: ${hierarchyRoles.length}`);
    console.log(`- Ruoli nella lista: ${listRoles.length}`);
    
    const missingInList = hierarchyRoles.filter(role => !listRoles.includes(role));
    const missingInHierarchy = listRoles.filter(role => !hierarchyRoles.includes(role));
    
    if (missingInList.length > 0) {
      console.log('❌ Ruoli presenti nella gerarchia ma NON nella lista:', missingInList);
    }
    
    if (missingInHierarchy.length > 0) {
      console.log('❌ Ruoli presenti nella lista ma NON nella gerarchia:', missingInHierarchy);
    }
    
    if (missingInList.length === 0 && missingInHierarchy.length === 0) {
      console.log('✅ Tutti i ruoli sono coerenti tra gerarchia e lista');
    }

    // 6. Test creazione ruolo custom
    console.log('\n6. ➕ Testando creazione ruolo custom...');
    const customRoleData = {
      name: 'Test Ruolo Custom',
      description: 'Ruolo di test per diagnosi',
      permissions: ['VIEW_COURSES']
    };

    try {
      const createResponse = await axios.post(`${API_BASE}/api/roles`, customRoleData, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('✅ Creazione ruolo custom riuscita');
      console.log('📊 Ruolo creato:', createResponse.data);
      
      // Ricarica la gerarchia per vedere se il nuovo ruolo appare
      console.log('\n7. 🔄 Ricaricando gerarchia dopo creazione...');
      const newHierarchyResponse = await axios.get(`${API_BASE}/api/roles/hierarchy`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      const newHierarchy = newHierarchyResponse.data.data || {};
      const newHierarchyRoles = Object.keys(newHierarchy);
      console.log(`- Ruoli nella nuova gerarchia: ${newHierarchyRoles.length}`);
      
      const customRoleInHierarchy = newHierarchyRoles.find(role => 
        newHierarchy[role].name === customRoleData.name
      );
      
      if (customRoleInHierarchy) {
        console.log('✅ Ruolo custom trovato nella gerarchia:', customRoleInHierarchy);
      } else {
        console.log('❌ Ruolo custom NON trovato nella gerarchia');
      }
      
    } catch (createError) {
      console.log('❌ Errore nella creazione ruolo custom:', createError.response?.data || createError.message);
    }

    // 8. Verifica gerarchia predefinita richiesta
    console.log('\n8. 🏗️ Verificando gerarchia predefinita richiesta...');
    const requiredHierarchy = {
      'COMPANY_ADMIN': 'Amministratore Azienda',
      'TRAINING_ADMIN': 'Amministratore Formazione & Lavoro',
      'CLINIC_ADMIN': 'Amministratore Poliambulatorio',
      'MANAGER': 'Manager',
      'HR_MANAGER': 'Manager HR',
      'TRAINER_COORDINATOR': 'Coordinatore Formatori',
      'COMPANY_MANAGER': 'Responsabile Aziendale'
    };

    console.log('🎯 Gerarchia richiesta:');
    console.log('- Amministratore Azienda');
    console.log('  ├── Amministratore Formazione & Lavoro');
    console.log('  └── Amministratore Poliambulatorio');
    console.log('      └── Amministratore Formazione & Lavoro');
    console.log('          ├── Manager');
    console.log('          └── Manager HR');
    console.log('              ├── Coordinatore Formatori');
    console.log('              └── Responsabile Aziendale');

    console.log('\n🔍 Verifica presenza ruoli richiesti:');
    Object.entries(requiredHierarchy).forEach(([roleType, roleName]) => {
      if (hierarchy[roleType]) {
        console.log(`✅ ${roleType} (${hierarchy[roleType].name}) - Livello ${hierarchy[roleType].level}`);
      } else {
        console.log(`❌ ${roleType} (${roleName}) - NON TROVATO`);
      }
    });

    console.log('\n✅ DIAGNOSI COMPLETATA');

  } catch (error) {
    console.error('❌ Errore durante la diagnosi:', error.response?.data || error.message);
    if (error.response?.status === 401) {
      console.log('🔐 Problema di autenticazione - verificare credenziali');
    }
  }
}

testHierarchyDiagnosis();