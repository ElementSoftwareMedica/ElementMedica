#!/usr/bin/env node

/**
 * Script per verificare i tenant esistenti e il tenantId dell'utente admin
 */

import { PrismaClient } from './backend/node_modules/@prisma/client/index.js';

const prisma = new PrismaClient();

async function checkTenants() {
  try {
    console.log('🔍 Verificando tenant esistenti...');
    
    // Verifica tenant esistenti
    const tenants = await prisma.tenant.findMany({
      select: {
        id: true,
        name: true,
        slug: true,
        isActive: true
      }
    });
    
    console.log('📋 Tenant trovati:', tenants.length);
    tenants.forEach(tenant => {
      console.log(`  - ${tenant.name} (${tenant.slug}) - ID: ${tenant.id} - Attivo: ${tenant.isActive}`);
    });
    
    // Verifica utente admin
    console.log('\n👤 Verificando utente admin...');
    const adminUser = await prisma.person.findUnique({
      where: { email: 'admin@example.com' },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        tenantId: true,
        companyId: true,
        tenant: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        }
      }
    });
    
    if (adminUser) {
      console.log('✅ Utente admin trovato:');
      console.log(`  - ID: ${adminUser.id}`);
      console.log(`  - Email: ${adminUser.email}`);
      console.log(`  - Nome: ${adminUser.firstName} ${adminUser.lastName}`);
      console.log(`  - TenantId: ${adminUser.tenantId}`);
      console.log(`  - CompanyId: ${adminUser.companyId}`);
      if (adminUser.tenant) {
        console.log(`  - Tenant: ${adminUser.tenant.name} (${adminUser.tenant.slug})`);
      } else {
        console.log('  - ⚠️ Nessun tenant associato');
      }
    } else {
      console.log('❌ Utente admin non trovato');
    }
    
    // Se non ci sono tenant, crea un tenant di default
    if (tenants.length === 0) {
      console.log('\n🏗️ Creando tenant di default...');
      const defaultTenant = await prisma.tenant.create({
        data: {
          name: 'Default Tenant',
          slug: 'default',
          domain: 'localhost',
          settings: {},
          billingPlan: 'basic',
          maxUsers: 100,
          maxCompanies: 50,
          isActive: true
        }
      });
      console.log('✅ Tenant di default creato:', defaultTenant.id);
      
      // Aggiorna l'utente admin se esiste ma non ha tenantId
      if (adminUser && !adminUser.tenantId) {
        await prisma.person.update({
          where: { id: adminUser.id },
          data: { tenantId: defaultTenant.id }
        });
        console.log('✅ Utente admin aggiornato con tenantId di default');
      }
    }
    
  } catch (error) {
    console.error('❌ Errore:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

checkTenants();