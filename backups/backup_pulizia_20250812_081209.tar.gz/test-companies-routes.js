import axios from 'axios';

async function testCompaniesRoutes() {
  try {
    console.log('🔐 Step 1: Authenticating...');
    
    // Login to get token
    const loginResponse = await axios.post('http://localhost:4001/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    const token = loginResponse.data.data.accessToken;
    console.log('✅ Authentication successful');
    
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    
    console.log('\n📋 Step 2: Testing companies list endpoint...');
    try {
      const listResponse = await axios.get('http://localhost:4001/api/v1/companies', { headers });
      console.log('✅ Companies list test successful:', listResponse.status);
      console.log('Companies found:', listResponse.data.length || 'N/A');
    } catch (error) {
      console.log('❌ Companies list test failed:', error.response?.status, error.response?.statusText);
      if (error.response?.data) {
        console.log('Error details:', JSON.stringify(error.response.data, null, 2));
      }
    }
    
    console.log('\n🧪 Step 3: Testing companies test endpoint...');
    try {
      const testResponse = await axios.get('http://localhost:4001/api/v1/companies/test');
      console.log('✅ Companies test endpoint successful:', testResponse.status);
      console.log('Response:', JSON.stringify(testResponse.data, null, 2));
    } catch (error) {
      console.log('❌ Companies test endpoint failed:', error.response?.status, error.response?.statusText);
      if (error.response?.data) {
        console.log('Error details:', JSON.stringify(error.response.data, null, 2));
      }
    }
    
    console.log('\n📤 Step 4: Testing import endpoint...');
    const testData = {
      companies: [
        {
          ragioneSociale: "Test Company Import",
          piva: "12345678901",
          codiceFiscale: "TSTCMP01",
          indirizzo: "Via Test 123",
          citta: "Milano",
          cap: "20100",
          provincia: "MI",
          telefono: "02-1234567",
          email: "test@testcompany.com"
        }
      ]
    };
    
    try {
      const importResponse = await axios.post('http://localhost:4001/api/v1/companies/import', testData, { headers });
      console.log('✅ Import test successful:', importResponse.status);
      console.log('Response:', JSON.stringify(importResponse.data, null, 2));
    } catch (error) {
      console.log('❌ Import test failed:', error.response?.status, error.response?.statusText);
      if (error.response?.data) {
        console.log('Error details:', JSON.stringify(error.response.data, null, 2));
      }
    }
    
  } catch (error) {
    console.error('❌ Authentication failed:', error.response?.status, error.response?.statusText);
    if (error.response?.data) {
      console.error('Error details:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

testCompaniesRoutes();