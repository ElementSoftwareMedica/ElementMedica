# CSV Import Troubleshooting - Persone

## Problemi Identificati

### 1. Errore Prisma - Campo birthPlace
**Errore**: `Invalid \`prisma.person.create()\` invocation: Unknown argument \`birthPlace\``
**Status**: ✅ RISOLTO

### 2. Modal Conflitti Non Si Apre
**Errore**: Il modal dei conflitti non si apre nonostante vengano rilevati conflitti
**Status**: 🔍 IN INVESTIGAZIONE

## Soluzioni Implementate

### Soluzione 1: Rimozione Campo birthPlace ✅
**Problema**: Errore Prisma per campo non esistente nel database.

**Implementazione**:
1. Rimosso `birthPlace` da `fieldMapping` in `PersonImport.tsx`
2. Rimosso `birthPlace` dalla funzione `createPerson` in `personService.js`

### Soluzione 2-14: Debug Logging Esteso ✅
**Problema**: Necessità di tracciare il flusso di rilevamento conflitti.

**Implementazione**:
- Log in `detectConflicts`
- Log in `customProcessFile` 
- `useEffect` per monitorare stati `showConflictModal` e `conflicts`
- Log nel rendering del `PersonImportConflictModal`

### Soluzione 15: Fix Z-Index Modal Conflitti ✅
**Problema**: Possibile conflitto di z-index tra modal.

**Implementazione**:
- Aumentato z-index a `z-[10000]` e `zIndex: 10001`
- Aggiunto `useEffect` per forzare apertura modal con ritardo 100ms
- Log dettagliato nel rendering

### Soluzione 16: Debug Logging Esteso per Modal Conflitti ✅
**Problema**: Il modal dei conflitti non si apre nonostante i conflitti vengano rilevati.

**Implementazione**:

1. **Log dettagliato in `convertConflictsForModal` (PersonImport.tsx)**:
   ```javascript
   const convertConflictsForModal = () => {
     console.log('🔄 convertConflictsForModal chiamata');
     console.log('📊 conflicts:', conflicts);
     console.log('📋 previewData length:', previewData.length);
     
     const converted = Object.entries(conflicts).map(([index, conflict]) => {
       const convertedItem = {
         person: previewData[parseInt(index)],
         index: parseInt(index),
         type: conflict.type,
         existingPerson: conflict.existingPerson,
         suggestedCompanies: conflict.suggestedCompanies || []
       };
       console.log(`🔄 Converted conflict ${index}:`, convertedItem);
       return convertedItem;
     });
     
     console.log('✅ convertConflictsForModal result:', converted);
     return converted;
   };
   ```

2. **Log dettagliato in `PersonImportConflictModal.tsx`**:
   ```javascript
   // Debug log per verificare quando il componente viene renderizzato
   console.log('🎭 PersonImportConflictModal render START:', {
     isOpen,
     conflictsLength: conflicts?.length || 0,
     existingCompaniesLength: existingCompanies?.length || 0,
     conflicts: conflicts,
     timestamp: new Date().toISOString()
   });

   // Log dettagliato dei conflitti ricevuti
   if (conflicts && conflicts.length > 0) {
     console.log('📋 Conflicts details:');
     conflicts.forEach((conflict, idx) => {
       console.log(`  Conflict ${idx}:`, {
         index: conflict.index,
         type: conflict.type,
         person: conflict.person,
         existingPerson: conflict.existingPerson,
         suggestedCompanies: conflict.suggestedCompanies
       });
     });
   }
   ```

3. **File CSV di test aggiornato** (`test-conflict.csv`):
   - Aggiunta terza riga per testare più conflitti
   - Include sia duplicati che aziende inesistenti

**Status**: 🔍 IN TEST - Verificare i log nella console del browser durante l'importazione

## File di Test

### test-conflict.csv
File CSV creato per testare il rilevamento dei conflitti:
- Barbara Tremonti: dovrebbe essere rilevata come duplicato
- Mario Rossi: azienda inesistente "Azienda Inesistente"
- Giulia Bianchi: azienda inesistente "Altra Azienda Inesistente"

## Prossimi Passi

1. **Testare con file CSV di test**: Utilizzare `test-conflict.csv` per verificare i log
2. **Analizzare log console**: Verificare se il modal viene renderizzato
3. **Identificare punto di fallimento**: Capire dove si interrompe il flusso

## Note Tecniche

- **Server attivo**: http://localhost:5176
- **File di test**: `/Users/matteo.michielon/project 2.0/test-conflict.csv`
- **Log da monitorare**: Console del browser durante importazione
- **Componenti modificati**: `PersonImport.tsx`, `PersonImportConflictModal.tsx`