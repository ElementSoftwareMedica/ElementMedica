# PLANNING RISOLUZIONE PERMESSI - ANALISI E STANDARDIZZAZIONE

## 🔍 ANALISI SITUAZIONE ATTUALE

### Problemi Identificati
1. **Utente admin non può accedere ai ruoli** - manca il permesso `roles:read`
2. **Inconsistenza nei formati dei permessi** tra frontend e backend
3. **Possibile mancanza del ruolo ADMIN** nel database per l'utente admin@example.com

### Architettura Permessi Attuale

#### Backend (Database - Schema Prisma)
- **Enum PersonPermission**: `ROLE_MANAGEMENT`, `VIEW_ROLES`, `CREATE_ROLES`, etc.
- **Modello PersonRole**: Collega Person a RoleType (ADMIN, SUPER_ADMIN, etc.)
- **Modello RolePermission**: Collega ruoli a permessi specifici

#### Frontend
- **Formato richiesto**: `resource:action` (es. `roles:read`, `companies:view`)
- **Mapping in permissionMapping.ts**: Converte backend → frontend
- **AuthContext**: Gestisce verifica permessi con `hasPermission()`

#### Endpoint Backend `/verify`
- **Fornisce permessi hardcoded per ADMIN/SUPER_ADMIN**
- **Include già `roles:read`, `roles:view`, `roles:manage`**
- **Mapping automatico per tutti i permessi admin**

## 🎯 STANDARDIZZAZIONE PROPOSTA

### Formato Standard Adottato: `resource:action`

**Motivazioni:**
1. **Più leggibile**: `roles:read` vs `ROLE_MANAGEMENT`
2. **Più granulare**: Permette azioni specifiche (`read`, `create`, `edit`, `delete`)
3. **Più mantenibile**: Struttura consistente e prevedibile
4. **Già utilizzato nel frontend**: Riduce refactoring necessario

### Mapping Standardizzato

#### Entità Principali
```
companies:read, companies:create, companies:edit, companies:delete
persons:read, persons:create, persons:edit, persons:delete
employees:read, employees:create, employees:edit, employees:delete
trainers:read, trainers:create, trainers:edit, trainers:delete
courses:read, courses:create, courses:edit, courses:delete
roles:read, roles:create, roles:edit, roles:delete
users:read, users:create, users:edit, users:delete
```

#### Permessi Speciali
```
dashboard:view
admin:access
system:admin
settings:view, settings:edit
gdpr:view, gdpr:export, gdpr:delete
reports:view, reports:export
```

## 🚀 PIANO DI IMPLEMENTAZIONE

### FASE 1: RISOLUZIONE IMMEDIATA (PRIORITÀ ALTA)
1. **Verifica ruolo admin nel database**
   - Controllare se admin@example.com ha ruolo ADMIN/SUPER_ADMIN
   - Aggiungere ruolo se mancante

2. **Test login e permessi**
   - Verificare che l'endpoint `/verify` restituisca i permessi corretti
   - Testare accesso alla sezione ruoli

### FASE 2: STANDARDIZZAZIONE BACKEND (PRIORITÀ MEDIA)
1. **Aggiornare enum PersonPermission**
   - Migrare da `ROLE_MANAGEMENT` a `ROLES_READ`
   - Mantenere backward compatibility

2. **Aggiornare servizi backend**
   - Modificare `EnhancedRoleService.js`
   - Aggiornare `getDefaultPermissions()`

### FASE 3: OTTIMIZZAZIONE FRONTEND (PRIORITÀ BASSA)
1. **Semplificare permissionMapping.ts**
   - Ridurre mappature speciali
   - Standardizzare conversioni

2. **Aggiornare componenti**
   - Verificare tutti gli usi di `hasPermission()`
   - Standardizzare chiamate ai permessi

## 🔧 AZIONI IMMEDIATE

### 1. Script di Verifica Database
```sql
-- Verificare utente admin
SELECT p.id, p.email, p.firstName, p.lastName, pr.roleType
FROM Person p
LEFT JOIN PersonRole pr ON p.id = pr.personId
WHERE p.email = 'admin@example.com';

-- Verificare permessi ruolo ADMIN
SELECT rp.permission, rp.isGranted
FROM RolePermission rp
JOIN PersonRole pr ON rp.roleId = pr.id
JOIN Person p ON pr.personId = p.id
WHERE p.email = 'admin@example.com' AND pr.roleType = 'ADMIN';
```

### 2. Script di Correzione
```javascript
// Aggiungere ruolo ADMIN se mancante
// Aggiungere permessi ROLE_MANAGEMENT, VIEW_ROLES, etc.
// Verificare che l'endpoint /verify restituisca roles:read
```

## 📋 CHECKLIST VERIFICA

### Pre-Login
- [ ] Utente admin@example.com esiste nel database
- [ ] Utente ha ruolo ADMIN o SUPER_ADMIN assegnato
- [ ] Ruolo ha permessi ROLE_MANAGEMENT, VIEW_ROLES

### Post-Login
- [ ] Endpoint `/verify` restituisce `roles:read: true`
- [ ] Frontend riceve e converte correttamente i permessi
- [ ] `hasPermission('roles', 'read')` restituisce `true`
- [ ] Accesso alla sezione ruoli funziona

### Test Completo
- [ ] Login con admin@example.com / Admin123!
- [ ] Navigazione a /settings/roles
- [ ] Visualizzazione lista ruoli
- [ ] Creazione/modifica ruoli funziona

## 🎯 RISULTATO ATTESO

Dopo l'implementazione:
1. **Login admin funzionante** con accesso completo ai ruoli
2. **Permessi standardizzati** nel formato `resource:action`
3. **Mapping consistente** tra backend e frontend
4. **Conformità GDPR** mantenuta con controlli granulari
5. **Architettura scalabile** per futuri permessi

## 📝 NOTE TECNICHE

### Compatibilità
- Mantenere backward compatibility durante la migrazione
- Testare tutti i ruoli (ADMIN, COMPANY_ADMIN, EMPLOYEE)
- Verificare che i permessi esistenti continuino a funzionare

### Sicurezza
- Non creare bypass per admin
- Mantenere controlli granulari GDPR
- Verificare che i permessi siano sempre espliciti

### Performance
- Ottimizzare query di verifica permessi
- Implementare caching appropriato
- Minimizzare chiamate API per verifica permessi