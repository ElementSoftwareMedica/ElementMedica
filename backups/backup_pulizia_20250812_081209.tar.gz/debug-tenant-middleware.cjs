const axios = require('axios');

const BASE_URL = 'http://localhost:4003'; // Uso il proxy server

async function debugTenantMiddleware() {
  try {
    console.log('=== DEBUG TENANT MIDDLEWARE ===\n');

    // 1. Login per ottenere il token
    console.log('1. Effettuando login...');
    const loginResponse = await axios.post(`${BASE_URL}/api/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    const token = loginResponse.data.tokens?.access_token;
    if (!token) {
      console.log('❌ Token non ricevuto nella risposta di login');
      console.log('Risposta completa:', JSON.stringify(loginResponse.data, null, 2));
      return;
    }

    console.log('✅ Login effettuato con successo');
    
    // Decodifica il token per vedere i dettagli
    const tokenParts = token.split('.');
    const payload = JSON.parse(Buffer.from(tokenParts[1], 'base64').toString());
    console.log('Token payload:', {
      userId: payload.userId,
      tenantId: payload.tenantId,
      roles: payload.roles,
      exp: new Date(payload.exp * 1000).toISOString()
    });

    // 2. Test con diversi header per il tenant
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    console.log('\n2. Test endpoint /api/tenants/current senza header tenant...');
    try {
      const response = await axios.get(`${BASE_URL}/api/tenants/current`, { headers });
      console.log('✅ Successo:', response.data);
    } catch (error) {
      console.log('❌ Errore:', error.response?.status, error.response?.data);
    }

    console.log('\n3. Test endpoint /api/tenants/current con header X-Tenant-ID...');
    try {
      const headersWithTenant = {
        ...headers,
        'X-Tenant-ID': payload.tenantId
      };
      const response = await axios.get(`${BASE_URL}/api/tenants/current`, { headers: headersWithTenant });
      console.log('✅ Successo:', response.data);
    } catch (error) {
      console.log('❌ Errore:', error.response?.status, error.response?.data);
    }

    console.log('\n4. Test endpoint /api/tenants/current con query parameter...');
    try {
      const response = await axios.get(`${BASE_URL}/api/tenants/current?tenantId=${payload.tenantId}`, { headers });
      console.log('✅ Successo:', response.data);
    } catch (error) {
      console.log('❌ Errore:', error.response?.status, error.response?.data);
    }

    console.log('\n5. Test endpoint /api/persons per confronto...');
    try {
      const response = await axios.get(`${BASE_URL}/api/persons`, { headers });
      console.log('✅ Successo - Numero di persone:', response.data.data?.length || 0);
    } catch (error) {
      console.log('❌ Errore:', error.response?.status, error.response?.data);
    }

    console.log('\n6. Test endpoint /api/companies per confronto...');
    try {
      const response = await axios.get(`${BASE_URL}/api/companies`, { headers });
      console.log('✅ Successo - Numero di aziende:', response.data.data?.length || 0);
    } catch (error) {
      console.log('❌ Errore:', error.response?.status, error.response?.data);
    }

  } catch (error) {
    console.error('Errore durante il debug:', error.message);
    console.error('Stack trace completo:', error.stack);
    if (error.response) {
      console.log('Status:', error.response.status);
      console.log('Data:', error.response.data);
      console.log('Headers:', error.response.headers);
    }
    if (error.code) {
      console.log('Error Code:', error.code);
    }
    if (error.code === 'ECONNREFUSED') {
      console.log('\n❌ Server non raggiungibile. Assicurati che il proxy server sia in esecuzione sulla porta 4003.');
    }
  }
}

debugTenantMiddleware();