const axios = require('axios');

async function testPermissionsBrowser() {
    console.log('🔐 Testing permissions in browser context...');
    
    try {
        // 1. Login per ottenere il token
        console.log('📝 Step 1: Login...');
        const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
            identifier: 'admin@example.com',
            password: 'Admin123!'
        });
        
        const token = loginResponse.data.tokens.access_token;
        console.log('✅ Login successful');
        
        // 2. Verifica permessi tramite endpoint /verify
        console.log('📝 Step 2: Verify permissions...');
        const verifyResponse = await axios.get('http://localhost:4003/api/v1/auth/verify', {
            headers: { Authorization: `Bearer ${token}` }
        });
        
        const permissions = verifyResponse.data.permissions;
        console.log(`✅ Permissions loaded: ${Object.keys(permissions).length} total`);
        
        // 3. Test permessi specifici
        console.log('📝 Step 3: Testing specific permissions...');
        
        const permissionsToTest = [
            'PUBLIC_CMS:READ',
            'PUBLIC_CMS:UPDATE', 
            'form_templates:read',
            'form_templates:update',
            'form_submissions:read',
            'form_submissions:update'
        ];
        
        console.log('\n🧪 Permission Test Results:');
        permissionsToTest.forEach(permission => {
            const hasPermission = permissions[permission] === true;
            console.log(`  ${hasPermission ? '✅' : '❌'} ${permission}: ${hasPermission}`);
        });
        
        // 4. Simula la funzione hasPermission del frontend
        console.log('\n📝 Step 4: Simulating frontend hasPermission function...');
        
        function simulateHasPermission(entity, action) {
            const permissionKey = `${entity}:${action.toUpperCase()}`;
            const permissionKeyLower = `${entity}:${action.toLowerCase()}`;
            
            return permissions[permissionKey] === true || permissions[permissionKeyLower] === true;
        }
        
        const frontendTests = [
            { entity: 'PUBLIC_CMS', action: 'READ' },
            { entity: 'PUBLIC_CMS', action: 'UPDATE' },
            { entity: 'form_templates', action: 'read' },
            { entity: 'form_templates', action: 'update' },
            { entity: 'form_submissions', action: 'read' },
            { entity: 'form_submissions', action: 'update' }
        ];
        
        console.log('\n🎯 Frontend hasPermission Simulation:');
        frontendTests.forEach(test => {
            const result = simulateHasPermission(test.entity, test.action);
            console.log(`  ${result ? '✅' : '❌'} hasPermission('${test.entity}', '${test.action}'): ${result}`);
        });
        
        // 5. Mostra tutti i permessi CMS e form
        console.log('\n📋 All CMS and Form permissions:');
        Object.keys(permissions).filter(p => 
            p.includes('CMS') || p.includes('cms') || p.includes('form') || p.includes('FORM')
        ).forEach(p => {
            if (permissions[p] === true) {
                console.log(`  ✅ ${p}`);
            }
        });
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        if (error.response) {
            console.error('Response data:', error.response.data);
        }
    }
}

testPermissionsBrowser();