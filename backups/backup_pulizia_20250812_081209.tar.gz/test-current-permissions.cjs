const axios = require('axios');

const API_BASE = 'http://localhost:4001';

async function testCurrentPermissions() {
  try {
    console.log('🔐 Testing current admin permissions...\n');
    
    // Login
    console.log('1. Attempting login...');
    const loginResponse = await axios.post(`${API_BASE}/api/v1/auth/login`, {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });
    
    if (!loginResponse.data.tokens?.access_token) {
      console.error('❌ Login failed - no access token');
      return;
    }
    
    const token = loginResponse.data.tokens.access_token;
    console.log('✅ Login successful');
    
    // Verify token and get permissions
    console.log('\n2. Getting current permissions...');
    const verifyResponse = await axios.get(`${API_BASE}/api/v1/auth/verify`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    if (!verifyResponse.data.valid) {
      console.error('❌ Token verification failed');
      return;
    }
    
    const user = verifyResponse.data.user;
    const permissions = verifyResponse.data.permissions;
    
    console.log('✅ User info:', {
      id: user.id,
      email: user.email,
      role: user.role,
      roles: user.roles
    });
    
    console.log('\n3. Current permissions:');
    const permissionKeys = Object.keys(permissions).filter(key => permissions[key] === true);
    console.log(`Total permissions: ${permissionKeys.length}`);
    
    // Group permissions by category
    const categories = {
      cms: permissionKeys.filter(p => p.toLowerCase().includes('cms')),
      form: permissionKeys.filter(p => p.toLowerCase().includes('form')),
      submission: permissionKeys.filter(p => p.toLowerCase().includes('submission')),
      public: permissionKeys.filter(p => p.toLowerCase().includes('public')),
      companies: permissionKeys.filter(p => p.toLowerCase().includes('companies')),
      users: permissionKeys.filter(p => p.toLowerCase().includes('users')),
      roles: permissionKeys.filter(p => p.toLowerCase().includes('role')),
      other: permissionKeys.filter(p => 
        !p.toLowerCase().includes('cms') &&
        !p.toLowerCase().includes('form') &&
        !p.toLowerCase().includes('submission') &&
        !p.toLowerCase().includes('public') &&
        !p.toLowerCase().includes('companies') &&
        !p.toLowerCase().includes('users') &&
        !p.toLowerCase().includes('role')
      )
    };
    
    Object.entries(categories).forEach(([category, perms]) => {
      if (perms.length > 0) {
        console.log(`\n📂 ${category.toUpperCase()} permissions (${perms.length}):`);
        perms.forEach(p => console.log(`  - ${p}`));
      }
    });
    
    // Test specific permissions that should exist
    console.log('\n4. Testing specific permissions:');
    const testPermissions = [
      'PUBLIC_CMS:READ',
      'PUBLIC_CMS:UPDATE', 
      'form_templates:read',
      'form_templates:create',
      'form_submissions:read',
      'form_submissions:update',
      'VIEW_CMS',
      'EDIT_CMS',
      'VIEW_FORM_TEMPLATES',
      'CREATE_FORM_TEMPLATES',
      'VIEW_FORM_SUBMISSIONS',
      'EDIT_FORM_SUBMISSIONS',
      'MANAGE_PUBLIC_CMS',
      'MANAGE_FORM_TEMPLATES',
      'MANAGE_FORM_SUBMISSIONS'
    ];
    
    testPermissions.forEach(perm => {
      const hasPermission = permissions[perm] === true;
      console.log(`${hasPermission ? '✅' : '❌'} ${perm}: ${hasPermission}`);
    });
    
    // Test API endpoints
    console.log('\n5. Testing API endpoints access:');
    
    // Test CMS endpoint
    try {
      const cmsResponse = await axios.get(`${API_BASE}/api/v1/cms/public-content`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      console.log('✅ CMS endpoint accessible');
    } catch (error) {
      console.log(`❌ CMS endpoint error: ${error.response?.status} - ${error.response?.data?.message || error.message}`);
    }
    
    // Test Form Templates endpoint
    try {
      const formTemplatesResponse = await axios.get(`${API_BASE}/api/v1/form-templates`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      console.log('✅ Form Templates endpoint accessible');
    } catch (error) {
      console.log(`❌ Form Templates endpoint error: ${error.response?.status} - ${error.response?.data?.message || error.message}`);
    }
    
    // Test Form Submissions endpoint
    try {
      const formSubmissionsResponse = await axios.get(`${API_BASE}/api/v1/form-submissions`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      console.log('✅ Form Submissions endpoint accessible');
    } catch (error) {
      console.log(`❌ Form Submissions endpoint error: ${error.response?.status} - ${error.response?.data?.message || error.message}`);
    }
    
  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
  }
}

testCurrentPermissions();