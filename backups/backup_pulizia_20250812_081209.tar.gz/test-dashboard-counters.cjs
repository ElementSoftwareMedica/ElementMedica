const puppeteer = require('puppeteer');

async function testDashboardCounters() {
  let browser;
  
  try {
    console.log('🚀 Starting Dashboard Counters Debug Test...\n');
    
    // Launch browser
    browser = await puppeteer.launch({ 
      headless: false, 
      devtools: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    
    // Listen to console logs
    page.on('console', msg => {
      const type = msg.type();
      const text = msg.text();
      
      // Filter for relevant logs
      if (text.includes('counters') || text.includes('fetchCounters') || text.includes('Fetching counters') || text.includes('Counters')) {
        console.log(`🔍 [${type.toUpperCase()}] ${text}`);
      }
    });
    
    // Listen to network requests
    page.on('response', response => {
      const url = response.url();
      if (url.includes('/api/counters')) {
        console.log(`📡 API Response: ${response.status()} ${url}`);
        response.json().then(data => {
          console.log(`📊 Counters API Data:`, JSON.stringify(data, null, 2));
        }).catch(() => {
          console.log(`❌ Failed to parse response body for ${url}`);
        });
      }
    });
    
    console.log('🌐 Navigating to login page...');
    await page.goto('http://localhost:5173/login', { waitUntil: 'networkidle0' });
    
    console.log('🔐 Performing login...');
    await page.type('#identifier', 'admin@example.com');
    await page.type('#password', 'Admin123!');
    await page.click('button[type="submit"]');
    
    // Wait for navigation to dashboard
    console.log('⏳ Waiting for dashboard to load...');
    await page.waitForNavigation({ waitUntil: 'networkidle0' });
    
    // Wait a bit more for React to render
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    console.log('📊 Checking counters in DOM...');
    
    // Get counter values from DOM
    const counters = await page.evaluate(() => {
      const statCards = document.querySelectorAll('[data-testid="stat-card"], .grid > div');
      const results = [];
      
      statCards.forEach((card, index) => {
        const title = card.querySelector('h3, .text-sm, .font-medium')?.textContent?.trim();
        const value = card.querySelector('.text-2xl, .text-3xl, .font-bold')?.textContent?.trim();
        
        if (title && value) {
          results.push({ title, value, index });
        }
      });
      
      return results;
    });
    
    console.log('📈 Counter values found in DOM:');
    counters.forEach(counter => {
      console.log(`  - ${counter.title}: ${counter.value}`);
    });
    
    // Check localStorage for auth data
    const authData = await page.evaluate(() => {
      return {
        token: localStorage.getItem('authToken'),
        tenantId: localStorage.getItem('tenantId'),
        user: localStorage.getItem('user')
      };
    });
    
    console.log('🔑 Auth data in localStorage:');
    console.log(`  - Token: ${authData.token ? 'Present' : 'Missing'}`);
    console.log(`  - Tenant ID: ${authData.tenantId || 'Missing'}`);
    console.log(`  - User: ${authData.user ? 'Present' : 'Missing'}`);
    
    // Wait for any additional network requests
    console.log('⏳ Waiting for additional requests...');
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    // Take a screenshot
    await page.screenshot({ path: 'dashboard-debug.png', fullPage: true });
    console.log('📸 Screenshot saved as dashboard-debug.png');
    
    console.log('✅ Test completed successfully');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

// Check if puppeteer is available
try {
  require('puppeteer');
  testDashboardCounters();
} catch (error) {
  console.log('❌ Puppeteer not available. Installing...');
  console.log('Run: npm install puppeteer');
  console.log('Then run this test again.');
}