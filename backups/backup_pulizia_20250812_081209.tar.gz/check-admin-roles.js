import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkAdminRoles() {
    try {
        console.log('🔍 Checking admin user roles...');
        
        // Trova l'utente admin
        const adminUser = await prisma.person.findUnique({
            where: { email: 'admin@example.com' },
            include: {
                personRoles: {
                    where: { deletedAt: null },
                    include: {
                        advancedPermissions: true
                    }
                },
                company: true
            }
        });
        
        if (!adminUser) {
            console.log('❌ Admin user not found');
            return;
        }
        
        console.log('✅ Admin user found:', {
            id: adminUser.id,
            email: adminUser.email,
            firstName: adminUser.firstName,
            lastName: adminUser.lastName,
            companyId: adminUser.companyId,
            tenantId: adminUser.tenantId
        });
        
        console.log('\n📋 Person Roles:');
        adminUser.personRoles.forEach((role, index) => {
            console.log(`  ${index + 1}. Role Type: ${role.roleType}`);
            console.log(`     - ID: ${role.id}`);
            console.log(`     - Tenant ID: ${role.tenantId}`);
            console.log(`     - Company ID: ${role.companyId}`);
            console.log(`     - Is Active: ${role.isActive}`);
            console.log(`     - Valid Until: ${role.validUntil}`);
            console.log(`     - Advanced Permissions: ${role.advancedPermissions.length}`);
            console.log('');
        });
        
        // Verifica se ha il ruolo ADMIN
        const hasAdminRole = adminUser.personRoles.some(role => role.roleType === 'ADMIN');
        console.log(`🔑 Has ADMIN role: ${hasAdminRole}`);
        
        // Conta le aziende nel database
        const companiesCount = await prisma.company.count({
            where: { deletedAt: null }
        });
        console.log(`🏢 Total companies in database: ${companiesCount}`);
        
        // Conta le persone (dipendenti) nel database
        const employeesCount = await prisma.person.count({
            where: { 
                deletedAt: null,
                personRoles: {
                    some: {
                        roleType: {
                            in: ['COMPANY_ADMIN', 'MANAGER', 'EMPLOYEE']
                        },
                        deletedAt: null
                    }
                }
            }
        });
        console.log(`👥 Total employees in database: ${employeesCount}`);
        
    } catch (error) {
        console.error('❌ Error checking admin roles:', error);
    } finally {
        await prisma.$disconnect();
    }
}

checkAdminRoles();