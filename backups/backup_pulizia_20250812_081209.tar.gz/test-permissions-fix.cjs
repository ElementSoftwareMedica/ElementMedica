const axios = require('axios');

async function testPermissionsFix() {
  try {
    console.log('🧪 Test Risoluzione Errore Permessi');
    console.log('=====================================');

    // 1. Login per ottenere token
    console.log('1. 🔐 Effettuo login...');
    const loginResponse = await axios.post('http://localhost:4003/api/v1/auth/login', {
      identifier: 'admin@example.com',
      password: 'Admin123!'
    });

    const accessToken = loginResponse.data.tokens.access_token;
    const user = loginResponse.data.user;
    const tenantId = user.tenantId;

    console.log('✅ Login riuscito');
    console.log(`🏢 Tenant ID: ${tenantId}`);
    console.log(`🎫 Token: ${accessToken.substring(0, 20)}...`);

    // 2. Test endpoint /api/v1/submissions/advanced
    console.log('\n2. 🧪 Test endpoint /api/v1/submissions/advanced...');
    try {
      const submissionsResponse = await axios.get('http://localhost:4003/api/v1/submissions/advanced', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-tenant-id': tenantId,
          'Content-Type': 'application/json'
        }
      });

      console.log('✅ Endpoint /api/v1/submissions/advanced funziona!');
      console.log(`📊 Status: ${submissionsResponse.status}`);
      console.log(`📝 Submissions trovate: ${submissionsResponse.data.submissions?.length || 0}`);
    } catch (error) {
      console.log('❌ Errore su /api/v1/submissions/advanced:');
      console.log(`📊 Status: ${error.response?.status}`);
      console.log(`💬 Messaggio: ${error.response?.data?.error || error.message}`);
      console.log(`🔍 Codice: ${error.response?.data?.code || 'N/A'}`);
    }

    // 3. Test endpoint /api/v1/submissions (per confronto)
    console.log('\n3. 🧪 Test endpoint /api/v1/submissions...');
    try {
      const basicSubmissionsResponse = await axios.get('http://localhost:4003/api/v1/submissions', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'x-tenant-id': tenantId,
          'Content-Type': 'application/json'
        }
      });

      console.log('✅ Endpoint /api/v1/submissions funziona!');
      console.log(`📊 Status: ${basicSubmissionsResponse.status}`);
      console.log(`📝 Submissions trovate: ${basicSubmissionsResponse.data.submissions?.length || 0}`);
    } catch (error) {
      console.log('❌ Errore su /api/v1/submissions:');
      console.log(`📊 Status: ${error.response?.status}`);
      console.log(`💬 Messaggio: ${error.response?.data?.error || error.message}`);
      console.log(`🔍 Codice: ${error.response?.data?.code || 'N/A'}`);
    }

    console.log('\n🏁 Test completato!');

  } catch (error) {
    console.error('❌ Errore durante il test:', error.message);
    if (error.response) {
      console.error(`📊 Status: ${error.response.status}`);
      console.error(`💬 Messaggio: ${error.response.data?.error || 'Errore sconosciuto'}`);
    }
  }
}

testPermissionsFix();